import * as i0 from '@angular/core';
import { Provider, EnvironmentProviders, Type, InjectionToken, TemplateRef, AfterViewInit, AfterViewChecked, OnInit, DoCheck, OnDestroy } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import * as _ngx_formly_core from '@ngx-formly/core';
import { FormlyFieldConfig, ConfigOption, FormlyFormOptions, FieldType, FieldTypeConfig, FieldArrayType, FieldWrapper } from '@ngx-formly/core';
import { Observable } from 'rxjs';

/**
 * Tipos TypeScript del SchemaContract (openspec.yaml).
 * Son la representación 1:1 del JSON que emite el backend / Appian.
 */
type DfFieldType = 'text' | 'email' | 'password' | 'number' | 'textarea' | 'select' | 'multiselect' | 'radio' | 'checkbox' | 'date' | 'hidden' | 'currency';
/**
 * Nombre de un tipo Formly registrado por la app con provideDynamicForms({ types }).
 * El `& Record<never, never>` conserva el autocompletado de DfFieldType.
 */
type DfCustomFieldType = string & Record<never, never>;
declare const DF_FIELD_TYPES: readonly DfFieldType[];
interface DfOption {
    value: string | number | boolean;
    label: string;
    disabled?: boolean;
}
interface DfStaticOptions {
    source: 'static';
    items: DfOption[];
}
interface DfDependentOptions {
    source: 'dependent';
    dependsOn: string;
    map: Record<string, DfOption[]>;
    resetOnChange?: boolean;
}
interface DfRemoteOptions {
    source: 'remote';
    endpoint: string;
    dependsOn?: string[];
    resetOnChange?: boolean;
}
type DfOptionsSource = DfOption[] | DfStaticOptions | DfDependentOptions | DfRemoteOptions;
type DfOperator = 'eq' | 'neq' | 'in' | 'nin' | 'gt' | 'gte' | 'lt' | 'lte' | 'empty' | 'notEmpty' | 'truthy' | 'falsy' | 'matches' | 'contains';
declare const DF_OPERATORS: readonly DfOperator[];
interface DfCondition {
    field: string;
    operator: DfOperator;
    value?: unknown;
}
interface DfRuleGroup {
    all?: DfRule[];
    any?: DfRule[];
    not?: DfRule;
}
type DfRule = DfCondition | DfRuleGroup;
interface DfConditionalLogic {
    showWhen?: DfRule;
    hideWhen?: DfRule;
    requiredWhen?: DfRule;
    disabledWhen?: DfRule;
    resetOnHide?: boolean;
}
interface DfValidatorRef {
    name: string;
    args?: Record<string, unknown>;
    message?: string;
}
interface DfValidation {
    required?: boolean;
    min?: number;
    max?: number;
    minLength?: number;
    maxLength?: number;
    pattern?: string;
    validators?: DfValidatorRef[];
    asyncValidators?: DfValidatorRef[];
    messages?: Record<string, string>;
}
interface DfFieldLayout {
    col?: number;
    order?: number;
    cssClass?: string;
}
interface DfField {
    key: string;
    type: DfFieldType | DfCustomFieldType;
    label?: string;
    placeholder?: string;
    description?: string;
    defaultValue?: unknown;
    readonly?: boolean;
    disabled?: boolean;
    hidden?: boolean;
    options?: DfOptionsSource;
    validation?: DfValidation;
    logic?: DfConditionalLogic;
    layout?: DfFieldLayout;
    props?: Record<string, unknown>;
}
interface DfGroup {
    type: 'group';
    id: string;
    title?: string;
    description?: string;
    columns?: number;
    cssClass?: string;
    logic?: DfConditionalLogic;
    fields: DfNode[];
}
type DfArrayDisplay = 'rows' | 'table';
type DfArrayTotalOp = 'sum' | 'count' | 'avg' | 'min' | 'max';
declare const DF_ARRAY_TOTAL_OPS: readonly DfArrayTotalOp[];
/**
 * Resumen que se muestra bajo la lista y se recalcula con cada cambio. Solo se muestra: no se
 * guarda en el modelo. `field` es un campo `number` o `currency` de la fila; `count` no lo necesita
 * (sin `field` cuenta las filas, con `field` las que lo tienen relleno). Un total de un campo
 * `currency` se muestra con su moneda y su formato.
 */
interface DfArrayTotal {
    label: string;
    op: DfArrayTotalOp;
    field?: string;
}
/**
 * Lista repetible de filas: el modelo guarda `key: [{...}, {...}]`, un objeto por fila con los `fields` del nodo.
 * Dentro de una fila, una condición puede apuntar a otro campo de la misma fila con `./campo`.
 */
interface DfArray {
    type: 'array';
    key: string;
    title?: string;
    description?: string;
    /** Nombre de cada fila en la disposición `rows` ("Línea 1", "Línea 2"…). */
    itemLabel?: string;
    addLabel?: string;
    removeLabel?: string;
    minItems?: number;
    maxItems?: number;
    totals?: DfArrayTotal[];
    /** `rows`: una tarjeta por fila. `table`: cabecera de columnas y una línea por fila. Por defecto `rows`. */
    display?: DfArrayDisplay;
    /** Campos por línea dentro de cada fila (solo `rows`). */
    columns?: number;
    cssClass?: string;
    logic?: DfConditionalLogic;
    fields: DfNode[];
}
type DfTableColumnType = 'text' | 'number' | 'currency' | 'date' | 'datetime' | 'boolean' | 'map' | 'badge' | 'link';
/** Variantes de color de una insignia (`df-badge--ok|warn|error|info`). */
type DfBadgeVariant = 'ok' | 'warn' | 'error' | 'info';
declare const DF_BADGE_VARIANTS: readonly DfBadgeVariant[];
declare const DF_TABLE_COLUMN_TYPES: readonly DfTableColumnType[];
interface DfTableColumn {
    /** Propiedad de cada fila; admite puntos (`titular.nombre`). */
    key: string;
    label: string;
    /** Cómo se muestra y se ordena el valor. Por defecto `text`. */
    type?: DfTableColumnType;
    /** Con `type: "map"`: valor de la fila → texto que se muestra (`{ "ADIF": "Organismo" }`). */
    map?: Record<string, string>;
    /**
     * Con `type: "badge"`: valor de la fila → variante de color de la insignia (`ok`, `warn`, `error`, `info`); un valor sin
     * entrada se pinta con la insignia neutra. El texto sale de `map` (o es el propio valor).
     */
    variants?: Record<string, DfBadgeVariant>;
    /**
     * Con `type: "link"`: destino del enlace; `{clave}` se sustituye por la propiedad de la fila (con puntos, codificada
     * para URL): `/ejecuciones/{id}`. Debe empezar por `/`, `#`, `http://` o `https://`. El texto es el valor de la celda.
     */
    href?: string;
    /**
     * Nombre de una plantilla `<ng-template dfCell="nombre" let-row>` de la app que pinta las celdas de esta columna.
     * El valor sigue siendo el de `key` para filtrar, ordenar y exportar; sin plantilla con ese nombre se pinta el texto.
     */
    template?: string;
    /** Si se puede ordenar pulsando la cabecera. Por defecto `true`. */
    sortable?: boolean;
    /** Peso relativo del ancho de la columna (1-12). Por defecto 1. */
    col?: number;
    /** Moneda de una columna `currency`; sin ella, la de la app. */
    currency?: string;
    /**
     * Muestra un filtro bajo la cabecera de esta columna: un cuadro de texto (contiene, sin mayúsculas ni
     * acentos), o un desplegable con las opciones en las columnas `map` y `boolean`.
     */
    filter?: boolean;
    /**
     * Deja la columna fija a la izquierda al desplazar la tabla en horizontal. Solo las primeras columnas
     * pueden ser fijas: una columna fija no puede ir detrás de una que no lo sea.
     */
    frozen?: boolean;
    /**
     * La celda se pinta como HTML (enlaces, insignias) en vez de texto. Solo en columnas `text`. El HTML pasa por el
     * sanitizador de Angular (sin scripts, `on*`, `style` ni `javascript:`); el filtro, la ordenación y el CSV usan el
     * texto sin etiquetas. Las insignias son `<span class="df-badge df-badge--ok|warn|error|info">`.
     */
    html?: boolean;
}
/** Exportación de la tabla a CSV (`exportCsv`). */
interface DfTableExport {
    /** Nombre del fichero, con o sin `.csv`. Por defecto, el `id` de la tabla. */
    filename?: string;
}
/** Botón por fila: al pulsarlo `<dynamic-form>` emite `tableAction` con la fila. */
interface DfTableAction {
    name: string;
    /** Texto del botón; con `icon` es solo el nombre accesible (y el tooltip si no hay `tooltip`). */
    label: string;
    /**
     * Botón de icono. Un nombre de `DF_TABLE_ICONS` (`view`, `edit`, `delete`, `download`, `add`, `check`, `close`) se
     * pinta como SVG; cualquier otro texto corto (un emoji, un símbolo) se pinta tal cual.
     */
    icon?: string;
    /** Texto emergente del botón. Por defecto, `label`. */
    tooltip?: string;
    /** Solo se muestra en las filas que cumplen la regla (`./campo` lee de la fila, el resto del modelo del formulario). */
    showWhen?: DfRule;
    /** Se muestra deshabilitado en las filas que cumplen la regla. */
    disabledWhen?: DfRule;
}
/** Iconos incluidos para `DfTableAction.icon`. */
declare const DF_TABLE_ICONS: readonly ["view", "edit", "delete", "download", "add", "check", "close"];
/**
 * De dónde salen las filas de una tabla: un servicio de la app (`DfTableProvider`).
 * `client`: el servicio devuelve todas las filas y la tabla filtra, ordena y pagina en el cliente.
 * `server`: el servicio devuelve una página cada vez (con el orden y el filtro que pida el usuario) y
 * el total de filas; necesita `pageSize`.
 */
interface DfTableSource {
    endpoint: string;
    mode?: 'client' | 'server';
    /** Campos del formulario cuyo valor se envía como parámetros; si cambia alguno, la tabla se recarga. */
    dependsOn?: string[];
    /**
     * `dependsOn` nombra claves del modelo que no son campos de este esquema: las rellena la app (por
     * ejemplo con los criterios de otro formulario al pulsar "Buscar"). El validador no las busca entre los campos.
     */
    externalParams?: boolean;
    /** Con `false` la tabla carga aunque algún parámetro de `dependsOn` esté vacío. Por defecto `true`. */
    requireParams?: boolean;
}
interface DfTableSort {
    key: string;
    direction?: 'asc' | 'desc';
}
/**
 * Tabla de datos de solo lectura, no un campo del formulario: no escribe nada en el modelo.
 * Las filas vienen de un servicio (`source`), del propio esquema (`rows`) o de una propiedad del
 * modelo (`dataKey`), que puede ser un array que llegue o cambie después. Filtro, orden y paginación
 * se hacen en el cliente, salvo con `source.mode: "server"`, donde los hace el servicio.
 */
interface DfTable {
    type: 'table';
    id: string;
    title?: string;
    description?: string;
    columns: DfTableColumn[];
    rows?: Record<string, unknown>[];
    /** Ruta (con puntos) del modelo raíz que contiene el array de filas. Tiene prioridad sobre `rows`. */
    dataKey?: string;
    /** Filas que carga un servicio. No se combina con `rows` ni `dataKey`. */
    source?: DfTableSource;
    /** Texto cuando la carga falla. */
    errorMessage?: string;
    /** Muestra un cuadro de búsqueda sobre el texto visible de las columnas. */
    filter?: boolean;
    filterLabel?: string;
    /**
     * Claves de la fila (con puntos) en las que también busca el cuadro de búsqueda, aunque no sean columnas visibles.
     * Solo cuenta en modo `client`; en `server` busca el servicio.
     */
    searchKeys?: string[];
    /** Filas por página. Sin él no hay paginación. */
    pageSize?: number;
    pageSizeOptions?: number[];
    /**
     * Orden inicial. Una lista de varios solo vale con `multiSort`: la primera manda y las siguientes desempatan.
     */
    sort?: DfTableSort | DfTableSort[];
    /**
     * Ordenar por varias columnas: Mayús + clic en una cabecera la añade al orden (o cambia su sentido, y a la
     * tercera la quita). Un clic sin Mayús ordena solo por esa columna. Con varias, la cabecera muestra su posición.
     */
    multiSort?: boolean;
    /**
     * Selección de filas; se emite `tableSelect`. `true` o `'single'`: una fila a la vez, con un clic.
     * `'multiple'`: una columna de casillas y una casilla en la cabecera que marca todas las filas filtradas
     * (en modo `server`, las de la página).
     */
    selectable?: boolean | 'single' | 'multiple';
    /**
     * Solo las filas que cumplen la regla se pueden seleccionar (`./campo` lee de la fila, el resto del modelo del
     * formulario). Las demás no tienen casilla activa ni responden al clic, y la casilla de la cabecera las salta.
     */
    selectableWhen?: DfRule;
    /**
     * Qué marca la casilla de la cabecera con `selectable: 'multiple'`: `filtered` (por defecto) todas las filas que
     * pasan el filtro, `page` solo las de la página visible. En modo `server` siempre es la página.
     */
    headerSelects?: 'filtered' | 'page';
    /**
     * Propiedad de la fila (con puntos) que la identifica. Con `selectable: 'multiple'` hace que la selección
     * sobreviva a cambiar de página, orden o filtro en modo `server`; sin ella se identifican por objeto y
     * esos cambios la vacían.
     */
    selectionKey?: string;
    /**
     * Pone en cada cabecera un botón para fijar o soltar la columna. Una columna fijada pasa al final del bloque de
     * columnas fijas y, al soltarla, vuelve a su sitio. Parte de lo que digan `columns[].frozen`; lo que elija el usuario
     * solo vive mientras la tabla está en pantalla.
     */
    pinnableColumns?: boolean;
    /**
     * El borde derecho de cada cabecera se arrastra para cambiar el ancho de la columna (o con las flechas
     * izquierda y derecha cuando tiene el foco; doble clic restablece los anchos). Desde el primer cambio los
     * anchos pasan a píxeles y la tabla se desplaza en horizontal si no cabe. Se recuerda con `persistState`.
     */
    resizableColumns?: boolean;
    /**
     * Las cabeceras se pueden arrastrar para cambiar el orden de las columnas (o con Alt + flecha izquierda o
     * derecha). Una columna fija solo se mueve entre las fijas y una normal entre las normales. Se recuerda con
     * `persistState`.
     */
    reorderableColumns?: boolean;
    /**
     * Recuerda el orden, el buscador, los filtros de columna, las filas por página y las columnas fijadas entre
     * visitas. `'session'` (o `true`) lo guarda en `sessionStorage`; `'local'`, en `localStorage`. No guarda la
     * página ni la selección.
     */
    persistState?: boolean | 'session' | 'local';
    /** Clave con la que se guarda el estado; por defecto, el `id` de la tabla. Cámbiala si dos pantallas comparten `id`. */
    stateKey?: string;
    /** Botón «Exportar CSV». `true` usa el `id` como nombre del fichero. */
    exportCsv?: boolean | DfTableExport;
    actions?: DfTableAction[];
    emptyMessage?: string;
    cssClass?: string;
    logic?: DfConditionalLogic;
}
/**
 * Hueco para un bloque de la app entre los campos del esquema (una vista previa, un resumen, un panel). No es un campo:
 * no tiene `key` ni toca el modelo. La app lo rellena con `<ng-template dfSlot="nombre">` dentro de `<dynamic-form>`.
 * Ocupa la fila entera. Puede ir en la raíz o dentro de un grupo, no dentro de una lista repetible.
 */
interface DfSlot {
    type: 'slot';
    name: string;
    cssClass?: string;
    logic?: DfConditionalLogic;
}
type DfNode = DfField | DfGroup | DfArray | DfTable | DfSlot;
declare function isDfSlot(node: DfNode): node is DfSlot;
interface DfFormLayout {
    columns?: number;
    gap?: string;
    /**
     * Valor por defecto de `logic.resetOnHide` en todo el esquema: con `false` un campo oculto conserva su valor en el
     * modelo. Un `logic.resetOnHide` propio de un nodo manda sobre este, y este sobre `defaultResetOnHide` de la app.
     */
    resetOnHide?: boolean;
}
interface DfFormSchema {
    version: '1.0';
    id: string;
    title?: string;
    description?: string;
    layout?: DfFormLayout;
    fields: DfNode[];
    meta?: Record<string, unknown>;
}
declare function isDfGroup(node: DfNode): node is DfGroup;
declare function isDfArray(node: DfNode): node is DfArray;
declare function isDfTable(node: DfNode): node is DfTable;
/** Un campo de entrada: ni grupo, ni lista repetible, ni tabla. */
declare function isDfField(node: DfNode): node is DfField;

/**
 * Importes: parseo de lo que escribe el usuario, formato para mostrar y conversión a letra
 * (como en cheques y documentos oficiales), en formato español o inglés y para cualquier moneda.
 */
/** 'es': 1.500,75 (punto de miles, coma decimal) · 'en': 1,500.75 (coma de miles, punto decimal). */
type DfNumberFormat = 'es' | 'en';
/** Idioma del importe en letra. */
type DfWordsLanguage = 'es' | 'en';
/** Resultado de leer un importe escrito por el usuario. */
type DfAmountParse = {
    ok: true;
    value: number | null;
} | {
    ok: false;
    error: 'format' | 'decimals';
};
/**
 * Nombres de la moneda para escribir el importe en letra. `feminine` y `centFeminine` solo
 * cuentan en español: "una libra", "doscientas libras".
 */
interface DfCurrencyWords {
    singular: string;
    plural: string;
    centSingular: string;
    centPlural: string;
    feminine?: boolean;
    centFeminine?: boolean;
}
/** Nombres incluidos. Para otra moneda, pasa currencyWords. */
declare const CURRENCY_WORDS: Record<DfWordsLanguage, Record<string, DfCurrencyWords>>;
declare const NUMBER_FORMATS: readonly DfNumberFormat[];
declare const WORDS_LANGUAGES: readonly DfWordsLanguage[];
/** Código ISO 4217 bien formado (EUR, GBP, USD…). */
declare const isCurrencyCode: (code: unknown) => code is string;
/** Ejemplo de importe en el formato indicado, para mensajes de error. */
declare const amountExample: (format?: DfNumberFormat) => string;
/** Símbolo corto de la moneda (€, £, $; CHF si no tiene uno propio). */
declare function currencySymbol(currency: string): string;
/**
 * Lee un importe en el formato indicado: separador de miles en grupos de 3, separador decimal y
 * hasta dos decimales, sin negativos. Solo ignora los espacios de los extremos y el símbolo o
 * código de la moneda al principio o al final; un espacio en medio ("15 00") es error de formato.
 * Un texto mal formado es error de formato aunque solo tenga dígitos y separadores ("5,", "1,2,3");
 * el error de decimales queda para un importe bien formado con más de dos. Un texto vacío es un
 * importe vacío (null).
 */
declare function parseAmount(text: string, format?: DfNumberFormat, currency?: string): DfAmountParse;
/**
 * Error de un valor de importe tal como lo guarda el control: number si es válido, el texto
 * escrito si no se pudo leer, o vacío. Lo usan los validadores currencyFormat y currencyDecimals.
 */
declare function amountError(value: unknown, format?: DfNumberFormat, currency?: string): 'format' | 'decimals' | null;
/** "1.500,75 €" (es) o "£1,500.75" (en): miles agrupados siempre, también con 4 cifras. */
declare function formatAmount(value: number, currency?: string, format?: DfNumberFormat): string;
/** "1.500,75" (es) o "1,500.75" (en) sin símbolo: miles agrupados siempre y hasta dos decimales. */
declare function formatNumber(value: number, format?: DfNumberFormat): string;
/** "1500,75" (es) o "1500.75" (en): versión editable, sin miles ni símbolo, que parseAmount vuelve a leer. */
declare function editableAmount(value: number, format?: DfNumberFormat): string;
/**
 * Número entero (0 – 999.999.999.999) en letra. Con beforeNoun usa "un"/"veintiún"; con
 * feminine, "una"/"veintiuna"/"doscientas". "Millón" es masculino: "doscientos millones de libras".
 */
declare function integerToWords(n: number, beforeNoun?: boolean, feminine?: boolean): string;
/** Número entero (0 – 999.999.999.999) en inglés británico: "one thousand and five". */
declare function integerToWordsEn(n: number): string;
interface DfAmountWordsOptions {
    /** Código ISO 4217 de la moneda incluida (EUR, GBP, USD). Por defecto, EUR. */
    currency?: string;
    /** Idioma de la letra. Por defecto, español. */
    language?: DfWordsLanguage;
    /** Nombres de la moneda; obligatorios para monedas que no estén en CURRENCY_WORDS. */
    words?: DfCurrencyWords;
}
/**
 * Importe en letra, en minúsculas:
 * - 1250.5 EUR, es → "mil doscientos cincuenta euros con cincuenta céntimos"
 * - 1250.5 GBP, en → "one thousand two hundred and fifty pounds and fifty pence"
 *
 * Devuelve '' si el importe no está entre 0 y 999.999.999.999,99 o si no hay nombres para la moneda.
 */
declare function amountToWords(amount: number, options?: DfAmountWordsOptions): string;

/**
 * Longitud de texto para validation.maxLength. Por defecto ('weighted') cada carácter no ASCII
 * (ñ, á, ü, €…) cuenta 2, porque el backend mide el límite como si fueran bytes; con 'chars'
 * cada carácter cuenta 1.
 */
type DfMaxLengthMode = 'weighted' | 'chars';
/** Longitud según el modo. Recorre code points, así que un emoji cuenta como un solo carácter (2). */
declare function textLength(text: string, mode?: DfMaxLengthMode): number;
/** Recorta el texto para que su longitud no pase de max, sin partir caracteres. */
declare function truncateToLength(text: string, max: number, mode?: DfMaxLengthMode): string;

/**
 * Textos fijos de las tablas. Los que llevan `{llaves}` se rellenan al mostrarlos:
 * `{label}` (columna), `{text}` (búsqueda), `{n}` (filas marcadas), `{from}`, `{to}` y `{total}`.
 */
interface DfTableTexts {
    search: string;
    actions: string;
    loading: string;
    retry: string;
    /** Texto cuando no hay filas y la tabla no define `emptyMessage`. */
    empty: string;
    /** Texto cuando la carga falla y la tabla no define `errorMessage`. */
    error: string;
    /** La búsqueda no encuentra nada. Admite `{text}`. */
    noResults: string;
    /** Los filtros de columna no dejan ninguna fila. */
    noResultsFiltered: string;
    rowsPerPage: string;
    previousPage: string;
    nextPage: string;
    /** Rango de la página. Admite `{from}`, `{to}` y `{total}`. */
    range: string;
    /** Opción «sin filtro» del desplegable de una columna. */
    all: string;
    /** Etiqueta del filtro de una columna. Admite `{label}`. */
    filterBy: string;
    /** Botón de la cabecera de una columna (`pinnableColumns`). Admite `{label}`. */
    pinColumn: string;
    unpinColumn: string;
    /** Pista de una cabecera que se puede arrastrar (`reorderableColumns`). */
    reorderHint: string;
    /** Borde de la cabecera que se arrastra (`resizableColumns`). Admite `{label}`. */
    resizeColumn: string;
    selectAll: string;
    selectRow: string;
    exportCsv: string;
    /** Con filas marcadas. Admite `{n}`. */
    exportSelection: string;
    exporting: string;
    exportFailed: string;
}
/** Juego completo en inglés: `provideDynamicForms({ tableTexts: EN_TABLE_TEXTS })`. */
declare const EN_TABLE_TEXTS: DfTableTexts;

/** Resultado de un validador: true == válido (semántica de Formly). */
type DfValidatorResult = boolean | Promise<boolean> | Observable<boolean>;
type DfValidatorFn = (control: AbstractControl, args?: Record<string, unknown>, field?: FormlyFieldConfig) => DfValidatorResult;
type DfMessageFn = (args: Record<string, unknown> | undefined, field: FormlyFieldConfig) => string;
interface DfValidatorDefinition {
    name: string;
    async?: boolean;
    validate: DfValidatorFn;
    message: string | DfMessageFn;
}
/** Resolver de options.source === 'remote'. Lo implementa la app consumidora. */
interface DfOptionsProvider {
    load(endpoint: string, params: Record<string, unknown>): Observable<DfOption[]>;
}
/**
 * Tema visual. Decide qué componente Formly renderiza cada tipo del contrato
 * y qué providers (p. ej. FormlyMaterialModule) hay que registrar.
 */
interface DfTheme {
    name: string;
    /** tipo del contrato → nombre de tipo Formly */
    typeMap: Partial<Record<DfFieldType, string>>;
    /** wrappers por defecto para cada campo (p. ej. ['df-field']) */
    fieldWrappers?: string[];
    /** wrappers de un tipo concreto del contrato; sustituyen a `fieldWrappers` (p. ej. { checkbox: [] }) */
    typeWrappers?: Partial<Record<DfFieldType, string[]>>;
    /** wrapper para grupos (fieldset) */
    groupWrapper?: string;
    /** providers adicionales (importProvidersFrom(FormlyMaterialModule), etc.) */
    providers?: (Provider | EnvironmentProviders)[];
    /** tipos/wrappers Formly que el propio tema registra */
    formlyConfig?: ConfigOption;
    /** clase CSS añadida al host del formulario */
    hostClass?: string;
    /** props por tipo que el tema necesita (p. ej. multiselect → { multiple: true }) */
    typeProps?: Partial<Record<DfFieldType, Record<string, unknown>>>;
}
type DfValidationMessage = string | ((error: unknown, field: FormlyFieldConfig) => string);
/**
 * Valores por defecto de los campos type currency. Cada campo puede cambiarlos con sus props
 * (currency, numberFormat, wordsLanguage, amountInWords, wordsUppercase).
 */
interface DfCurrencyConfig {
    /** Código ISO 4217. Por defecto, EUR. */
    code?: string;
    /** 'es' (1.500,75) o 'en' (1,500.75). Por defecto, 'es'. */
    numberFormat?: DfNumberFormat;
    /** Idioma del importe en letra. Por defecto, el de numberFormat. */
    wordsLanguage?: DfWordsLanguage;
    /** Escribir el importe en letra bajo el campo. Por defecto, true. */
    amountInWords?: boolean;
    /** Letra en mayúsculas. Por defecto, true. */
    wordsUppercase?: boolean;
}
interface DynamicFormsConfig {
    theme?: DfTheme;
    types?: ConfigOption['types'];
    wrappers?: ConfigOption['wrappers'];
    validators?: DfValidatorDefinition[];
    messages?: Record<string, DfValidationMessage>;
    defaultResetOnHide?: boolean;
    strictSchema?: boolean;
    optionsProvider?: Type<DfOptionsProvider>;
    /** Resolver de `table.source`. */
    tableProvider?: Type<DfTableProvider>;
    /** Cómo cuenta validation.maxLength: 'weighted' (por defecto; ñ, á… cuentan 2) o 'chars'. */
    maxLengthMode?: DfMaxLengthMode;
    /** Moneda y formato por defecto de los campos type currency. */
    currency?: DfCurrencyConfig;
    /** Textos fijos de las tablas ("Buscar", "Filas por página"…); lo que no se indique queda en español. */
    tableTexts?: Partial<DfTableTexts>;
}
interface DfResolvedConfig {
    theme: DfTheme;
    defaultResetOnHide: boolean;
    strictSchema: boolean;
    maxLengthMode: DfMaxLengthMode;
    currency: Required<DfCurrencyConfig>;
    tableTexts: DfTableTexts;
}
type DfFormStatus = 'VALID' | 'INVALID' | 'PENDING' | 'DISABLED';
interface DfSubmitEvent<T = Record<string, unknown>> {
    model: T;
    form: FormGroup;
    schema: DfFormSchema;
}
/** Lo que la tabla pide al servicio. En modo `client` solo importan el endpoint y los `params`. */
interface DfTableRequest {
    /** Página que se pide, desde 0. Siempre 0 en modo `client`. */
    page: number;
    /** Filas por página; null en modo `client`. */
    pageSize: number | null;
    /** Orden elegido por el usuario (o el inicial del esquema); null en modo `client`. */
    sort: {
        key: string;
        direction: 'asc' | 'desc';
    } | null;
    /**
     * Todo el orden, de la columna principal a la última que desempata (`sort` es la primera, o null). Solo tiene
     * más de una con `multiSort`; `[]` en modo `client`.
     */
    sorts: {
        key: string;
        direction: 'asc' | 'desc';
    }[];
    /** Texto del cuadro de búsqueda; vacío en modo `client`. */
    filter: string;
    /**
     * Filtros por columna que el usuario ha rellenado (`key` de la columna → texto escrito o, en las columnas
     * `map` y `boolean`, el valor elegido: la clave del `map`, o `"true"`/`"false"`). Sin los vacíos; `{}` en modo `client`.
     */
    columnFilters: Record<string, string>;
    /** Valor de los campos de `source.dependsOn` (con su nombre, sin el `./` de las rutas relativas). */
    params: Record<string, unknown>;
}
/** Respuesta paginada del servicio: las filas de la página pedida y el total de filas que cumplen el filtro. */
interface DfTablePage {
    rows: Record<string, unknown>[];
    total: number;
}
/**
 * Resolver de `table.source`. Lo implementa la app consumidora. Puede devolver un array de filas, o
 * `{ rows, total }`; en modo `server` conviene `{ rows, total }` (con un array, el total son las filas recibidas).
 */
interface DfTableProvider {
    load(endpoint: string, request: DfTableRequest): Observable<DfTablePage | Record<string, unknown>[]>;
}
/**
 * Un enlace de una columna `link` pulsado con el botón izquierdo (`tableNavigate`). Para navegar dentro de la app sin
 * recargar la página, llama a `originalEvent.preventDefault()` y navega tú (`router.navigateByUrl(href)`); si no lo
 * haces, el navegador sigue el enlace.
 */
interface DfTableNavigateEvent {
    tableId: string;
    /** `key` de la columna. */
    column: string;
    /** Destino ya resuelto con los valores de la fila. */
    href: string;
    row: Record<string, unknown>;
    originalEvent: MouseEvent;
}
/** Un botón de fila de una tabla pulsado (`tableAction`). */
interface DfTableActionEvent {
    tableId: string;
    action: string;
    row: Record<string, unknown>;
}
/**
 * Cambio de selección de una tabla (`tableSelect`). `rows` es siempre la selección completa. En una tabla
 * de selección única `row` es la fila elegida (null si se deselecciona); en una `multiple`, `row` es null.
 * `changed` dice qué filas han cambiado con este evento y en qué sentido, en cualquier modo.
 */
interface DfTableSelectEvent {
    tableId: string;
    row: Record<string, unknown> | null;
    rows: Record<string, unknown>[];
    /**
     * Lo que ha cambiado: `selected: true` son filas que se acaban de marcar (una al pulsar, varias con Mayús+clic o con la
     * casilla de la cabecera) y `selected: false` filas que se acaban de desmarcar (también las que se pierden al recargar
     * la tabla). Con selección única, la fila elegida es la marcada; la que dejó de estarlo no se lista.
     */
    changed: {
        rows: Record<string, unknown>[];
        selected: boolean;
    };
}
interface DfSchemaIssue {
    path: string;
    message: string;
}
interface DfSchemaValidationResult {
    valid: boolean;
    errors: DfSchemaIssue[];
}
declare class DynamicFormsSchemaError extends Error {
    readonly issues: DfSchemaIssue[];
    constructor(issues: DfSchemaIssue[]);
}

declare const DYNAMIC_FORMS_CONFIG: InjectionToken<DfResolvedConfig>;
/** multi: true — cada provider aporta un array de definiciones. */
declare const DF_VALIDATORS: InjectionToken<DfValidatorDefinition[][]>;
declare const DF_OPTIONS_PROVIDER: InjectionToken<DfOptionsProvider>;
declare const DF_TABLE_PROVIDER: InjectionToken<DfTableProvider>;

/**
 * Inicializa @core/dynamic-forms en la app consumidora.
 *
 *   bootstrapApplication(App, { providers: [provideDynamicForms()] });
 *   bootstrapApplication(App, { providers: [provideDynamicForms({ theme: materialTheme([...]) })] });
 */
declare function provideDynamicForms(config?: DynamicFormsConfig): EnvironmentProviders;

/** Mensajes built-in (ValidationContract.builtIn). */
declare const DEFAULT_VALIDATION_MESSAGES: Record<string, DfValidationMessage>;
/** Juego completo en inglés: `provideDynamicForms({ messages: EN_VALIDATION_MESSAGES })`. */
declare const EN_VALIDATION_MESSAGES: Record<string, DfValidationMessage>;
declare function toFormlyMessages(messages: Record<string, DfValidationMessage>): {
    name: string;
    message: string | ((error: unknown, field: FormlyFieldConfig) => string);
}[];

declare const DF_PLAIN_TYPE_NAMES: {
    readonly input: "df-input";
    readonly select: "df-select";
    readonly textarea: "df-textarea";
    readonly checkbox: "df-checkbox";
    readonly radio: "df-radio";
    readonly hidden: "df-hidden";
    readonly currency: "df-currency";
    readonly repeat: "df-repeat";
    readonly table: "df-table";
    readonly slot: "df-slot";
};
/**
 * Tema por defecto: sin dependencias de UI, componentes propios de la librería.
 * Estilos: @use '@core/dynamic-forms/styles/plain';
 */
declare const PLAIN_THEME: DfTheme;

declare function materialTheme(providers?: (Provider | EnvironmentProviders)[], overrides?: Partial<DfTheme>): DfTheme;
declare function bootstrapTheme(providers?: (Provider | EnvironmentProviders)[], overrides?: Partial<DfTheme>): DfTheme;

/**
 * Adapter Layer: SchemaContract (JSON) → FormlyFieldConfig[].
 * Única pieza de la librería que conoce Formly en profundidad.
 */
declare class FormSchemaAdapterService {
    private readonly config;
    private readonly registry;
    private readonly schemaValidator;
    private readonly evaluator;
    private optionsProvider;
    private readonly formlyConfig;
    /** Tipos declarados en forRoot(): se leen de FORMLY_CONFIG porque Formly los aplica en diferido. */
    private readonly declaredTypes;
    /** `layout.resetOnHide` del esquema que se está traduciendo (toFormly es síncrono). */
    private schemaResetOnHide;
    private readonly remoteCache;
    private readonly subscriptions;
    /**
     * Registra (o sustituye) el proveedor de `options.source = 'remote'` en tiempo de ejecución. Sirve cuando
     * `provideDynamicForms` está en los providers de una ruta y no llega a este servicio (que es `root`), como el
     * `DF_OPTIONS_PROVIDER`. Vacía la caché de opciones: las siguientes cargas ya van al proveedor nuevo.
     */
    registerOptionsProvider(provider: DfOptionsProvider): void;
    /** Valida, sanitiza y transforma. Lanza DynamicFormsSchemaError en modo estricto. */
    toFormly(schema: DfFormSchema): FormlyFieldConfig[];
    sanitize(schema: DfFormSchema): DfFormSchema;
    private sanitizeTable;
    /** Copia profunda de datos del esquema: sin claves peligrosas ni funciones, y sin caracteres de control en los textos. */
    private cleanValue;
    private sanitizeProps;
    private mapNode;
    /** Lista repetible: un tipo `df-repeat` (FormArray) cuyas filas son un grupo con los campos del nodo. */
    private mapArray;
    /** Hueco para una plantilla de la app: un campo sin key (no crea control) del tipo `df-slot`. */
    private mapSlot;
    /** Tabla de datos de solo lectura: un campo sin key (no crea control) del tipo `df-table`. */
    private mapTable;
    /** Resuelve la moneda y el formato de un total con los del campo que suma (o con los de la app). */
    private resolveTotal;
    private findRowField;
    private tableColumn;
    private arrayValidators;
    private mapGroup;
    /**
     * Wrappers de un campo. Manda, por este orden: `theme.typeWrappers` del tipo del contrato (el tema decide, aunque
     * el paquete UI declare wrappers en sus tipos), los `wrappers` del tipo Formly registrado (un tipo propio con
     * `wrappers: []` se pinta sin el wrapper del tema) y `theme.fieldWrappers`.
     */
    private fieldWrappers;
    private mapField;
    private inputTypeProps;
    private className;
    /** Validadores síncronos: los alias del esquema más los built-in de los tipos email y currency. */
    private fieldValidators;
    /**
     * Moneda y formato de un campo currency: lo que diga el campo (si es válido) o la config de la app.
     * El idioma de la letra sigue al numberFormat del campo si el campo lo cambia y no fija wordsLanguage.
     */
    private currencyProps;
    /**
     * Formly valida props.maxLength contando caracteres. En modo 'weighted' (ñ, á… cuentan 2) se añade
     * un validador con el mismo error { maxLength: { requiredLength, actualLength } }, así que el
     * mensaje built-in sigue funcionando. Como la longitud con peso nunca es menor, no se contradicen.
     */
    private withWeightedMaxLength;
    /** Mensajes por campo: resuelve {{x}} contra las props del campo y los args del validador del mismo nombre. */
    private mapMessages;
    private mapValidators;
    private resolveMessage;
    private applyOptions;
    private remoteOptions;
    /** Cascading: cuando cambia cualquier padre, el hijo se vacía. */
    private resetOnParentChange;
    private applyLogic;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormSchemaAdapterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormSchemaAdapterService>;
}
/** Helper exportado para tests/consumidores: ¿un valor de expresión es observable? */
declare const isObservableOptions: (v: unknown) => v is Observable<DfOption[]>;

/**
 * Validación estructural del SchemaContract sin dependencias externas (sin ajv).
 * Comprueba lo que de verdad rompe el render: tipos, keys, referencias cruzadas
 * en condiciones/dependsOn y aliases de validadores no registrados.
 */
declare class SchemaValidatorService {
    private readonly registry;
    private readonly formlyConfig;
    /**
     * Formly aplica la config de forRoot() en diferido (al crear el primer formulario), y aquí se valida
     * antes; por eso se leen también los tipos declarados en FORMLY_CONFIG.
     */
    private readonly declaredTypes;
    validate(schema: unknown): DfSchemaValidationResult;
    /** Claves de los campos y listas de un nivel, atravesando grupos pero no listas (cada fila tiene las suyas). */
    private collectKeys;
    /** `row`: contexto de la lista repetible que contiene los nodos (claves de la fila y su disposición). */
    private visitNodes;
    private validateGroup;
    private validateArray;
    private validateTable;
    private validateTableSource;
    private validateTotals;
    private validateField;
    private validateLogic;
    /** Comprueba que una referencia a otro campo existe: la raíz, o la fila si empieza por `./`. */
    private checkRef;
    private validateRule;
    /** Props de un campo currency que vienen del backend: si no son válidas, el adaptador las ignoraría. */
    private validateCurrencyProps;
    /** Tipos del contrato o tipos registrados en Formly con provideDynamicForms({ types }). */
    private isKnownType;
    static ɵfac: i0.ɵɵFactoryDeclaration<SchemaValidatorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SchemaValidatorService>;
}

/**
 * Catálogo de validadores de negocio referenciables por alias desde el esquema.
 * Se alimenta de DF_VALIDATORS (multi) y admite registro en tiempo de ejecución.
 */
declare class ValidatorRegistryService {
    private readonly registry;
    constructor();
    register(definition: DfValidatorDefinition): void;
    get(name: string): DfValidatorDefinition | undefined;
    has(name: string): boolean;
    names(): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidatorRegistryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ValidatorRegistryService>;
}

/** Lee `a.b.c` de un objeto sin lanzar. */
declare function getByPath(model: unknown, path: string): unknown;
/** Prefijo de una ruta que lee del contexto externo (`<dynamic-form [context]>`): `ctx.modo`. */
declare const CONTEXT_PREFIX = "ctx.";
/** Prefijo de una ruta relativa a la fila actual de una lista repetible: `./cantidad`. */
declare const RELATIVE_PREFIX = "./";
/**
 * Evaluador declarativo (sin eval) del ConditionalLogicContract.
 */
declare class ConditionEvaluatorService {
    /**
     * `model` es el modelo raíz. `local` es el objeto de la fila actual cuando la regla está dentro de una
     * lista repetible: las rutas `./campo` se leen de ahí. `context` es el objeto externo de la app: las rutas `ctx.nombre`
     * se leen de él. El resto de rutas, de `model`.
     */
    evaluate(rule: DfRule | undefined, model: unknown, local?: unknown, context?: unknown): boolean;
    private isCondition;
    private evaluateGroup;
    private evaluateCondition;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConditionEvaluatorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConditionEvaluatorService>;
}

declare function isValidDni(raw: unknown): boolean;
declare function isValidNie(raw: unknown): boolean;
declare function isValidCif(raw: unknown): boolean;
declare function isValidIban(raw: unknown): boolean;
declare const isValidPhoneES: (raw: unknown) => boolean;
declare function isValidPostalCodeES(raw: unknown): boolean;
declare const BUSINESS_VALIDATORS: DfValidatorDefinition[];

/** Contexto de una plantilla de celda: `let-row`, o `let-value="value"` y `let-column="column"`. */
interface DfCellContext {
    $implicit: Record<string, unknown>;
    row: Record<string, unknown>;
    /** Valor de la propiedad de la columna en esa fila. */
    value: unknown;
    /** `key` de la columna. */
    column: string;
}
/**
 * Plantilla propia para las celdas de las columnas con `template: "nombre"`:
 *
 *   <dynamic-form [schema]="schema">
 *     <ng-template dfCell="estado" let-row let-value="value"><app-estado [value]="value" /></ng-template>
 *   </dynamic-form>
 */
declare class DfCellDirective {
    readonly name: i0.InputSignal<string>;
    readonly template: TemplateRef<DfCellContext>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DfCellDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DfCellDirective, "ng-template[dfCell]", never, { "name": { "alias": "dfCell"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Plantilla propia para una tabla sin filas (en lugar de `emptyMessage`). `dfEmpty="id"` es para la tabla con ese `id`;
 * sin valor vale para todas las que no tengan una propia. El contexto es `let-table` (el `id` de la tabla).
 */
declare class DfEmptyDirective {
    readonly table: i0.InputSignal<string>;
    readonly template: TemplateRef<{
        $implicit: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DfEmptyDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DfEmptyDirective, "ng-template[dfEmpty]", never, { "table": { "alias": "dfEmpty"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Clave de `options.formState` por la que `<dynamic-form>` entrega a las tablas sus plantillas. */
declare const DF_TABLE_SLOTS = "dfTableSlots";
interface DfTableSlots {
    cell(name: string): TemplateRef<DfCellContext> | null;
    empty(tableId: string): TemplateRef<{
        $implicit: string;
    }> | null;
}

/** Contexto de una plantilla de slot: `let-model` (el modelo raíz del formulario). */
interface DfSlotContext {
    $implicit: Record<string, unknown>;
    model: Record<string, unknown>;
    /** `name` del nodo `slot`. */
    name: string;
}
/**
 * Plantilla propia que se pinta donde el esquema tiene un nodo `{ "type": "slot", "name": "resumen" }`, entre los
 * demás campos:
 *
 *   <dynamic-form [schema]="schema" [(model)]="model">
 *     <ng-template dfSlot="resumen" let-model><app-resumen [datos]="model" /></ng-template>
 *   </dynamic-form>
 */
declare class DfSlotDirective {
    readonly name: i0.InputSignal<string>;
    readonly template: TemplateRef<DfSlotContext>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DfSlotDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DfSlotDirective, "ng-template[dfSlot]", never, { "name": { "alias": "dfSlot"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Clave de `options.formState` por la que `<dynamic-form>` entrega a los nodos `slot` sus plantillas. */
declare const DF_SLOTS = "dfSlots";
interface DfSlots {
    get(name: string): TemplateRef<DfSlotContext> | null;
}

type Model = Record<string, unknown>;
/**
 * Fachada pública. Encapsula el ciclo de vida de Formly:
 *
 *   <dynamic-form [schema]="schema" [(model)]="model" (formSubmit)="onSubmit($event)">
 *     <button dfActions type="submit">Guardar</button>
 *   </dynamic-form>
 */
declare class DynamicFormComponent {
    private readonly adapter;
    private readonly config;
    private readonly destroyRef;
    readonly schema: i0.InputSignal<DfFormSchema>;
    readonly model: i0.ModelSignal<Model>;
    readonly submitLabel: i0.InputSignal<string>;
    readonly showDefaultActions: i0.InputSignal<boolean>;
    readonly validateOnInit: i0.InputSignal<boolean>;
    /**
     * Cuándo se muestran los errores: `'touched'` (por defecto) al tocar el campo o enviar; `'always'` desde que el
     * campo existe, también los que aparecen después (secciones condicionales, filas nuevas).
     */
    /**
     * Datos externos al formulario para las condiciones: `{ "field": "ctx.modo", ... }` lee `context().modo`. Si el objeto
     * cambia, las condiciones se reevalúan.
     */
    readonly context: i0.InputSignal<Record<string, unknown>>;
    readonly showErrors: i0.InputSignal<"touched" | "always">;
    readonly formSubmit: i0.OutputEmitterRef<DfSubmitEvent<Record<string, unknown>>>;
    readonly formInvalidSubmit: i0.OutputEmitterRef<DfSubmitEvent<Record<string, unknown>>>;
    readonly valueChange: i0.OutputEmitterRef<Model>;
    readonly statusChange: i0.OutputEmitterRef<DfFormStatus>;
    readonly formReady: i0.OutputEmitterRef<FormGroup<any>>;
    /** Un botón de fila de una tabla (`table.actions`) pulsado. */
    readonly tableAction: i0.OutputEmitterRef<DfTableActionEvent>;
    /** Una fila de una tabla `selectable` seleccionada, o null al deseleccionarla. */
    readonly tableSelect: i0.OutputEmitterRef<DfTableSelectEvent>;
    /** Un enlace de una columna `link` pulsado: `originalEvent.preventDefault()` y navega tú para no recargar la página. */
    readonly tableNavigate: i0.OutputEmitterRef<DfTableNavigateEvent>;
    private readonly cellTemplates;
    private readonly emptyTemplates;
    private readonly slotTemplates;
    readonly form: FormGroup<{}>;
    readonly options: FormlyFormOptions;
    readonly fields: i0.Signal<FormlyFieldConfig<_ngx_formly_core.FormlyFieldProps & {
        [additionalProperties: string]: any;
    }>[]>;
    readonly title: i0.Signal<string | undefined>;
    readonly description: i0.Signal<string | undefined>;
    readonly formId: i0.Signal<string>;
    readonly hostClass: string;
    /** layout.gap del esquema → --df-grid-gap (solo longitudes CSS simples). */
    get gridGap(): string | null;
    private initialModel;
    constructor();
    get valid(): boolean;
    onModelChange(next: Model): void;
    submit(): void;
    reset(next?: Model): void;
    /**
     * Marca las filas que marcaría la casilla de la cabecera de una tabla `selectable: 'multiple'` (en modo `server`,
     * las de la página). Sin `tableId` actúa sobre todas las tablas. Emite `tableSelect` con `changed`.
     */
    selectAll(tableId?: string): void;
    /** Vacía la selección de una tabla (también la de otras páginas). Sin `tableId` actúa sobre todas las tablas. */
    clearSelection(tableId?: string): void;
    private tableControls;
    markAllAsTouched(): void;
    /**
     * Vuelve a ejecutar los validadores de todos los controles. Para validadores que leen estado fuera del
     * formulario (una señal, un servicio): llámalo cuando ese estado cambie.
     */
    revalidate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DynamicFormComponent, "dynamic-form", never, { "schema": { "alias": "schema"; "required": true; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "submitLabel": { "alias": "submitLabel"; "required": false; "isSignal": true; }; "showDefaultActions": { "alias": "showDefaultActions"; "required": false; "isSignal": true; }; "validateOnInit": { "alias": "validateOnInit"; "required": false; "isSignal": true; }; "context": { "alias": "context"; "required": false; "isSignal": true; }; "showErrors": { "alias": "showErrors"; "required": false; "isSignal": true; }; }, { "model": "modelChange"; "formSubmit": "formSubmit"; "formInvalidSubmit": "formInvalidSubmit"; "valueChange": "valueChange"; "statusChange": "statusChange"; "formReady": "formReady"; "tableAction": "tableAction"; "tableSelect": "tableSelect"; "tableNavigate": "tableNavigate"; }, ["cellTemplates", "emptyTemplates", "slotTemplates"], ["[dfHeader]", "[dfActions]"], true, never>;
}

/** text | email | password | number | date */
declare class InputFieldComponent extends FieldType<FieldTypeConfig> {
    get inputType(): string;
    /** Modo de validation.maxLength (en 'weighted' la ñ y los acentos cuentan 2). */
    get mode(): DfMaxLengthMode;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputFieldComponent, "df-input-field", never, {}, {}, never, never, true, never>;
}

/** select | multiselect — acepta options estáticas u Observable (remote/cascading). */
declare class SelectFieldComponent extends FieldType<FieldTypeConfig> {
    private lastRaw;
    private lastObs;
    get options$(): Observable<DfOption[]>;
    get multiple(): boolean;
    trackValue(_: number, o: DfOption): unknown;
    /**
     * Valor de la opción del placeholder: el mismo "vacío" que tenga el modelo (undefined al empezar,
     * null tras un reset en cascada) para que quede seleccionada. Con [ngValue]="null" fijo, un campo
     * sin valor se pintaba en blanco.
     */
    get placeholderValue(): null | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectFieldComponent, "df-select-field", never, {}, {}, never, never, true, never>;
}

declare class TextareaFieldComponent extends FieldType<FieldTypeConfig> {
    get rows(): number;
    /**
     * Con validation.maxLength se pinta el contador "N/máx" bajo la caja y se bloquea en el límite.
     * En modo 'weighted' (por defecto) la ñ y los acentos cuentan 2, igual que en el validador.
     */
    get maxLength(): number | undefined;
    get mode(): DfMaxLengthMode;
    get length(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextareaFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextareaFieldComponent, "df-textarea-field", never, {}, {}, never, never, true, never>;
}

/** La label se pinta aquí (el wrapper la oculta con hideLabel). */
declare class CheckboxFieldComponent extends FieldType<FieldTypeConfig> {
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxFieldComponent, "df-checkbox-field", never, {}, {}, never, never, true, never>;
}

/**
 * Sin [formControl]: con el value accessor de Angular, [disabled] en el input lo
 * captura FormControlDirective y las opciones deshabilitadas seguían pulsables.
 */
declare class RadioFieldComponent extends FieldType<FieldTypeConfig> {
    private lastRaw;
    private lastObs;
    get options$(): Observable<DfOption[]>;
    get inline(): boolean;
    isDisabled(opt: DfOption): boolean;
    select(value: DfOption['value']): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioFieldComponent, "df-radio-field", never, {}, {}, never, never, true, never>;
}

/** Mantiene el valor en el modelo sin pintarse (ids de proceso, tokens…). */
declare class HiddenFieldComponent extends FieldType<FieldTypeConfig> {
    static ɵfac: i0.ɵɵFactoryDeclaration<HiddenFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HiddenFieldComponent, "df-hidden-field", never, {}, {}, never, never, true, never>;
}

/**
 * Importe. Mientras se edita muestra el texto tal cual ("1500,75"); al salir lo formatea
 * ("1.500,75 €" o "£1,500.75") y debajo escribe el importe en letra. El modelo guarda un number; si
 * el texto no se puede leer, guarda el texto para que los validadores currencyFormat/currencyDecimals
 * lo marquen como inválido.
 *
 * Props (el adaptador las resuelve con la config de provideDynamicForms({ currency })): currency
 * (ISO 4217), numberFormat ('es' | 'en'), wordsLanguage ('es' | 'en'), amountInWords, wordsUppercase
 * y currencyWords (nombres de una moneda que no esté incluida).
 *
 * Sin [formControl]: el input muestra un texto distinto del valor del modelo, así que el valor se
 * escribe a mano en el elemento.
 */
declare class CurrencyFieldComponent extends FieldType<FieldTypeConfig> implements AfterViewInit {
    private input;
    private readonly destroyRef;
    private focused;
    ngAfterViewInit(): void;
    get currency(): string;
    get numberFormat(): DfNumberFormat;
    get words(): string;
    onFocus(): void;
    onInput(text: string): void;
    onBlur(): void;
    /** Pinta el valor del control: formateado si es un importe, tal cual si es texto inválido. */
    private render;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CurrencyFieldComponent, "df-currency-field", never, {}, {}, never, never, true, never>;
}

interface TableColumn {
    label: string;
    col: number;
    required: boolean;
}
/** Lista repetible (nodo `array`): una fila por elemento, con botones para añadir y quitar. */
declare class RepeatFieldComponent extends FieldArrayType implements AfterViewChecked {
    private readonly host;
    /**
     * Las celdas de una tabla no llevan etiqueta (la pone la cabecera). En un contenedor estrecho las celdas se
     * apilan y la etiqueta sale de `data-label` (ver _grid.scss); las filas de tabla no pueden ocultar campos,
     * así que la celda N de cada fila es la columna N.
     */
    ngAfterViewChecked(): void;
    get isTable(): boolean;
    get columns(): TableColumn[];
    /** Plantilla de columnas de la rejilla de la tabla: el `col` de cada campo hace de peso relativo. */
    get tableTemplate(): string;
    /** Ancho mínimo de la tabla (9rem por columna y el botón de quitar): por debajo de eso se desplaza en horizontal. */
    get tableMinWidth(): string;
    /** Totales calculados con las filas actuales: se recalculan en cada ciclo de detección. */
    get totals(): {
        label: string;
        text: string;
    }[];
    get rowCount(): number;
    get locked(): boolean;
    get canAdd(): boolean;
    get canRemove(): boolean;
    rowTitle(index: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RepeatFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RepeatFieldComponent, "df-repeat-field", never, {}, {}, never, never, true, never>;
}

/** Columna ya resuelta por el adaptador: moneda y formato de número incluidos. */
interface DfResolvedColumn {
    key: string;
    label: string;
    type: DfTableColumnType;
    map?: Record<string, string>;
    variants?: Record<string, DfBadgeVariant>;
    href?: string;
    template?: string;
    sortable: boolean;
    col: number;
    currency: string;
    numberFormat: DfNumberFormat;
    filter: boolean;
    frozen: boolean;
    html: boolean;
}

type Row = Record<string, unknown>;
/** Clave de formState donde `<dynamic-form>` deja la función que recibe los eventos de las tablas. */
declare const DF_TABLE_EVENTS = "dfTableEvents";
/** Clave de formState con el registro de tablas vivas (`tableId` → controles), que `<dynamic-form>` usa para `selectAll()` y `clearSelection()`. */
declare const DF_TABLE_CONTROLS = "dfTableControls";
interface DfTableControls {
    selectAll(): void;
    clearSelection(): void;
}
interface DfTableEvents {
    action(event: DfTableActionEvent): void;
    select(event: DfTableSelectEvent): void;
    navigate(event: DfTableNavigateEvent): void;
}
type LoadState = 'idle' | 'loading' | 'error';
/** Tabla de datos de solo lectura (nodo `table`): filtro, orden, paginación, acciones por fila y selección. */
declare class TableFieldComponent extends FieldType<FormlyFieldConfig> implements OnInit, DoCheck, AfterViewChecked, OnDestroy {
    private readonly provider;
    private readonly cdr;
    private readonly evaluator;
    private readonly document;
    private readonly host;
    private readonly config;
    /** Últimos desplazamientos de las columnas fijas que se escribieron en el DOM. */
    private frozenOffsets;
    private readonly destroyed$;
    /** Peticiones al servicio; null cancela la que esté en vuelo. switchMap descarta las respuestas viejas. */
    private readonly jobs$;
    /** Avisa de que el usuario tocó el buscador o un filtro de columna (modo server: se espera a que pare). */
    private readonly filterInput$;
    loadState: LoadState;
    /** Filas que dio el servicio: todas (modo client) o solo la página actual (modo server). */
    private remoteRows;
    /** Total de filas que cumplen el filtro en el servidor (modo server). */
    private remoteTotal;
    /** Faltan campos de `dependsOn` por rellenar: no se pide nada. */
    waiting: boolean;
    private paramsKey;
    /** Filtro que ya se ha enviado al servidor (modo server). */
    private appliedFilter;
    /** Filtros por columna que ya se han enviado al servidor (modo server). */
    private appliedColumnFilters;
    filterText: string;
    /** Lo que el usuario ha escrito o elegido en los filtros de columna (`key` → valor). */
    columnFilters: Partial<Record<string, string>>;
    /** Exportando: en modo server se piden al servicio todas las filas. */
    exporting: boolean;
    exportFailed: boolean;
    /** Orden actual: de la columna principal a la última que desempata (más de una solo con `multiSort`). */
    sorts: {
        key: string;
        direction: 'asc' | 'desc';
    }[];
    pageIndex: number;
    /** Null hasta que el usuario cambia el tamaño; mientras, el del esquema. */
    private pageSizeChoice;
    private sortInitialised;
    /** Fila elegida con `selectable` simple. */
    selected: Row | null;
    /** Filas marcadas con `selectable: 'multiple'`, por `selectionKey` o, sin ella, por objeto. */
    private readonly selection;
    private cache;
    /** Textos de la app (`provideDynamicForms({ tableTexts })`); lo que no define queda en español. */
    get texts(): DfTableTexts;
    get noResultsText(): string;
    filterAria(col: DfResolvedColumn): string;
    /** Columnas del esquema, en su orden y con su `frozen`. */
    private get schemaColumns();
    /**
     * Columnas que se pintan: las del esquema en el orden que el usuario eligió arrastrando (`orderKeys`) y, con
     * `pinnableColumns`, las que fijó (`pinnedKeys`) primero y en el orden en que las fijó. Las fijas van siempre
     * delante. Se cachea para que cada columna sea siempre el mismo objeto.
     */
    get columns(): DfResolvedColumn[];
    get pinnable(): boolean;
    get reorderable(): boolean;
    /** Claves de las columnas fijas que el usuario dejó (null mientras no toque nada: manda el esquema). */
    private pinnedKeys;
    /** Orden de todas las columnas que el usuario eligió arrastrando (null: el del esquema). */
    private orderKeys;
    private columnsCache;
    /** Columna que se está arrastrando, y la que tiene el cursor encima. */
    dragKey: string | null;
    dropKey: string | null;
    /** Tras mover una columna con el teclado el foco vuelve a su cabecera cuando ya está en su sitio. */
    private refocusKey;
    private column;
    /** Solo se mueve entre columnas del mismo grupo: fijas con fijas, normales con normales. */
    canDrop(target: DfResolvedColumn): boolean;
    onDragStart(event: DragEvent, col: DfResolvedColumn): void;
    onDragOver(event: DragEvent, col: DfResolvedColumn): void;
    onDrop(event: DragEvent, col: DfResolvedColumn): void;
    onDragEnd(): void;
    get resizable(): boolean;
    /** Anchos en px de cada columna una vez que el usuario cambia alguno (null: los del esquema, en %). */
    widths: Record<string, number> | null;
    private resize;
    /** Ancho de una pista de `<colgroup>`: px si el usuario ya redimensionó, % del esquema si no. */
    colWidth(col: DfResolvedColumn): string;
    /** Ancho de la tabla entera: la suma de las pistas, para que sea más ancha que el contenedor y se desplace. */
    get tableWidth(): string | null;
    specialWidth(key: string): string | null;
    resizeLabel(col: DfResolvedColumn): string;
    /** Toma los anchos que tienen ahora las celdas de la cabecera: de ahí parte cualquier cambio. */
    private measureWidths;
    onResizeStart(event: PointerEvent, col: DfResolvedColumn): void;
    onResizeMove(event: PointerEvent): void;
    onResizeEnd(): void;
    /** Con el borde enfocado, las flechas lo mueven 10 px (50 con Mayús). */
    onResizeKey(event: KeyboardEvent, col: DfResolvedColumn): void;
    /** Doble clic en un borde: vuelven los anchos del esquema. */
    resetWidths(event: Event): void;
    private setWidth;
    /** Alt + flecha izquierda o derecha en una cabecera mueve la columna un sitio, dentro de su grupo. */
    onHeaderKey(event: KeyboardEvent, col: DfResolvedColumn): void;
    /** Pone `fromKey` en el sitio de `toKey`: una fija reordena las fijadas; una normal, el orden general. */
    private moveColumn;
    /** Fija o suelta una columna: la fijada pasa al final de las fijas; la soltada vuelve a su sitio. */
    togglePin(col: DfResolvedColumn): void;
    pinLabel(col: DfResolvedColumn): string;
    get actions(): DfTableAction[];
    get hasFilter(): boolean;
    get selectMode(): 'none' | 'single' | 'multiple';
    get selectable(): boolean;
    get multiple(): boolean;
    /** Hay columnas fijas a la izquierda. */
    get hasFrozen(): boolean;
    /** `left` de una columna fija: variable CSS que `ngAfterViewChecked` rellena con lo que miden las anteriores. */
    frozenLeft(col: DfResolvedColumn): string | null;
    onResize(): void;
    /** Mide dónde empieza cada columna fija (la casilla de selección incluida) y lo deja en variables CSS. */
    ngAfterViewChecked(): void;
    /** Dónde se guarda el estado, o null si la tabla no lo recuerda o el navegador no deja usar el almacén. */
    private get storage();
    private get stateKey();
    private restoreState;
    private saveState;
    get hasColumnFilters(): boolean;
    get exportConfig(): {
        filename: string;
    } | undefined;
    /** Hay algún filtro puesto (buscador o columna). */
    get filtering(): boolean;
    get emptyMessage(): string;
    get source(): DfTableSource | undefined;
    /** El servicio entrega las páginas ya filtradas, ordenadas y recortadas. */
    get serverSide(): boolean;
    get loading(): boolean;
    get failed(): boolean;
    get errorMessage(): string;
    /** Filas de origen: las del servicio (`source`), la propiedad del modelo (`dataKey`) o las del propio esquema. */
    get sourceRows(): Row[];
    /** Filas que cumplen el filtro: el total del servidor, o las que quedan en el cliente. */
    get totalRows(): number;
    ngOnInit(): void;
    /** Recarga la tabla cuando cambia el valor de alguno de los campos de `source.dependsOn`. */
    ngDoCheck(): void;
    ngOnDestroy(): void;
    private params;
    private toPage;
    /** Pide al servicio las filas que toquen ahora. */
    reload(): void;
    /** `keepSelection`: un cambio de página, orden o filtro no vacía una selección múltiple que tiene `selectionKey`. */
    private load;
    get pageSizeOptions(): number[];
    /** Filas por página; null si la tabla no pagina. */
    get pageSize(): number | null;
    private applyDefaultSort;
    /** Todas las filas tras filtrar y ordenar (sin paginar). */
    get processed(): Row[];
    get pageCount(): number;
    /** Página actual, sin salirse si las filas han bajado de número. */
    get currentPage(): number;
    get visibleRows(): Row[];
    /** "11–20 de 45" */
    get range(): string;
    /** Ancho de una columna en %: su `col` frente a la suma de todas (una pista, la tabla se ajusta al contenido). */
    width(col: DfResolvedColumn): number;
    /** El HTML crudo de una celda `html`; el `[innerHTML]` de la plantilla lo sanea. */
    html(row: Row, col: DfResolvedColumn): string;
    private get slots();
    /** Plantilla de la app para las celdas de la columna (`template`), si la hay. */
    cellTemplate(col: DfResolvedColumn): TemplateRef<DfCellContext> | null;
    cellContext(row: Row, col: DfResolvedColumn): DfCellContext;
    /** Plantilla de la app para la tabla vacía (`dfEmpty`), si la hay. */
    get emptyTemplate(): TemplateRef<{
        $implicit: string;
    }> | null;
    /** Clase de la insignia de una celda `badge`: `df-badge df-badge--ok` (neutra si el valor no tiene variante). */
    badgeClass(row: Row, col: DfResolvedColumn): string;
    /** Destino de una celda `link` (null si falta algún valor de la fila: se pinta el texto sin enlace). */
    href(row: Row, col: DfResolvedColumn): string | null;
    /**
     * Clic en un enlace `link`: se emite `tableNavigate` y la app decide si navega ella (`preventDefault`). Con Ctrl,
     * Cmd, Mayús, Alt o un botón que no sea el izquierdo no se emite: el navegador abre una pestaña o ventana.
     */
    onLink(event: MouseEvent, row: Row, col: DfResolvedColumn): void;
    text(row: Row, col: DfResolvedColumn): string;
    ariaSort(col: DfResolvedColumn): 'ascending' | 'descending' | 'none' | null;
    get multiSort(): boolean;
    /** Posición (desde 1) de la columna en el orden, solo cuando hay varias columnas ordenando. */
    sortPosition(col: DfResolvedColumn): number | null;
    sortArrow(col: DfResolvedColumn): string;
    /**
     * Pulsar la cabecera: ascendente, luego descendente, luego sin orden. Con `multiSort`, Mayús + clic añade la
     * columna al orden (o cambia su sentido, o la quita) sin tocar las demás; un clic sin Mayús ordena solo por ella.
     */
    sortBy(col: DfResolvedColumn, event?: Event): void;
    onFilter(event: Event): void;
    filterKind(col: DfResolvedColumn): 'text' | 'select';
    filterOptions(col: DfResolvedColumn): {
        value: string;
        label: string;
    }[];
    onColumnFilter(col: DfResolvedColumn, event: Event): void;
    /** Filtros por columna con algo escrito o elegido. */
    private activeColumnFilters;
    private filtersChanged;
    goTo(page: number): void;
    onPageSize(event: Event): void;
    private get events();
    /** La acción se muestra en esta fila (sin `showWhen` se muestra siempre). */
    actionVisible(row: Row, action: DfTableAction): boolean;
    actionDisabled(row: Row, action: DfTableAction): boolean;
    /** Trazado SVG del icono incluido, o null si `icon` es un texto que se pinta tal cual. */
    iconPath(action: DfTableAction): string | null;
    act(row: Row, action: DfTableAction): void;
    get tableId(): string;
    private get selectionKey();
    private idOf;
    /** Filas marcadas con `selectable: 'multiple'`. */
    get selectedRows(): Row[];
    /** Última fila que se marcó o desmarcó con el ratón: donde empieza un rango con Shift. */
    private anchor;
    /** Con Shift apretado el navegador selecciona texto entre los dos clics; aquí estorba. */
    onRowMouseDown(event: MouseEvent): void;
    /** Hay alguna fila que la casilla de la cabecera pueda marcar. */
    get headerRowsAvailable(): boolean;
    /** La fila admite selección (sin `selectableWhen` todas la admiten). */
    rowSelectable(row: Row): boolean;
    /** Filas que marca la casilla de la cabecera: las seleccionables de la página o de todo lo filtrado. */
    private get headerRows();
    toggle(row: Row, event?: Event): void;
    isSelected(row: Row): boolean;
    /** Casilla de la cabecera: todas las filas filtradas (en modo server, las de la página). */
    get allSelected(): boolean;
    get someSelected(): boolean;
    toggleAll(): void;
    private get controls();
    /** Marca las filas que marcaría la casilla de la cabecera (`selectable: 'multiple'`). Es la misma lógica que `toggleAll` cuando no están todas marcadas. */
    selectAll(): void;
    /** Quita toda la selección, también la de otras páginas. No emite nada si no había nada marcado. */
    clearSelection(): void;
    private emitSelection;
    /** Texto del botón: con filas marcadas exporta solo esas. */
    get exportLabel(): string;
    exportCsv(): void;
    private download;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableFieldComponent, "df-table-field", never, {}, {}, never, never, true, never>;
}

/** Nodo `slot`: no es un control ni toca el modelo, solo pinta la plantilla de la app con ese nombre. */
declare class SlotFieldComponent extends FieldType<FormlyFieldConfig> {
    get name(): string;
    get template(): TemplateRef<DfSlotContext> | null;
    get context(): DfSlotContext;
    static ɵfac: i0.ɵɵFactoryDeclaration<SlotFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SlotFieldComponent, "df-slot-field", never, {}, {}, never, never, true, never>;
}

/** Wrapper estándar: label, control proyectado, descripción y mensajes de error. */
declare class FieldWrapperComponent extends FieldWrapper {
    get showLabel(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldWrapperComponent, "df-field-wrapper", never, {}, {}, never, never, true, never>;
}

/** Fieldset con título/descripción para nodos de tipo group. */
declare class GroupWrapperComponent extends FieldWrapper {
    static ɵfac: i0.ɵɵFactoryDeclaration<GroupWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GroupWrapperComponent, "df-group-wrapper", never, {}, {}, never, never, true, never>;
}

export { BUSINESS_VALIDATORS, CONTEXT_PREFIX, CURRENCY_WORDS, CheckboxFieldComponent, ConditionEvaluatorService, CurrencyFieldComponent, DEFAULT_VALIDATION_MESSAGES, DF_ARRAY_TOTAL_OPS, DF_BADGE_VARIANTS, DF_FIELD_TYPES, DF_OPERATORS, DF_OPTIONS_PROVIDER, DF_PLAIN_TYPE_NAMES, DF_SLOTS, DF_TABLE_COLUMN_TYPES, DF_TABLE_CONTROLS, DF_TABLE_EVENTS, DF_TABLE_ICONS, DF_TABLE_PROVIDER, DF_TABLE_SLOTS, DF_VALIDATORS, DYNAMIC_FORMS_CONFIG, DfCellDirective, DfEmptyDirective, DfSlotDirective, DynamicFormComponent, DynamicFormsSchemaError, EN_TABLE_TEXTS, EN_VALIDATION_MESSAGES, FieldWrapperComponent, FormSchemaAdapterService, GroupWrapperComponent, HiddenFieldComponent, InputFieldComponent, NUMBER_FORMATS, PLAIN_THEME, RELATIVE_PREFIX, RadioFieldComponent, RepeatFieldComponent, SchemaValidatorService, SelectFieldComponent, SlotFieldComponent, TableFieldComponent, TextareaFieldComponent, ValidatorRegistryService, WORDS_LANGUAGES, amountError, amountExample, amountToWords, bootstrapTheme, currencySymbol, editableAmount, formatAmount, formatNumber, getByPath, integerToWords, integerToWordsEn, isCurrencyCode, isDfArray, isDfField, isDfGroup, isDfSlot, isDfTable, isObservableOptions, isValidCif, isValidDni, isValidIban, isValidNie, isValidPhoneES, isValidPostalCodeES, materialTheme, parseAmount, provideDynamicForms, textLength, toFormlyMessages, truncateToLength };
export type { DfAmountParse, DfAmountWordsOptions, DfArray, DfArrayDisplay, DfArrayTotal, DfArrayTotalOp, DfBadgeVariant, DfCellContext, DfCondition, DfConditionalLogic, DfCurrencyConfig, DfCurrencyWords, DfCustomFieldType, DfDependentOptions, DfField, DfFieldLayout, DfFieldType, DfFormLayout, DfFormSchema, DfFormStatus, DfGroup, DfMaxLengthMode, DfMessageFn, DfNode, DfNumberFormat, DfOperator, DfOption, DfOptionsProvider, DfOptionsSource, DfRemoteOptions, DfResolvedConfig, DfRule, DfRuleGroup, DfSchemaIssue, DfSchemaValidationResult, DfSlot, DfSlotContext, DfSlots, DfStaticOptions, DfSubmitEvent, DfTable, DfTableAction, DfTableActionEvent, DfTableColumn, DfTableColumnType, DfTableControls, DfTableEvents, DfTableExport, DfTableNavigateEvent, DfTablePage, DfTableProvider, DfTableRequest, DfTableSelectEvent, DfTableSlots, DfTableSort, DfTableSource, DfTableTexts, DfTheme, DfValidation, DfValidationMessage, DfValidatorDefinition, DfValidatorFn, DfValidatorRef, DfValidatorResult, DfWordsLanguage, DynamicFormsConfig };
