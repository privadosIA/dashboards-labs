import * as i0 from '@angular/core';
import { InjectionToken, input, inject, ElementRef, HostListener, Directive, ChangeDetectionStrategy, Component, DestroyRef, ViewChild, TemplateRef, Injectable, ChangeDetectorRef, makeEnvironmentProviders, importProvidersFrom, model, output, contentChildren, computed, effect, untracked, HostBinding } from '@angular/core';
import * as i2 from '@ngx-formly/core';
import { FieldType, FormlyModule, FieldArrayType, FieldWrapper, FormlyConfig, FORMLY_CONFIG } from '@ngx-formly/core';
import * as i1 from '@angular/forms';
import { NgControl, ReactiveFormsModule, Validators, FormGroup, FormArray } from '@angular/forms';
import { AsyncPipe, DOCUMENT, NgTemplateOutlet } from '@angular/common';
import { of, isObservable, Subject, debounceTime, takeUntil, switchMap, EMPTY, map, catchError, take, Subscription } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { shareReplay, distinctUntilChanged } from 'rxjs/operators';

/**
 * Tipos TypeScript del SchemaContract (openspec.yaml).
 * Son la representación 1:1 del JSON que emite el backend / Appian.
 */
const DF_FIELD_TYPES = [
    'text', 'email', 'password', 'number', 'textarea',
    'select', 'multiselect', 'radio', 'checkbox', 'date', 'hidden', 'currency',
];
const DF_OPERATORS = [
    'eq', 'neq', 'in', 'nin', 'gt', 'gte', 'lt', 'lte',
    'empty', 'notEmpty', 'truthy', 'falsy', 'matches', 'contains',
];
const DF_ARRAY_TOTAL_OPS = ['sum', 'count', 'avg', 'min', 'max'];
const DF_BADGE_VARIANTS = ['ok', 'warn', 'error', 'info'];
const DF_TABLE_COLUMN_TYPES = [
    'text', 'number', 'currency', 'date', 'datetime', 'boolean', 'map', 'badge', 'link',
];
/** Iconos incluidos para `DfTableAction.icon`. */
const DF_TABLE_ICONS = ['view', 'edit', 'delete', 'download', 'add', 'check', 'close'];
function isDfSlot(node) {
    return node.type === 'slot';
}
function isDfGroup(node) {
    return node.type === 'group';
}
function isDfArray(node) {
    return node.type === 'array';
}
function isDfTable(node) {
    return node.type === 'table';
}
/** Un campo de entrada: ni grupo, ni lista repetible, ni tabla. */
function isDfField(node) {
    return !isDfGroup(node) && !isDfArray(node) && !isDfTable(node) && !isDfSlot(node);
}

class DynamicFormsSchemaError extends Error {
    issues;
    constructor(issues) {
        super(`Esquema de formulario inválido:\n${issues.map((i) => ` - ${i.path}: ${i.message}`).join('\n')}`);
        this.issues = issues;
        this.name = 'DynamicFormsSchemaError';
    }
}

const DYNAMIC_FORMS_CONFIG = new InjectionToken('DYNAMIC_FORMS_CONFIG');
/** multi: true — cada provider aporta un array de definiciones. */
const DF_VALIDATORS = new InjectionToken('DF_VALIDATORS');
const DF_OPTIONS_PROVIDER = new InjectionToken('DF_OPTIONS_PROVIDER');
const DF_TABLE_PROVIDER = new InjectionToken('DF_TABLE_PROVIDER');

/** Longitud según el modo. Recorre code points, así que un emoji cuenta como un solo carácter (2). */
function textLength(text, mode = 'weighted') {
    let length = 0;
    for (const char of text)
        length += mode === 'weighted' && char.codePointAt(0) > 127 ? 2 : 1;
    return length;
}
/** Recorta el texto para que su longitud no pase de max, sin partir caracteres. */
function truncateToLength(text, max, mode = 'weighted') {
    let length = 0;
    let out = '';
    for (const char of text) {
        const weight = mode === 'weighted' && char.codePointAt(0) > 127 ? 2 : 1;
        if (length + weight > max)
            break;
        length += weight;
        out += char;
    }
    return out;
}
/** Modo de un campo: props.maxLengthMode si es válido; si no, el de la config. */
const resolveMaxLengthMode = (prop, fallback) => prop === 'chars' || prop === 'weighted' ? prop : fallback;

/**
 * Bloquea input/textarea en validation.maxLength contando con el mismo modo que el validador.
 * El maxlength nativo cuenta la ñ como 1; en modo 'weighted' cuenta 2, así que al escribir o
 * pegar se recorta lo que sobre.
 */
class DfMaxLengthDirective {
    dfMaxLength = input(...(ngDevMode ? [undefined, { debugName: "dfMaxLength" }] : /* istanbul ignore next */ []));
    dfMaxLengthMode = input('weighted', ...(ngDevMode ? [{ debugName: "dfMaxLengthMode" }] : /* istanbul ignore next */ []));
    el = inject(ElementRef);
    control = inject(NgControl, { optional: true, self: true });
    onInput() {
        const max = this.dfMaxLength();
        const mode = this.dfMaxLengthMode();
        const value = this.el.nativeElement.value;
        if (max == null || textLength(value, mode) <= max)
            return;
        const truncated = truncateToLength(value, max, mode);
        this.el.nativeElement.value = truncated;
        this.control?.control?.setValue(truncated);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfMaxLengthDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.25", type: DfMaxLengthDirective, isStandalone: true, selector: "input[dfMaxLength], textarea[dfMaxLength]", inputs: { dfMaxLength: { classPropertyName: "dfMaxLength", publicName: "dfMaxLength", isSignal: true, isRequired: false, transformFunction: null }, dfMaxLengthMode: { classPropertyName: "dfMaxLengthMode", publicName: "dfMaxLengthMode", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "input": "onInput()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfMaxLengthDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[dfMaxLength], textarea[dfMaxLength]',
                    standalone: true,
                }]
        }], propDecorators: { dfMaxLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "dfMaxLength", required: false }] }], dfMaxLengthMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "dfMaxLengthMode", required: false }] }], onInput: [{
                type: HostListener,
                args: ['input']
            }] } });

/** text | email | password | number | date */
class InputFieldComponent extends FieldType {
    get inputType() {
        return this.props['type'] ?? 'text';
    }
    /** Modo de validation.maxLength (en 'weighted' la ñ y los acentos cuentan 2). */
    get mode() {
        return resolveMaxLengthMode(this.props['maxLengthMode'], 'weighted');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: InputFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: InputFieldComponent, isStandalone: true, selector: "df-input-field", usesInheritance: true, ngImport: i0, template: "@if (inputType === 'number') {\n  <input\n    type=\"number\"\n    class=\"df-control\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [readonly]=\"props.readonly === true\"\n    [attr.min]=\"props.min\"\n    [attr.max]=\"props.max\"\n    [attr.step]=\"props['step']\"\n    [attr.aria-invalid]=\"showError\" />\n} @else {\n  <input\n    [type]=\"inputType\"\n    class=\"df-control\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [readonly]=\"props.readonly === true\"\n    [attr.minlength]=\"props.minLength\"\n    [attr.maxlength]=\"props.maxLength\"\n    [dfMaxLength]=\"props.maxLength\"\n    [dfMaxLengthMode]=\"mode\"\n    [attr.autocomplete]=\"props['autocomplete']\"\n    [attr.aria-invalid]=\"showError\" />\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: FormlyModule }, { kind: "directive", type: i2.LegacyFormlyAttributes, selector: "[formlyAttributes]" }, { kind: "directive", type: DfMaxLengthDirective, selector: "input[dfMaxLength], textarea[dfMaxLength]", inputs: ["dfMaxLength", "dfMaxLengthMode"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: InputFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-input-field', standalone: true, imports: [ReactiveFormsModule, FormlyModule, DfMaxLengthDirective], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (inputType === 'number') {\n  <input\n    type=\"number\"\n    class=\"df-control\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [readonly]=\"props.readonly === true\"\n    [attr.min]=\"props.min\"\n    [attr.max]=\"props.max\"\n    [attr.step]=\"props['step']\"\n    [attr.aria-invalid]=\"showError\" />\n} @else {\n  <input\n    [type]=\"inputType\"\n    class=\"df-control\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [readonly]=\"props.readonly === true\"\n    [attr.minlength]=\"props.minLength\"\n    [attr.maxlength]=\"props.maxLength\"\n    [dfMaxLength]=\"props.maxLength\"\n    [dfMaxLengthMode]=\"mode\"\n    [attr.autocomplete]=\"props['autocomplete']\"\n    [attr.aria-invalid]=\"showError\" />\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}\n"] }]
        }] });

/** select | multiselect — acepta options estáticas u Observable (remote/cascading). */
class SelectFieldComponent extends FieldType {
    lastRaw;
    lastObs = of([]);
    get options$() {
        const raw = this.props.options;
        if (raw !== this.lastRaw) {
            this.lastRaw = raw;
            this.lastObs = isObservable(raw) ? raw : of(raw ?? []);
        }
        return this.lastObs;
    }
    get multiple() {
        return this.props['multiple'] === true;
    }
    trackValue(_, o) {
        return o.value;
    }
    /**
     * Valor de la opción del placeholder: el mismo "vacío" que tenga el modelo (undefined al empezar,
     * null tras un reset en cascada) para que quede seleccionada. Con [ngValue]="null" fijo, un campo
     * sin valor se pintaba en blanco.
     */
    get placeholderValue() {
        return this.formControl.value === undefined ? undefined : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: SelectFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: SelectFieldComponent, isStandalone: true, selector: "df-select-field", usesInheritance: true, ngImport: i0, template: "@if (multiple) {\n  <select\n    multiple\n    class=\"df-control df-select df-select--multiple\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [attr.aria-invalid]=\"showError\">\n    @for (opt of options$ | async; track opt.value) {\n      <option [ngValue]=\"opt.value\" [disabled]=\"opt.disabled === true\">{{ opt.label }}</option>\n    }\n  </select>\n} @else {\n  <select\n    class=\"df-control df-select\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [attr.aria-invalid]=\"showError\">\n    <option [ngValue]=\"placeholderValue\">{{ props.placeholder || '\u2014 Selecciona \u2014' }}</option>\n    @for (opt of options$ | async; track opt.value) {\n      <option [ngValue]=\"opt.value\" [disabled]=\"opt.disabled === true\">{{ opt.label }}</option>\n    }\n  </select>\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}.df-select--multiple{min-height:7rem}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.SelectMultipleControlValueAccessor, selector: "select[multiple][formControlName],select[multiple][formControl],select[multiple][ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: FormlyModule }, { kind: "directive", type: i2.LegacyFormlyAttributes, selector: "[formlyAttributes]" }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: SelectFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-select-field', standalone: true, imports: [ReactiveFormsModule, FormlyModule, AsyncPipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (multiple) {\n  <select\n    multiple\n    class=\"df-control df-select df-select--multiple\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [attr.aria-invalid]=\"showError\">\n    @for (opt of options$ | async; track opt.value) {\n      <option [ngValue]=\"opt.value\" [disabled]=\"opt.disabled === true\">{{ opt.label }}</option>\n    }\n  </select>\n} @else {\n  <select\n    class=\"df-control df-select\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [attr.aria-invalid]=\"showError\">\n    <option [ngValue]=\"placeholderValue\">{{ props.placeholder || '\u2014 Selecciona \u2014' }}</option>\n    @for (opt of options$ | async; track opt.value) {\n      <option [ngValue]=\"opt.value\" [disabled]=\"opt.disabled === true\">{{ opt.label }}</option>\n    }\n  </select>\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}.df-select--multiple{min-height:7rem}\n"] }]
        }] });

class TextareaFieldComponent extends FieldType {
    get rows() {
        return this.props['rows'] ?? 3;
    }
    /**
     * Con validation.maxLength se pinta el contador "N/máx" bajo la caja y se bloquea en el límite.
     * En modo 'weighted' (por defecto) la ñ y los acentos cuentan 2, igual que en el validador.
     */
    get maxLength() {
        return this.props.maxLength;
    }
    get mode() {
        return resolveMaxLengthMode(this.props['maxLengthMode'], 'weighted');
    }
    get length() {
        return textLength(String(this.formControl.value ?? ''), this.mode);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: TextareaFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: TextareaFieldComponent, isStandalone: true, selector: "df-textarea-field", usesInheritance: true, ngImport: i0, template: "<textarea\n  class=\"df-control df-textarea\"\n  [rows]=\"rows\"\n  [formControl]=\"formControl\"\n  [formlyAttributes]=\"field\"\n  [readonly]=\"props.readonly === true\"\n  [attr.maxlength]=\"props.maxLength\"\n  [dfMaxLength]=\"props.maxLength\"\n  [dfMaxLengthMode]=\"mode\"\n  [attr.aria-invalid]=\"showError\"\n  [attr.aria-describedby]=\"maxLength ? id + '-counter' : null\"></textarea>\n@if (maxLength) {\n  <div class=\"df-counter\" [class.df-counter--limit]=\"length >= maxLength\" [id]=\"id + '-counter'\">\n    {{ length }}/{{ maxLength }}\n  </div>\n  @if (length >= maxLength) {\n    <span class=\"df-sr-only\" role=\"status\">Has llegado al m\u00E1ximo de {{ maxLength }} caracteres</span>\n  }\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}.df-textarea{resize:vertical;min-height:4rem}.df-counter{margin-top:.25rem;font-size:.8rem;text-align:right;color:var(--df-color-muted);font-variant-numeric:tabular-nums}.df-counter--limit{color:var(--df-color-danger);font-weight:600}.df-sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: FormlyModule }, { kind: "directive", type: i2.LegacyFormlyAttributes, selector: "[formlyAttributes]" }, { kind: "directive", type: DfMaxLengthDirective, selector: "input[dfMaxLength], textarea[dfMaxLength]", inputs: ["dfMaxLength", "dfMaxLengthMode"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: TextareaFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-textarea-field', standalone: true, imports: [ReactiveFormsModule, FormlyModule, DfMaxLengthDirective], changeDetection: ChangeDetectionStrategy.OnPush, template: "<textarea\n  class=\"df-control df-textarea\"\n  [rows]=\"rows\"\n  [formControl]=\"formControl\"\n  [formlyAttributes]=\"field\"\n  [readonly]=\"props.readonly === true\"\n  [attr.maxlength]=\"props.maxLength\"\n  [dfMaxLength]=\"props.maxLength\"\n  [dfMaxLengthMode]=\"mode\"\n  [attr.aria-invalid]=\"showError\"\n  [attr.aria-describedby]=\"maxLength ? id + '-counter' : null\"></textarea>\n@if (maxLength) {\n  <div class=\"df-counter\" [class.df-counter--limit]=\"length >= maxLength\" [id]=\"id + '-counter'\">\n    {{ length }}/{{ maxLength }}\n  </div>\n  @if (length >= maxLength) {\n    <span class=\"df-sr-only\" role=\"status\">Has llegado al m\u00E1ximo de {{ maxLength }} caracteres</span>\n  }\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}.df-textarea{resize:vertical;min-height:4rem}.df-counter{margin-top:.25rem;font-size:.8rem;text-align:right;color:var(--df-color-muted);font-variant-numeric:tabular-nums}.df-counter--limit{color:var(--df-color-danger);font-weight:600}.df-sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%);white-space:nowrap}\n"] }]
        }] });

/** La label se pinta aquí (el wrapper la oculta con hideLabel). */
class CheckboxFieldComponent extends FieldType {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: CheckboxFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: CheckboxFieldComponent, isStandalone: true, selector: "df-checkbox-field", usesInheritance: true, ngImport: i0, template: "<label class=\"df-checkbox\">\n  <input\n    type=\"checkbox\"\n    class=\"df-checkbox__input\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [attr.aria-invalid]=\"showError\" />\n  <span class=\"df-checkbox__label\">\n    {{ props.label }}\n    @if (props.required) { <span class=\"df-required\" aria-hidden=\"true\">*</span> }\n  </span>\n</label>\n", styles: [":host{display:block}.df-checkbox{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer;font:inherit;color:var(--df-color-text)}.df-checkbox__input{width:1.1rem;height:1.1rem;accent-color:var(--df-color-primary)}.df-required{color:var(--df-color-danger)}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.CheckboxControlValueAccessor, selector: "input[type=checkbox][formControlName],input[type=checkbox][formControl],input[type=checkbox][ngModel]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: FormlyModule }, { kind: "directive", type: i2.LegacyFormlyAttributes, selector: "[formlyAttributes]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: CheckboxFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-checkbox-field', standalone: true, imports: [ReactiveFormsModule, FormlyModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<label class=\"df-checkbox\">\n  <input\n    type=\"checkbox\"\n    class=\"df-checkbox__input\"\n    [formControl]=\"formControl\"\n    [formlyAttributes]=\"field\"\n    [attr.aria-invalid]=\"showError\" />\n  <span class=\"df-checkbox__label\">\n    {{ props.label }}\n    @if (props.required) { <span class=\"df-required\" aria-hidden=\"true\">*</span> }\n  </span>\n</label>\n", styles: [":host{display:block}.df-checkbox{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer;font:inherit;color:var(--df-color-text)}.df-checkbox__input{width:1.1rem;height:1.1rem;accent-color:var(--df-color-primary)}.df-required{color:var(--df-color-danger)}\n"] }]
        }] });

/**
 * Sin [formControl]: con el value accessor de Angular, [disabled] en el input lo
 * captura FormControlDirective y las opciones deshabilitadas seguían pulsables.
 */
class RadioFieldComponent extends FieldType {
    lastRaw;
    lastObs = of([]);
    get options$() {
        const raw = this.props.options;
        if (raw !== this.lastRaw) {
            this.lastRaw = raw;
            this.lastObs = isObservable(raw) ? raw : of(raw ?? []);
        }
        return this.lastObs;
    }
    get inline() {
        return this.props['inline'] === true;
    }
    isDisabled(opt) {
        return opt.disabled === true || this.formControl.disabled;
    }
    select(value) {
        this.formControl.setValue(value);
        this.formControl.markAsDirty();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: RadioFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: RadioFieldComponent, isStandalone: true, selector: "df-radio-field", usesInheritance: true, ngImport: i0, template: "<div class=\"df-radio-group\" [class.df-radio-group--inline]=\"inline\" role=\"radiogroup\" [attr.aria-invalid]=\"showError\">\n  @for (opt of options$ | async; track opt.value; let i = $index) {\n    <label class=\"df-radio\" [class.df-radio--disabled]=\"isDisabled(opt)\">\n      <input\n        type=\"radio\"\n        class=\"df-radio__input\"\n        [id]=\"id + '_' + i\"\n        [name]=\"field.name || id\"\n        [value]=\"opt.value\"\n        [checked]=\"formControl.value === opt.value\"\n        [disabled]=\"isDisabled(opt)\"\n        [formlyAttributes]=\"field\"\n        (change)=\"select(opt.value)\"\n        (blur)=\"formControl.markAsTouched()\" />\n      <span class=\"df-radio__label\">{{ opt.label }}</span>\n    </label>\n  }\n</div>\n", styles: [":host{display:block}.df-radio-group{display:flex;flex-direction:column;gap:.4rem}.df-radio-group--inline{flex-direction:row;flex-wrap:wrap;gap:1rem}.df-radio{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer;color:var(--df-color-text)}.df-radio--disabled{opacity:.6;cursor:not-allowed}.df-radio__input{accent-color:var(--df-color-primary)}\n"], dependencies: [{ kind: "ngmodule", type: FormlyModule }, { kind: "directive", type: i2.LegacyFormlyAttributes, selector: "[formlyAttributes]" }, { kind: "pipe", type: AsyncPipe, name: "async" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: RadioFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-radio-field', standalone: true, imports: [FormlyModule, AsyncPipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"df-radio-group\" [class.df-radio-group--inline]=\"inline\" role=\"radiogroup\" [attr.aria-invalid]=\"showError\">\n  @for (opt of options$ | async; track opt.value; let i = $index) {\n    <label class=\"df-radio\" [class.df-radio--disabled]=\"isDisabled(opt)\">\n      <input\n        type=\"radio\"\n        class=\"df-radio__input\"\n        [id]=\"id + '_' + i\"\n        [name]=\"field.name || id\"\n        [value]=\"opt.value\"\n        [checked]=\"formControl.value === opt.value\"\n        [disabled]=\"isDisabled(opt)\"\n        [formlyAttributes]=\"field\"\n        (change)=\"select(opt.value)\"\n        (blur)=\"formControl.markAsTouched()\" />\n      <span class=\"df-radio__label\">{{ opt.label }}</span>\n    </label>\n  }\n</div>\n", styles: [":host{display:block}.df-radio-group{display:flex;flex-direction:column;gap:.4rem}.df-radio-group--inline{flex-direction:row;flex-wrap:wrap;gap:1rem}.df-radio{display:inline-flex;align-items:center;gap:.5rem;cursor:pointer;color:var(--df-color-text)}.df-radio--disabled{opacity:.6;cursor:not-allowed}.df-radio__input{accent-color:var(--df-color-primary)}\n"] }]
        }] });

/** Mantiene el valor en el modelo sin pintarse (ids de proceso, tokens…). */
class HiddenFieldComponent extends FieldType {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: HiddenFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.25", type: HiddenFieldComponent, isStandalone: true, selector: "df-hidden-field", usesInheritance: true, ngImport: i0, template: "<input type=\"hidden\" [formControl]=\"formControl\" [formlyAttributes]=\"field\" />\n", styles: [":host{display:none}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: FormlyModule }, { kind: "directive", type: i2.LegacyFormlyAttributes, selector: "[formlyAttributes]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: HiddenFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-hidden-field', standalone: true, imports: [ReactiveFormsModule, FormlyModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<input type=\"hidden\" [formControl]=\"formControl\" [formlyAttributes]=\"field\" />\n", styles: [":host{display:none}\n"] }]
        }] });

/**
 * Importes: parseo de lo que escribe el usuario, formato para mostrar y conversión a letra
 * (como en cheques y documentos oficiales), en formato español o inglés y para cualquier moneda.
 */
/** Nombres incluidos. Para otra moneda, pasa currencyWords. */
const CURRENCY_WORDS = {
    es: {
        EUR: { singular: 'euro', plural: 'euros', centSingular: 'céntimo', centPlural: 'céntimos' },
        GBP: { singular: 'libra', plural: 'libras', centSingular: 'penique', centPlural: 'peniques', feminine: true },
        USD: { singular: 'dólar', plural: 'dólares', centSingular: 'centavo', centPlural: 'centavos' },
    },
    en: {
        EUR: { singular: 'euro', plural: 'euros', centSingular: 'cent', centPlural: 'cents' },
        GBP: { singular: 'pound', plural: 'pounds', centSingular: 'penny', centPlural: 'pence' },
        USD: { singular: 'dollar', plural: 'dollars', centSingular: 'cent', centPlural: 'cents' },
    },
};
const FORMATS = {
    es: { thousands: '.', decimal: ',', locale: 'es-ES', example: '1.500,75' },
    en: { thousands: ',', decimal: '.', locale: 'en-GB', example: '1,500.75' },
};
const NUMBER_FORMATS = ['es', 'en'];
const WORDS_LANGUAGES = ['es', 'en'];
/** Código ISO 4217 bien formado (EUR, GBP, USD…). */
const isCurrencyCode = (code) => typeof code === 'string' && /^[A-Z]{3}$/.test(code);
/** Ejemplo de importe en el formato indicado, para mensajes de error. */
const amountExample = (format = 'es') => (FORMATS[format] ?? FORMATS.es).example;
/** Símbolo corto de la moneda (€, £, $; CHF si no tiene uno propio). */
function currencySymbol(currency) {
    try {
        const parts = new Intl.NumberFormat('en', { style: 'currency', currency, currencyDisplay: 'narrowSymbol' }).formatToParts(0);
        return parts.find((p) => p.type === 'currency')?.value ?? currency;
    }
    catch {
        return currency;
    }
}
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** Quita un símbolo o código de moneda pegado al principio o al final ("£1,500.75", "1.500,75 €"). */
function stripCurrency(text, currency) {
    for (const mark of [currencySymbol(currency), currency]) {
        if (text.startsWith(mark))
            return text.slice(mark.length).trimStart();
        if (text.endsWith(mark))
            return text.slice(0, -mark.length).trimEnd();
    }
    return text;
}
/**
 * Lee un importe en el formato indicado: separador de miles en grupos de 3, separador decimal y
 * hasta dos decimales, sin negativos. Solo ignora los espacios de los extremos y el símbolo o
 * código de la moneda al principio o al final; un espacio en medio ("15 00") es error de formato.
 * Un texto mal formado es error de formato aunque solo tenga dígitos y separadores ("5,", "1,2,3");
 * el error de decimales queda para un importe bien formado con más de dos. Un texto vacío es un
 * importe vacío (null).
 */
function parseAmount(text, format = 'es', currency = 'EUR') {
    const { thousands, decimal } = FORMATS[format] ?? FORMATS.es;
    const clean = stripCurrency(text.trim(), currency);
    if (clean === '')
        return { ok: true, value: null };
    const t = escapeRe(thousands);
    const d = escapeRe(decimal);
    if (new RegExp(`^(\\d+|\\d{1,3}(${t}\\d{3})+)(${d}\\d{1,2})?$`).test(clean)) {
        return { ok: true, value: Number(clean.split(thousands).join('').replace(decimal, '.')) };
    }
    const tooManyDecimals = new RegExp(`^(\\d+|\\d{1,3}(${t}\\d{3})+)${d}\\d{3,}$`).test(clean);
    return { ok: false, error: tooManyDecimals ? 'decimals' : 'format' };
}
/**
 * Error de un valor de importe tal como lo guarda el control: number si es válido, el texto
 * escrito si no se pudo leer, o vacío. Lo usan los validadores currencyFormat y currencyDecimals.
 */
function amountError(value, format = 'es', currency = 'EUR') {
    if (value == null || value === '')
        return null;
    if (typeof value === 'number') {
        if (!Number.isFinite(value) || value < 0)
            return 'format';
        return Math.abs(Math.round(value * 100) - value * 100) > 1e-6 ? 'decimals' : null;
    }
    if (typeof value === 'string') {
        const parsed = parseAmount(value, format, currency);
        return parsed.ok ? null : parsed.error;
    }
    return 'format';
}
/** "1.500,75 €" (es) o "£1,500.75" (en): miles agrupados siempre, también con 4 cifras. */
function formatAmount(value, currency = 'EUR', format = 'es') {
    // useGrouping 'always' (Intl ES2023) evita "1500,75 €": es-ES no agrupa por defecto los números de 4 cifras.
    const options = {
        style: 'currency', currency, currencyDisplay: 'narrowSymbol', useGrouping: 'always',
    };
    return new Intl.NumberFormat((FORMATS[format] ?? FORMATS.es).locale, options).format(value);
}
/** "1.500,75" (es) o "1,500.75" (en) sin símbolo: miles agrupados siempre y hasta dos decimales. */
function formatNumber(value, format = 'es') {
    const options = { maximumFractionDigits: 2, useGrouping: 'always' };
    return new Intl.NumberFormat((FORMATS[format] ?? FORMATS.es).locale, options).format(value);
}
/** "1500,75" (es) o "1500.75" (en): versión editable, sin miles ni símbolo, que parseAmount vuelve a leer. */
function editableAmount(value, format = 'es') {
    return String(Math.round(value * 100) / 100).replace('.', (FORMATS[format] ?? FORMATS.es).decimal);
}
// --- Letra en español -------------------------------------------------------
const UNITS = [
    '', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve',
    'diez', 'once', 'doce', 'trece', 'catorce', 'quince', 'dieciséis', 'diecisiete', 'dieciocho', 'diecinueve',
    'veinte', 'veintiuno', 'veintidós', 'veintitrés', 'veinticuatro', 'veinticinco', 'veintiséis', 'veintisiete',
    'veintiocho', 'veintinueve',
];
const TENS = ['', '', '', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa'];
const HUNDREDS = [
    '', 'ciento', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos', 'seiscientos', 'setecientos',
    'ochocientos', 'novecientos',
];
function below1000(n, ending, feminine) {
    if (n === 100)
        return 'cien';
    const h = Math.floor(n / 100);
    const rest = n % 100;
    // "doscientas libras": las centenas concuerdan en género; "ciento" no cambia.
    const hundreds = feminine && h >= 2 ? HUNDREDS[h].replace(/os$/, 'as') : HUNDREDS[h];
    let restWords = rest < 30 ? UNITS[rest] : `${TENS[Math.floor(rest / 10)]}${rest % 10 ? ` y ${UNITS[rest % 10]}` : ''}`;
    if (ending !== 'uno' && restWords.endsWith('uno')) {
        const base = restWords.slice(0, -3);
        restWords = ending === 'una' ? `${base}una` : `${base}${base.endsWith('veinti') ? 'ún' : 'un'}`;
    }
    return [hundreds, restWords].filter(Boolean).join(' ');
}
function below1e6(n, ending, feminine) {
    const thousands = Math.floor(n / 1000);
    const rest = n % 1000;
    const parts = [];
    // Delante de "mil": "veintiún mil libras", pero "doscientas mil libras".
    if (thousands)
        parts.push(thousands === 1 ? 'mil' : `${below1000(thousands, 'un', feminine)} mil`);
    if (rest)
        parts.push(below1000(rest, ending, feminine));
    return parts.join(' ');
}
/**
 * Número entero (0 – 999.999.999.999) en letra. Con beforeNoun usa "un"/"veintiún"; con
 * feminine, "una"/"veintiuna"/"doscientas". "Millón" es masculino: "doscientos millones de libras".
 */
function integerToWords(n, beforeNoun = false, feminine = false) {
    if (n === 0)
        return 'cero';
    const ending = !beforeNoun ? 'uno' : feminine ? 'una' : 'un';
    const millions = Math.floor(n / 1e6);
    const rest = n % 1e6;
    const parts = [];
    if (millions)
        parts.push(millions === 1 ? 'un millón' : `${below1e6(millions, 'un', false)} millones`);
    if (rest)
        parts.push(below1e6(rest, ending, feminine));
    return parts.join(' ');
}
// --- Letra en inglés (británico: "two hundred and fifty") -------------------
const EN_ONES = [
    'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve',
    'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen',
];
const EN_TENS = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
const EN_SCALES = ['', 'thousand', 'million', 'billion'];
const below100En = (n) => n < 20 ? EN_ONES[n] : `${EN_TENS[Math.floor(n / 10)]}${n % 10 ? `-${EN_ONES[n % 10]}` : ''}`;
function below1000En(n) {
    const h = Math.floor(n / 100);
    const rest = n % 100;
    const parts = [];
    if (h)
        parts.push(`${EN_ONES[h]} hundred`);
    if (rest)
        parts.push(`${h ? 'and ' : ''}${below100En(rest)}`);
    return parts.join(' ');
}
/** Número entero (0 – 999.999.999.999) en inglés británico: "one thousand and five". */
function integerToWordsEn(n) {
    if (n === 0)
        return 'zero';
    const words = [];
    for (let rest = n, scale = 0; rest > 0; rest = Math.floor(rest / 1000), scale++) {
        const group = rest % 1000;
        if (!group)
            continue;
        const text = scale === 0 && group < 100 && n >= 1000 ? `and ${below100En(group)}` : below1000En(group);
        words.unshift(EN_SCALES[scale] ? `${text} ${EN_SCALES[scale]}` : text);
    }
    return words.join(' ');
}
/**
 * Importe en letra, en minúsculas:
 * - 1250.5 EUR, es → "mil doscientos cincuenta euros con cincuenta céntimos"
 * - 1250.5 GBP, en → "one thousand two hundred and fifty pounds and fifty pence"
 *
 * Devuelve '' si el importe no está entre 0 y 999.999.999.999,99 o si no hay nombres para la moneda.
 */
function amountToWords(amount, options = {}) {
    const language = options.language ?? 'es';
    const names = options.words ?? CURRENCY_WORDS[language]?.[options.currency ?? 'EUR'];
    if (!names || !Number.isFinite(amount) || amount < 0 || amount >= 1e12)
        return '';
    const totalCents = Math.round(amount * 100);
    const units = Math.floor(totalCents / 100);
    const cents = totalCents % 100;
    const parts = [];
    if (language === 'en') {
        if (units > 0 || cents === 0)
            parts.push(`${integerToWordsEn(units)} ${units === 1 ? names.singular : names.plural}`);
        if (cents > 0)
            parts.push(`${integerToWordsEn(cents)} ${cents === 1 ? names.centSingular : names.centPlural}`);
        return parts.join(' and ');
    }
    if (units > 0 || cents === 0) {
        // "un millón de euros", pero "un millón cien euros".
        const linker = units >= 1e6 && units % 1e6 === 0 ? ' de' : '';
        parts.push(`${integerToWords(units, true, !!names.feminine)}${linker} ${units === 1 ? names.singular : names.plural}`);
    }
    if (cents > 0) {
        parts.push(`${integerToWords(cents, true, !!names.centFeminine)} ${cents === 1 ? names.centSingular : names.centPlural}`);
    }
    return parts.join(' con ');
}

/**
 * Importe. Mientras se edita muestra el texto tal cual ("1500,75"); al salir lo formatea
 * ("1.500,75 €" o "£1,500.75") y debajo escribe el importe en letra. El modelo guarda un number; si
 * el texto no se puede leer, guarda el texto para que los validadores currencyFormat/currencyDecimals
 * lo marquen como inválido.
 *
 * Props (el adaptador las resuelve con la config de provideDynamicForms({ currency })): currency
 * (ISO 4217), numberFormat ('es' | 'en'), wordsLanguage ('es' | 'en'), amountInWords, wordsUppercase
 * y currencyWords (nombres de una moneda que no esté incluida).
 *
 * Sin [formControl]: el input muestra un texto distinto del valor del modelo, así que el valor se
 * escribe a mano en el elemento.
 */
class CurrencyFieldComponent extends FieldType {
    input;
    destroyRef = inject(DestroyRef);
    focused = false;
    ngAfterViewInit() {
        this.render();
        // Cambios que no vienen del usuario (reset, modelo inicial cargado después…).
        this.formControl.valueChanges
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => { if (!this.focused)
            this.render(); });
    }
    get currency() {
        return this.props['currency'] ?? 'EUR';
    }
    get numberFormat() {
        return this.props['numberFormat'] ?? 'es';
    }
    get words() {
        const value = this.formControl.value;
        if (this.props['amountInWords'] === false || typeof value !== 'number')
            return '';
        const language = this.props['wordsLanguage'] ?? 'es';
        const words = amountToWords(value, {
            currency: this.currency,
            language,
            words: this.props['currencyWords'],
        });
        return this.props['wordsUppercase'] === false ? words : words.toLocaleUpperCase(language === 'en' ? 'en-GB' : 'es-ES');
    }
    onFocus() {
        this.focused = true;
        const value = this.formControl.value;
        if (typeof value === 'number')
            this.input.nativeElement.value = editableAmount(value, this.numberFormat);
    }
    onInput(text) {
        const parsed = parseAmount(text, this.numberFormat, this.currency);
        this.formControl.setValue(parsed.ok ? parsed.value : text);
        this.formControl.markAsDirty();
    }
    onBlur() {
        this.focused = false;
        this.formControl.markAsTouched();
        this.render();
    }
    /** Pinta el valor del control: formateado si es un importe, tal cual si es texto inválido. */
    render() {
        const value = this.formControl.value;
        this.input.nativeElement.value =
            typeof value === 'number' ? formatAmount(value, this.currency, this.numberFormat) : value == null ? '' : String(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: CurrencyFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: CurrencyFieldComponent, isStandalone: true, selector: "df-currency-field", viewQueries: [{ propertyName: "input", first: true, predicate: ["input"], descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: "<input\n  #input\n  type=\"text\"\n  inputmode=\"decimal\"\n  autocomplete=\"off\"\n  class=\"df-control df-currency\"\n  [formlyAttributes]=\"field\"\n  [disabled]=\"formControl.disabled\"\n  [readonly]=\"props.readonly === true\"\n  [attr.placeholder]=\"props.placeholder\"\n  [attr.aria-invalid]=\"showError\"\n  [attr.aria-describedby]=\"words ? id + '-words' : null\"\n  (focus)=\"onFocus()\"\n  (input)=\"onInput(input.value)\"\n  (blur)=\"onBlur()\" />\n@if (words) {\n  <small class=\"df-currency__words\" [id]=\"id + '-words'\">{{ words }}</small>\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}.df-currency{text-align:right;font-variant-numeric:tabular-nums}.df-currency__words{display:block;margin-top:.35rem;font-size:.8rem;font-weight:500;color:var(--df-color-text)}\n"], dependencies: [{ kind: "ngmodule", type: FormlyModule }, { kind: "directive", type: i2.LegacyFormlyAttributes, selector: "[formlyAttributes]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: CurrencyFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-currency-field', standalone: true, imports: [FormlyModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<input\n  #input\n  type=\"text\"\n  inputmode=\"decimal\"\n  autocomplete=\"off\"\n  class=\"df-control df-currency\"\n  [formlyAttributes]=\"field\"\n  [disabled]=\"formControl.disabled\"\n  [readonly]=\"props.readonly === true\"\n  [attr.placeholder]=\"props.placeholder\"\n  [attr.aria-invalid]=\"showError\"\n  [attr.aria-describedby]=\"words ? id + '-words' : null\"\n  (focus)=\"onFocus()\"\n  (input)=\"onInput(input.value)\"\n  (blur)=\"onBlur()\" />\n@if (words) {\n  <small class=\"df-currency__words\" [id]=\"id + '-words'\">{{ words }}</small>\n}\n", styles: [":host{display:block}.df-control{box-sizing:border-box;width:100%;padding:var(--df-control-padding);font:var(--df-font);font-size:.95rem;color:var(--df-color-text);background:var(--df-color-surface);border:1px solid var(--df-color-border);border-radius:var(--df-radius);transition:border-color .15s,box-shadow .15s}.df-control:focus{outline:none;border-color:var(--df-color-primary);box-shadow:0 0 0 3px var(--df-color-focus)}.df-control[aria-invalid=true]{border-color:var(--df-color-danger)}.df-control:disabled,.df-control[readonly]{background:color-mix(in srgb,var(--df-color-surface) 85%,var(--df-color-border));cursor:not-allowed}.df-currency{text-align:right;font-variant-numeric:tabular-nums}.df-currency__words{display:block;margin-top:.35rem;font-size:.8rem;font-weight:500;color:var(--df-color-text)}\n"] }]
        }], propDecorators: { input: [{
                type: ViewChild,
                args: ['input', { static: true }]
            }] } });

/** Lee el valor numérico de una celda: un number, o el texto de un importe si se puede leer. */
function toNumber$1(value, total) {
    if (typeof value === 'number')
        return Number.isFinite(value) ? value : null;
    if (typeof value !== 'string' || value.trim() === '')
        return null;
    const parsed = parseAmount(value, total.numberFormat, total.currency);
    return parsed.ok ? parsed.value : null;
}
const filled = (v) => v != null && v !== '' && !(typeof v === 'number' && Number.isNaN(v));
/** Calcula un total sobre las filas; null si no hay valores con los que calcular (media, mínimo, máximo). */
function computeTotal(rows, total) {
    const list = Array.isArray(rows) ? rows : [];
    const cell = (row) => (total.field && row ? row[total.field] : undefined);
    if (total.op === 'count')
        return total.field ? list.filter((r) => filled(cell(r))).length : list.length;
    const values = list.map((r) => toNumber$1(cell(r), total)).filter((v) => v !== null);
    if (total.op === 'sum')
        return Math.round(values.reduce((a, b) => a + b, 0) * 100) / 100;
    if (values.length === 0)
        return null;
    if (total.op === 'avg')
        return Math.round((values.reduce((a, b) => a + b, 0) / values.length) * 100) / 100;
    return total.op === 'min' ? Math.min(...values) : Math.max(...values);
}
/** "1.500,75 €" si el total viene de un campo currency; "1.500,75" si no; "—" sin valor. */
function formatTotal(value, total) {
    if (value === null)
        return '—';
    if (total.op === 'count' || !total.currency)
        return formatNumber(value, total.numberFormat);
    return formatAmount(value, total.currency, total.numberFormat);
}

/** Lista repetible (nodo `array`): una fila por elemento, con botones para añadir y quitar. */
class RepeatFieldComponent extends FieldArrayType {
    host = inject(ElementRef);
    /**
     * Las celdas de una tabla no llevan etiqueta (la pone la cabecera). En un contenedor estrecho las celdas se
     * apilan y la etiqueta sale de `data-label` (ver _grid.scss); las filas de tabla no pueden ocultar campos,
     * así que la celda N de cada fila es la columna N.
     */
    ngAfterViewChecked() {
        if (!this.isTable)
            return;
        const cols = this.columns;
        this.host.nativeElement.querySelectorAll('.df-table-row').forEach((row) => {
            Array.from(row.children).forEach((cell, i) => {
                const c = cols[i];
                const label = c ? c.label + (c.required ? ' *' : '') : '';
                if (cell.getAttribute('data-label') !== label)
                    cell.setAttribute('data-label', label);
            });
        });
    }
    get isTable() {
        return this.props['display'] === 'table';
    }
    get columns() {
        return this.props['tableColumns'] ?? [];
    }
    /** Plantilla de columnas de la rejilla de la tabla: el `col` de cada campo hace de peso relativo. */
    get tableTemplate() {
        return this.columns.map((c) => `minmax(0, ${c.col}fr)`).join(' ');
    }
    /** Ancho mínimo de la tabla (9rem por columna y el botón de quitar): por debajo de eso se desplaza en horizontal. */
    get tableMinWidth() {
        return `${this.columns.length * 9 + 2.25}rem`;
    }
    /** Totales calculados con las filas actuales: se recalculan en cada ciclo de detección. */
    get totals() {
        const defs = this.props['totals'] ?? [];
        const rows = this.formControl.value;
        return defs.map((t) => ({ label: t.label, text: formatTotal(computeTotal(rows, t), t) }));
    }
    get rowCount() {
        return this.field.fieldGroup?.length ?? 0;
    }
    get locked() {
        return this.props.disabled === true || this.props.readonly === true;
    }
    get canAdd() {
        const max = this.props['maxItems'];
        return !this.locked && (max == null || this.rowCount < max);
    }
    get canRemove() {
        const min = this.props['minItems'] ?? 0;
        return !this.locked && this.rowCount > min;
    }
    rowTitle(index) {
        return `${this.props['itemLabel'] || 'Elemento'} ${index + 1}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: RepeatFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: RepeatFieldComponent, isStandalone: true, selector: "df-repeat-field", usesInheritance: true, ngImport: i0, template: "<div class=\"df-repeat\" [class.df-repeat--table]=\"isTable\" [style.--df-table-cols]=\"tableTemplate\" [style.--df-table-min]=\"isTable ? tableMinWidth : null\">\n  @if (props.label) {\n    <div class=\"df-repeat__title\">{{ props.label }}</div>\n  }\n  @if (props.description) {\n    <p class=\"df-repeat__description\">{{ props.description }}</p>\n  }\n\n  @if (isTable && rowCount > 0) {\n    <div class=\"df-repeat__head\" aria-hidden=\"true\">\n      <div class=\"df-repeat__cols\">\n        @for (c of columns; track $index) {\n          <span class=\"df-repeat__th\">\n            {{ c.label }}\n            @if (c.required) { <span class=\"df-required\">*</span> }\n          </span>\n        }\n      </div>\n    </div>\n  }\n\n  @for (item of field.fieldGroup; track $index; let i = $index) {\n    <div class=\"df-repeat__row\" role=\"group\" [attr.aria-label]=\"rowTitle(i)\">\n      @if (!isTable) {\n        <div class=\"df-repeat__row-head\">\n          <span class=\"df-repeat__row-title\">{{ rowTitle(i) }}</span>\n          @if (!locked) {\n            <button type=\"button\" class=\"df-btn df-repeat__remove\" [disabled]=\"!canRemove\" (click)=\"remove(i)\">\n              {{ props['removeLabel'] || 'Eliminar' }}\n            </button>\n          }\n        </div>\n      }\n      <div class=\"df-repeat__cells\">\n        <formly-field [field]=\"item\"></formly-field>\n      </div>\n      @if (isTable && !locked) {\n        <button\n          type=\"button\"\n          class=\"df-btn df-repeat__remove df-repeat__remove--icon\"\n          [disabled]=\"!canRemove\"\n          [attr.aria-label]=\"(props['removeLabel'] || 'Eliminar') + ' ' + rowTitle(i)\"\n          (click)=\"remove(i)\">\n          \u00D7\n        </button>\n      }\n    </div>\n  }\n\n  @if (totals.length) {\n    <dl class=\"df-repeat__totals\">\n      @for (t of totals; track $index) {\n        <div class=\"df-repeat__total\">\n          <dt>{{ t.label }}</dt>\n          <dd>{{ t.text }}</dd>\n        </div>\n      }\n    </dl>\n  }\n\n  @if (!locked) {\n    <button type=\"button\" class=\"df-btn df-repeat__add\" [disabled]=\"!canAdd\" (click)=\"add()\">\n      + {{ props['addLabel'] || 'A\u00F1adir' }}\n    </button>\n  }\n\n  @if (showError) {\n    <div class=\"df-error df-repeat__error\" role=\"alert\">\n      <formly-validation-message [field]=\"field\"></formly-validation-message>\n    </div>\n  }\n</div>\n", styles: [":host{display:block}.df-repeat{margin-bottom:var(--df-field-gap)}.df-repeat__title{font-weight:600;color:var(--df-color-text);margin-bottom:.25rem}.df-repeat__description{margin:0 0 .75rem;font-size:.85rem;color:var(--df-color-muted)}.df-repeat__row{border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);padding:.75rem 1rem 0;margin-bottom:.75rem;min-width:0}.df-repeat__row-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:.75rem}.df-repeat__row-title{font-weight:600;font-size:var(--df-label-size)}.df-repeat__remove,.df-repeat__add{cursor:pointer;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);color:var(--df-color-text);padding:.35rem .75rem;font:inherit}.df-repeat__remove:disabled,.df-repeat__add:disabled{opacity:.5;cursor:not-allowed}.df-repeat__remove{color:var(--df-color-danger)}.df-repeat__totals{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:.25rem 1.5rem;margin:0 0 .75rem;padding:.5rem .25rem 0;border-top:1px solid var(--df-color-border)}.df-repeat__total{display:flex;gap:.5rem;align-items:baseline}.df-repeat__total dt{font-size:var(--df-label-size);color:var(--df-color-muted)}.df-repeat__total dd{margin:0;font-weight:600;color:var(--df-color-text);font-variant-numeric:tabular-nums}.df-repeat__error{margin-top:.35rem}.df-repeat--table .df-repeat__head,.df-repeat--table .df-repeat__row{display:grid;grid-template-columns:minmax(0,1fr) 2.25rem;column-gap:var(--df-grid-gap)}.df-repeat--table{overflow-x:auto}.df-repeat--table .df-repeat__head,.df-repeat--table .df-repeat__row{min-width:var(--df-table-min, 0)}.df-repeat--table .df-repeat__head{margin-bottom:.35rem}.df-repeat--table .df-repeat__row{border:0;border-radius:0;background:transparent;padding:0;margin-bottom:0;align-items:start}.df-repeat__cols{display:grid;grid-template-columns:var(--df-table-cols);gap:var(--df-grid-gap)}.df-repeat__th{font-size:var(--df-label-size);font-weight:600;color:var(--df-color-text)}.df-repeat--table .df-repeat__remove--icon{padding:.35rem 0;line-height:1.4;margin-top:.1rem}@container df-form (max-width: 640px){.df-repeat--table{overflow-x:visible}.df-repeat--table .df-repeat__head{display:none}.df-repeat--table .df-repeat__row{min-width:0;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);padding:.75rem .75rem 0;margin-bottom:.75rem}}\n"], dependencies: [{ kind: "ngmodule", type: FormlyModule }, { kind: "component", type: i2.LegacyFormlyField, selector: "formly-field" }, { kind: "component", type: i2.LegacyFormlyValidationMessage, selector: "formly-validation-message" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: RepeatFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-repeat-field', standalone: true, imports: [FormlyModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"df-repeat\" [class.df-repeat--table]=\"isTable\" [style.--df-table-cols]=\"tableTemplate\" [style.--df-table-min]=\"isTable ? tableMinWidth : null\">\n  @if (props.label) {\n    <div class=\"df-repeat__title\">{{ props.label }}</div>\n  }\n  @if (props.description) {\n    <p class=\"df-repeat__description\">{{ props.description }}</p>\n  }\n\n  @if (isTable && rowCount > 0) {\n    <div class=\"df-repeat__head\" aria-hidden=\"true\">\n      <div class=\"df-repeat__cols\">\n        @for (c of columns; track $index) {\n          <span class=\"df-repeat__th\">\n            {{ c.label }}\n            @if (c.required) { <span class=\"df-required\">*</span> }\n          </span>\n        }\n      </div>\n    </div>\n  }\n\n  @for (item of field.fieldGroup; track $index; let i = $index) {\n    <div class=\"df-repeat__row\" role=\"group\" [attr.aria-label]=\"rowTitle(i)\">\n      @if (!isTable) {\n        <div class=\"df-repeat__row-head\">\n          <span class=\"df-repeat__row-title\">{{ rowTitle(i) }}</span>\n          @if (!locked) {\n            <button type=\"button\" class=\"df-btn df-repeat__remove\" [disabled]=\"!canRemove\" (click)=\"remove(i)\">\n              {{ props['removeLabel'] || 'Eliminar' }}\n            </button>\n          }\n        </div>\n      }\n      <div class=\"df-repeat__cells\">\n        <formly-field [field]=\"item\"></formly-field>\n      </div>\n      @if (isTable && !locked) {\n        <button\n          type=\"button\"\n          class=\"df-btn df-repeat__remove df-repeat__remove--icon\"\n          [disabled]=\"!canRemove\"\n          [attr.aria-label]=\"(props['removeLabel'] || 'Eliminar') + ' ' + rowTitle(i)\"\n          (click)=\"remove(i)\">\n          \u00D7\n        </button>\n      }\n    </div>\n  }\n\n  @if (totals.length) {\n    <dl class=\"df-repeat__totals\">\n      @for (t of totals; track $index) {\n        <div class=\"df-repeat__total\">\n          <dt>{{ t.label }}</dt>\n          <dd>{{ t.text }}</dd>\n        </div>\n      }\n    </dl>\n  }\n\n  @if (!locked) {\n    <button type=\"button\" class=\"df-btn df-repeat__add\" [disabled]=\"!canAdd\" (click)=\"add()\">\n      + {{ props['addLabel'] || 'A\u00F1adir' }}\n    </button>\n  }\n\n  @if (showError) {\n    <div class=\"df-error df-repeat__error\" role=\"alert\">\n      <formly-validation-message [field]=\"field\"></formly-validation-message>\n    </div>\n  }\n</div>\n", styles: [":host{display:block}.df-repeat{margin-bottom:var(--df-field-gap)}.df-repeat__title{font-weight:600;color:var(--df-color-text);margin-bottom:.25rem}.df-repeat__description{margin:0 0 .75rem;font-size:.85rem;color:var(--df-color-muted)}.df-repeat__row{border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);padding:.75rem 1rem 0;margin-bottom:.75rem;min-width:0}.df-repeat__row-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:.75rem}.df-repeat__row-title{font-weight:600;font-size:var(--df-label-size)}.df-repeat__remove,.df-repeat__add{cursor:pointer;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);color:var(--df-color-text);padding:.35rem .75rem;font:inherit}.df-repeat__remove:disabled,.df-repeat__add:disabled{opacity:.5;cursor:not-allowed}.df-repeat__remove{color:var(--df-color-danger)}.df-repeat__totals{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:.25rem 1.5rem;margin:0 0 .75rem;padding:.5rem .25rem 0;border-top:1px solid var(--df-color-border)}.df-repeat__total{display:flex;gap:.5rem;align-items:baseline}.df-repeat__total dt{font-size:var(--df-label-size);color:var(--df-color-muted)}.df-repeat__total dd{margin:0;font-weight:600;color:var(--df-color-text);font-variant-numeric:tabular-nums}.df-repeat__error{margin-top:.35rem}.df-repeat--table .df-repeat__head,.df-repeat--table .df-repeat__row{display:grid;grid-template-columns:minmax(0,1fr) 2.25rem;column-gap:var(--df-grid-gap)}.df-repeat--table{overflow-x:auto}.df-repeat--table .df-repeat__head,.df-repeat--table .df-repeat__row{min-width:var(--df-table-min, 0)}.df-repeat--table .df-repeat__head{margin-bottom:.35rem}.df-repeat--table .df-repeat__row{border:0;border-radius:0;background:transparent;padding:0;margin-bottom:0;align-items:start}.df-repeat__cols{display:grid;grid-template-columns:var(--df-table-cols);gap:var(--df-grid-gap)}.df-repeat__th{font-size:var(--df-label-size);font-weight:600;color:var(--df-color-text)}.df-repeat--table .df-repeat__remove--icon{padding:.35rem 0;line-height:1.4;margin-top:.1rem}@container df-form (max-width: 640px){.df-repeat--table{overflow-x:visible}.df-repeat--table .df-repeat__head{display:none}.df-repeat--table .df-repeat__row{min-width:0;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);padding:.75rem .75rem 0;margin-bottom:.75rem}}\n"] }]
        }] });

/**
 * Plantilla propia para las celdas de las columnas con `template: "nombre"`:
 *
 *   <dynamic-form [schema]="schema">
 *     <ng-template dfCell="estado" let-row let-value="value"><app-estado [value]="value" /></ng-template>
 *   </dynamic-form>
 */
class DfCellDirective {
    name = input.required({ ...(ngDevMode ? { debugName: "name" } : /* istanbul ignore next */ {}), alias: 'dfCell' });
    template = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfCellDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.25", type: DfCellDirective, isStandalone: true, selector: "ng-template[dfCell]", inputs: { name: { classPropertyName: "name", publicName: "dfCell", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfCellDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[dfCell]', standalone: true }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "dfCell", required: true }] }] } });
/**
 * Plantilla propia para una tabla sin filas (en lugar de `emptyMessage`). `dfEmpty="id"` es para la tabla con ese `id`;
 * sin valor vale para todas las que no tengan una propia. El contexto es `let-table` (el `id` de la tabla).
 */
class DfEmptyDirective {
    table = input('', { ...(ngDevMode ? { debugName: "table" } : /* istanbul ignore next */ {}), alias: 'dfEmpty' });
    template = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfEmptyDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.25", type: DfEmptyDirective, isStandalone: true, selector: "ng-template[dfEmpty]", inputs: { table: { classPropertyName: "table", publicName: "dfEmpty", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfEmptyDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[dfEmpty]', standalone: true }]
        }], propDecorators: { table: [{ type: i0.Input, args: [{ isSignal: true, alias: "dfEmpty", required: false }] }] } });
/** Clave de `options.formState` por la que `<dynamic-form>` entrega a las tablas sus plantillas. */
const DF_TABLE_SLOTS = 'dfTableSlots';

/** Lee `a.b.c` de un objeto sin lanzar. */
function getByPath(model, path) {
    if (model == null || !path)
        return undefined;
    return path.split('.').reduce((acc, key) => {
        if (acc == null || typeof acc !== 'object')
            return undefined;
        return acc[key];
    }, model);
}
/** Prefijo de una ruta que lee del contexto externo (`<dynamic-form [context]>`): `ctx.modo`. */
const CONTEXT_PREFIX = 'ctx.';
/** Prefijo de una ruta relativa a la fila actual de una lista repetible: `./cantidad`. */
const RELATIVE_PREFIX = './';
const isBlank = (v) => v == null || v === '' || (Array.isArray(v) && v.length === 0);
/**
 * Evaluador declarativo (sin eval) del ConditionalLogicContract.
 */
class ConditionEvaluatorService {
    /**
     * `model` es el modelo raíz. `local` es el objeto de la fila actual cuando la regla está dentro de una
     * lista repetible: las rutas `./campo` se leen de ahí. `context` es el objeto externo de la app: las rutas `ctx.nombre`
     * se leen de él. El resto de rutas, de `model`.
     */
    evaluate(rule, model, local, context) {
        if (!rule)
            return false;
        if (this.isCondition(rule))
            return this.evaluateCondition(rule, model, local, context);
        return this.evaluateGroup(rule, model, local, context);
    }
    isCondition(rule) {
        return typeof rule.field === 'string';
    }
    evaluateGroup(group, model, local, context) {
        const checks = [];
        if (group.all)
            checks.push(group.all.every((r) => this.evaluate(r, model, local, context)));
        if (group.any)
            checks.push(group.any.some((r) => this.evaluate(r, model, local, context)));
        if (group.not)
            checks.push(!this.evaluate(group.not, model, local, context));
        return checks.length > 0 && checks.every(Boolean);
    }
    evaluateCondition(c, model, local, context) {
        const actual = c.field.startsWith(RELATIVE_PREFIX)
            ? getByPath(local, c.field.slice(RELATIVE_PREFIX.length))
            : c.field.startsWith(CONTEXT_PREFIX)
                ? getByPath(context, c.field.slice(CONTEXT_PREFIX.length))
                : getByPath(model, c.field);
        const expected = c.value;
        switch (c.operator) {
            case 'eq': return actual === expected || (isBlank(actual) && isBlank(expected));
            case 'neq': return !(actual === expected || (isBlank(actual) && isBlank(expected)));
            case 'in': return Array.isArray(expected) && expected.includes(actual);
            case 'nin': return Array.isArray(expected) && !expected.includes(actual);
            case 'gt': return Number(actual) > Number(expected);
            case 'gte': return Number(actual) >= Number(expected);
            case 'lt': return Number(actual) < Number(expected);
            case 'lte': return Number(actual) <= Number(expected);
            case 'empty': return isBlank(actual);
            case 'notEmpty': return !isBlank(actual);
            case 'truthy': return !!actual;
            case 'falsy': return !actual;
            case 'matches':
                try {
                    return typeof expected === 'string' && new RegExp(expected).test(String(actual ?? ''));
                }
                catch {
                    return false;
                }
            case 'contains':
                if (Array.isArray(actual))
                    return actual.includes(expected);
                return typeof actual === 'string' && actual.includes(String(expected));
            default:
                return false;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: ConditionEvaluatorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: ConditionEvaluatorService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: ConditionEvaluatorService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Modelo raíz del formulario desde cualquier campo (los grupos no tienen key). */
function rootModel(field) {
    let f = field;
    while (f.parent)
        f = f.parent;
    return f.model;
}
/** Lee la ruta de un campo: `./campo` de la fila que contiene a `field`; cualquier otra, del modelo raíz. */
function readPath(field, path) {
    return path.startsWith(RELATIVE_PREFIX)
        ? getByPath(field.model, path.slice(RELATIVE_PREFIX.length))
        : getByPath(rootModel(field), path);
}
/** El nombre de un parámetro: la ruta sin el `./` de las relativas. */
const paramName = (path) => (path.startsWith(RELATIVE_PREFIX) ? path.slice(RELATIVE_PREFIX.length) : path);
/** Clave de `options.formState` por la que `<dynamic-form>` entrega su `context` a los campos y las tablas. */
const DF_CONTEXT_KEY = 'dfContext';
/** Contexto externo del formulario (`<dynamic-form [context]>`), para las rutas `ctx.nombre` de las condiciones. */
function contextOf(field) {
    return field.options?.formState?.[DF_CONTEXT_KEY];
}

const pad = (n) => String(n).padStart(2, '0');
/** Fecha desde `yyyy-MM-dd`, `yyyy-MM-ddTHH:mm[:ss]` o `dd/MM/yyyy [HH:mm]`; la hora es local. */
function parseDate(value) {
    if (value instanceof Date)
        return Number.isNaN(value.getTime()) ? null : { date: value, hasTime: true };
    if (typeof value !== 'string')
        return null;
    const text = value.trim();
    const iso = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?/.exec(text);
    const es = /^(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2}))?$/.exec(text);
    const m = iso ? [iso[1], iso[2], iso[3], iso[4], iso[5]] : es ? [es[3], es[2], es[1], es[4], es[5]] : null;
    if (!m)
        return null;
    const [y, mo, d] = [Number(m[0]), Number(m[1]), Number(m[2])];
    const date = new Date(y, mo - 1, d, Number(m[3] ?? 0), Number(m[4] ?? 0));
    // Fechas imposibles (31/02) se desplazarían al mes siguiente: se descartan.
    if (date.getFullYear() !== y || date.getMonth() !== mo - 1 || date.getDate() !== d)
        return null;
    return { date, hasTime: m[3] != null };
}
/** El número de una celda: un number, o un texto numérico escrito con punto decimal ("1500.75"). */
function toNumber(value) {
    if (typeof value === 'number')
        return Number.isFinite(value) ? value : null;
    if (typeof value === 'string' && value.trim() !== '' && Number.isFinite(Number(value)))
        return Number(value);
    return null;
}
const plainText = (value) => {
    if (value == null)
        return '';
    if (Array.isArray(value))
        return value.map(plainText).filter(Boolean).join(', ');
    if (typeof value === 'object')
        return '';
    return String(value);
};
/** El texto de un fragmento HTML, sin etiquetas. El documento de `DOMParser` es inerte: no ejecuta ni carga nada. */
function htmlToText(html) {
    if (typeof DOMParser === 'undefined')
        return html.replace(/<[^>]*>/g, '');
    return (new DOMParser().parseFromString(html, 'text/html').body.textContent ?? '').replace(/\s+/g, ' ').trim();
}
/** Lo que se ve en la celda. Un valor que no encaja con el tipo de la columna se muestra tal cual. */
function formatCell(value, col) {
    if (value == null || value === '')
        return '';
    switch (col.type) {
        case 'number': {
            const n = toNumber(value);
            return n === null ? plainText(value) : formatNumber(n, col.numberFormat);
        }
        case 'currency': {
            const n = toNumber(value);
            return n === null ? plainText(value) : formatAmount(n, col.currency, col.numberFormat);
        }
        case 'date':
        case 'datetime': {
            const parsed = parseDate(value);
            if (!parsed)
                return plainText(value);
            const { date, hasTime } = parsed;
            const day = `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()}`;
            return col.type === 'datetime' && hasTime ? `${day} ${pad(date.getHours())}:${pad(date.getMinutes())}` : day;
        }
        case 'boolean':
            return value === true || value === 'true' ? 'Sí' : value === false || value === 'false' ? 'No' : plainText(value);
        case 'map':
        case 'badge':
            return col.map?.[plainText(value)] ?? plainText(value);
        default:
            return col.html ? htmlToText(plainText(value)) : plainText(value);
    }
}
const cellText = (row, col) => formatCell(getByPath(row, col.key), col);
/** Minúsculas sin acentos: "Peña" y "pena" se buscan igual. */
const normalize$1 = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
function filterRows(rows, cols, text, extraKeys = []) {
    const needle = normalize$1(text.trim());
    if (!needle)
        return rows;
    const extra = (row, key) => {
        const v = getByPath(row, key);
        return v == null || typeof v === 'object' ? '' : String(v);
    };
    return rows.filter((row) => cols.some((c) => normalize$1(cellText(row, c)).includes(needle))
        || extraKeys.some((k) => normalize$1(extra(row, k)).includes(needle)));
}
/** Destino de una celda `link`: `{clave}` se sustituye por la propiedad de la fila; null si falta alguna o no hay `href`. */
function resolveHref(row, href) {
    if (!href)
        return null;
    let missing = false;
    const out = href.replace(/\{([\w.]+)\}/g, (_, key) => {
        const v = getByPath(row, key);
        if (v == null || v === '' || typeof v === 'object') {
            missing = true;
            return '';
        }
        return encodeURIComponent(String(v));
    });
    return missing ? null : out;
}
/** Cómo se filtra una columna: escribiendo texto, o eligiendo un valor (`map`, `badge` y `boolean`). */
const columnFilterKind = (col) => col.type === 'map' || col.type === 'badge' || col.type === 'boolean' ? 'select' : 'text';
/** Opciones del desplegable de una columna `map` o `boolean`; `value` es lo que se envía como filtro. */
function columnFilterOptions(col) {
    if (col.type === 'boolean')
        return [{ value: 'true', label: 'Sí' }, { value: 'false', label: 'No' }];
    if (col.type === 'badge' && !col.map)
        return Object.keys(col.variants ?? {}).map((value) => ({ value, label: value }));
    return Object.entries(col.map ?? {}).map(([value, label]) => ({ value, label }));
}
/** El valor de una celda `map` o `boolean` tal como se envía en el filtro (`""` si está vacía). */
function filterValue(row, col) {
    const value = getByPath(row, col.key);
    if (value == null || value === '')
        return '';
    if (col.type === 'boolean')
        return value === true || value === 'true' ? 'true' : value === false || value === 'false' ? 'false' : '';
    return plainText(value);
}
/** Filas que cumplen todos los filtros por columna (`key` → texto o valor elegido); ignora los vacíos. */
function filterByColumns(rows, cols, filters) {
    const active = cols.filter((c) => c.filter && (filters[c.key] ?? '').trim() !== '');
    if (!active.length)
        return rows;
    return rows.filter((row) => active.every((c) => {
        const wanted = (filters[c.key] ?? '').trim();
        return columnFilterKind(c) === 'select'
            ? filterValue(row, c) === wanted
            : normalize$1(cellText(row, c)).includes(normalize$1(wanted));
    }));
}
/** Valor por el que se ordena una celda: número, texto o null (las celdas vacías van siempre al final). */
function sortValue(row, col) {
    const value = getByPath(row, col.key);
    if (value == null || value === '')
        return null;
    switch (col.type) {
        case 'number':
        case 'currency':
            return toNumber(value) ?? normalize$1(plainText(value));
        case 'date':
        case 'datetime':
            return parseDate(value)?.date.getTime() ?? normalize$1(plainText(value));
        case 'boolean':
            return value === true || value === 'true' ? 1 : 0;
        default:
            return normalize$1(formatCell(value, col));
    }
}
function sortRows(rows, col, direction) {
    return sortRowsBy(rows, [{ col, direction }]);
}
/** Ordena por varias columnas: la primera manda y cada una desempata a la anterior. Los vacíos van al final en cualquier sentido. */
function sortRowsBy(rows, sorts) {
    const keyed = rows.map((row, index) => ({ row, index, values: sorts.map((s) => sortValue(row, s.col)) }));
    keyed.sort((a, b) => {
        for (let i = 0; i < sorts.length; i++) {
            const [x, y] = [a.values[i], b.values[i]];
            if (x === null || y === null) {
                if (x === y)
                    continue;
                return x === null ? 1 : -1;
            }
            const diff = typeof x === 'number' && typeof y === 'number'
                ? x - y
                : String(x).localeCompare(String(y), 'es', { numeric: true });
            if (diff !== 0)
                return diff * (sorts[i].direction === 'asc' ? 1 : -1);
        }
        return a.index - b.index;
    });
    return keyed.map((k) => k.row);
}

/** Separador de columnas: el de Excel con configuración regional española. */
const SEPARATOR = ';';
/** Marca de orden de bytes: sin ella Excel abre el UTF-8 como ANSI y estropea las tildes y la eñe. */
const BOM = '\uFEFF';
/**
 * Un texto que empieza por `=`, `+`, `@` o un control, o por `-` y algo que no es un número, lo evalúa Excel
 * como fórmula. Se antepone `'` para que se quede como texto.
 */
function neutralize(text) {
    return /^[=+@\t\r]|^-(?![\d.,\s])/.test(text) ? `'${text}` : text;
}
function field(text) {
    const safe = neutralize(text);
    return /[";\r\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
}
/** CSV de las filas con lo que se ve en cada celda (importes y fechas ya formateados). Líneas con CRLF. */
function toCsv(rows, cols) {
    const lines = [cols.map((c) => field(c.label)), ...rows.map((r) => cols.map((c) => field(cellText(r, c))))];
    return BOM + lines.map((l) => l.join(SEPARATOR)).join('\r\n') + '\r\n';
}
/** Nombre de fichero seguro con extensión `.csv`: sin rutas ni caracteres raros. */
function csvFileName(name) {
    const base = name.replace(/\.csv$/i, '').replace(/[^A-Za-z0-9_. -]/g, '_').replace(/^[. ]+/, '').slice(0, 100);
    return `${base || 'tabla'}.csv`;
}

/** Trazados SVG (viewBox 24, relleno `currentColor`) de los iconos incluidos para las acciones de fila. */
const PATHS = {
    view: 'M12 5c-5 0-9 4.5-10 7 1 2.5 5 7 10 7s9-4.5 10-7c-1-2.5-5-7-10-7zm0 11.5a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9zm0-7a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z',
    edit: 'M3 17.25V21h3.75L17.8 9.94l-3.75-3.75L3 17.25zM20.7 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
    delete: 'M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
    download: 'M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z',
    add: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
    check: 'M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z',
    close: 'M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z',
};
/** Trazado del icono incluido con ese nombre, o null si no existe (entonces se pinta el texto tal cual). */
const tableIconPath = (name) => Object.prototype.hasOwnProperty.call(PATHS, name) ? PATHS[name] : null;

const DEFAULT_TABLE_TEXTS = {
    search: 'Buscar',
    actions: 'Acciones',
    loading: 'Cargando…',
    retry: 'Reintentar',
    empty: 'No hay datos',
    error: 'No se pudieron cargar los datos',
    noResults: 'Ningún resultado para «{text}»',
    noResultsFiltered: 'Ningún resultado con los filtros aplicados',
    rowsPerPage: 'Filas por página',
    previousPage: 'Página anterior',
    nextPage: 'Página siguiente',
    range: '{from}–{to} de {total}',
    all: 'Todos',
    filterBy: 'Filtrar por {label}',
    pinColumn: 'Fijar la columna {label}',
    unpinColumn: 'Soltar la columna {label}',
    reorderHint: 'Arrastra para mover la columna, o Alt + flechas con el teclado',
    resizeColumn: 'Cambiar el ancho de la columna {label} (flechas izquierda y derecha)',
    selectAll: 'Seleccionar todas las filas',
    selectRow: 'Seleccionar fila',
    exportCsv: 'Exportar CSV',
    exportSelection: 'Exportar selección ({n})',
    exporting: 'Exportando…',
    exportFailed: 'No se pudo exportar',
};
/** Juego completo en inglés: `provideDynamicForms({ tableTexts: EN_TABLE_TEXTS })`. */
const EN_TABLE_TEXTS = {
    search: 'Search',
    actions: 'Actions',
    loading: 'Loading…',
    retry: 'Retry',
    empty: 'No data',
    error: 'The data could not be loaded',
    noResults: 'No results for «{text}»',
    noResultsFiltered: 'No results with the applied filters',
    rowsPerPage: 'Rows per page',
    previousPage: 'Previous page',
    nextPage: 'Next page',
    range: '{from}–{to} of {total}',
    all: 'All',
    filterBy: 'Filter by {label}',
    pinColumn: 'Pin column {label}',
    unpinColumn: 'Unpin column {label}',
    reorderHint: 'Drag to move the column, or Alt + arrow keys on the keyboard',
    resizeColumn: 'Resize column {label} (left and right arrow keys)',
    selectAll: 'Select all rows',
    selectRow: 'Select row',
    exportCsv: 'Export CSV',
    exportSelection: 'Export selection ({n})',
    exporting: 'Exporting…',
    exportFailed: 'The export failed',
};
/** Rellena las `{llaves}` de un texto; una llave sin valor se queda tal cual. */
function fillText(template, values) {
    return template.replace(/\{(\w+)\}/g, (m, k) => (k in values ? String(values[k]) : m));
}

/** Claves de `widths` para la columna de casillas y la de acciones. */
const WIDTH_CHECK = '__check';
const WIDTH_ACTIONS = '__actions';
const MIN_WIDTH = 48;
const MAX_WIDTH = 4000;
const isPlainObject = (v) => !!v && typeof v === 'object' && !Array.isArray(v);
/** Lee el JSON guardado sin fiarse de él: solo se queda lo que tiene la forma esperada y encaja con la tabla. */
function parseTableState(raw, ctx) {
    let data;
    try {
        data = raw ? JSON.parse(raw) : null;
    }
    catch {
        return {};
    }
    if (!isPlainObject(data))
        return {};
    const state = {};
    // `sort` (un solo orden, o null) es el formato de antes de `multiSort`; se sigue leyendo.
    const stored = Array.isArray(data['sorts']) ? data['sorts'] : data['sort'] === null ? [] : isPlainObject(data['sort']) ? [data['sort']] : null;
    if (stored) {
        const seen = new Set();
        state.sorts = [];
        for (const s of stored) {
            if (!isPlainObject(s) || !ctx.columnKeys.includes(String(s['key'])) || seen.has(String(s['key'])))
                continue;
            seen.add(String(s['key']));
            state.sorts.push({ key: String(s['key']), direction: s['direction'] === 'desc' ? 'desc' : 'asc' });
        }
        // Un orden guardado cuya columna ya no existe vale como «sin orden» solo si el usuario no tenía otro: se descarta entero.
        if (stored.length && !state.sorts.length)
            delete state.sorts;
    }
    if (typeof data['filter'] === 'string')
        state.filter = data['filter'];
    if (isPlainObject(data['columnFilters'])) {
        const filters = {};
        for (const [k, v] of Object.entries(data['columnFilters'])) {
            if (typeof v === 'string' && ctx.filterKeys.includes(k))
                filters[k] = v;
        }
        state.columnFilters = filters;
    }
    if (typeof data['pageSize'] === 'number' && Number.isInteger(data['pageSize']) && data['pageSize'] >= 1)
        state.pageSize = data['pageSize'];
    if (ctx.pinnable && Array.isArray(data['pinned'])) {
        state.pinned = data['pinned'].filter((k) => typeof k === 'string' && ctx.columnKeys.includes(k));
    }
    if (ctx.reorderable && Array.isArray(data['order'])) {
        const keys = data['order'].filter((k) => typeof k === 'string' && ctx.columnKeys.includes(k));
        // Una columna nueva del esquema que no estaba guardada va al final.
        state.order = [...new Set(keys), ...ctx.columnKeys.filter((k) => !keys.includes(k))];
    }
    if (ctx.resizable && isPlainObject(data['widths'])) {
        const widths = {};
        for (const [k, v] of Object.entries(data['widths'])) {
            if ((ctx.columnKeys.includes(k) || k === WIDTH_CHECK || k === WIDTH_ACTIONS) && typeof v === 'number' && v >= MIN_WIDTH && v <= MAX_WIDTH)
                widths[k] = v;
        }
        // Los anchos valen para todas las columnas a la vez: si falta alguna (el esquema cambió), se descartan.
        if (ctx.columnKeys.every((k) => k in widths))
            state.widths = widths;
    }
    return state;
}

/** Clave de formState donde `<dynamic-form>` deja la función que recibe los eventos de las tablas. */
const DF_TABLE_EVENTS = 'dfTableEvents';
/** Clave de formState con el registro de tablas vivas (`tableId` → controles), que `<dynamic-form>` usa para `selectAll()` y `clearSelection()`. */
const DF_TABLE_CONTROLS = 'dfTableControls';
const DEFAULT_PAGE_SIZES = [5, 10, 25, 100];
/** Espera tras la última tecla antes de pedir al servidor las filas filtradas. */
const FILTER_DEBOUNCE_MS = 300;
/** Tabla de datos de solo lectura (nodo `table`): filtro, orden, paginación, acciones por fila y selección. */
class TableFieldComponent extends FieldType {
    provider = inject(DF_TABLE_PROVIDER, { optional: true });
    cdr = inject(ChangeDetectorRef);
    evaluator = inject(ConditionEvaluatorService);
    document = inject(DOCUMENT);
    host = inject(ElementRef);
    config = inject(DYNAMIC_FORMS_CONFIG, { optional: true });
    /** Últimos desplazamientos de las columnas fijas que se escribieron en el DOM. */
    frozenOffsets = '';
    destroyed$ = new Subject();
    /** Peticiones al servicio; null cancela la que esté en vuelo. switchMap descarta las respuestas viejas. */
    jobs$ = new Subject();
    /** Avisa de que el usuario tocó el buscador o un filtro de columna (modo server: se espera a que pare). */
    filterInput$ = new Subject();
    // Estado de la carga remota (source).
    loadState = 'idle';
    /** Filas que dio el servicio: todas (modo client) o solo la página actual (modo server). */
    remoteRows = [];
    /** Total de filas que cumplen el filtro en el servidor (modo server). */
    remoteTotal = 0;
    /** Faltan campos de `dependsOn` por rellenar: no se pide nada. */
    waiting = false;
    paramsKey = null;
    /** Filtro que ya se ha enviado al servidor (modo server). */
    appliedFilter = '';
    /** Filtros por columna que ya se han enviado al servidor (modo server). */
    appliedColumnFilters = {};
    filterText = '';
    /** Lo que el usuario ha escrito o elegido en los filtros de columna (`key` → valor). */
    columnFilters = {};
    /** Exportando: en modo server se piden al servicio todas las filas. */
    exporting = false;
    exportFailed = false;
    /** Orden actual: de la columna principal a la última que desempata (más de una solo con `multiSort`). */
    sorts = [];
    pageIndex = 0;
    /** Null hasta que el usuario cambia el tamaño; mientras, el del esquema. */
    pageSizeChoice = null;
    sortInitialised = false;
    /** Fila elegida con `selectable` simple. */
    selected = null;
    /** Filas marcadas con `selectable: 'multiple'`, por `selectionKey` o, sin ella, por objeto. */
    selection = new Map();
    // Resultado de filtrar y ordenar, recalculado solo si cambia algo de lo que depende.
    cache = null;
    /** Textos de la app (`provideDynamicForms({ tableTexts })`); lo que no define queda en español. */
    get texts() {
        return this.config?.tableTexts ?? DEFAULT_TABLE_TEXTS;
    }
    get noResultsText() {
        const text = this.filterText.trim();
        return text ? fillText(this.texts.noResults, { text: this.filterText }) : this.texts.noResultsFiltered;
    }
    filterAria(col) {
        return fillText(this.texts.filterBy, { label: col.label });
    }
    /** Columnas del esquema, en su orden y con su `frozen`. */
    get schemaColumns() {
        return this.props['columns'];
    }
    /**
     * Columnas que se pintan: las del esquema en el orden que el usuario eligió arrastrando (`orderKeys`) y, con
     * `pinnableColumns`, las que fijó (`pinnedKeys`) primero y en el orden en que las fijó. Las fijas van siempre
     * delante. Se cachea para que cada columna sea siempre el mismo objeto.
     */
    get columns() {
        const base = this.schemaColumns;
        const pinnedKeys = this.pinnable ? this.pinnedKeys : null;
        if (!pinnedKeys && !this.orderKeys)
            return base;
        const cached = this.columnsCache;
        if (cached && cached.base === base && cached.pinned === pinnedKeys && cached.order === this.orderKeys)
            return cached.result;
        const byKey = new Map(base.map((c) => [c.key, c]));
        const order = this.orderKeys;
        const ordered = order ? [...order.map((k) => byKey.get(k)), ...base.filter((c) => !order.includes(c.key))].filter((c) => !!c) : base;
        let result;
        if (pinnedKeys) {
            const pinned = pinnedKeys.map((k) => byKey.get(k)).filter((c) => !!c).map((c) => (c.frozen ? c : { ...c, frozen: true }));
            const rest = ordered.filter((c) => !pinnedKeys.includes(c.key)).map((c) => (c.frozen ? { ...c, frozen: false } : c));
            result = [...pinned, ...rest];
        }
        else {
            // Sin fijado del usuario las fijas son las del esquema, y van delante aunque el orden guardado las separe.
            result = [...ordered.filter((c) => c.frozen), ...ordered.filter((c) => !c.frozen)];
        }
        this.columnsCache = { base, pinned: pinnedKeys, order: this.orderKeys, result };
        return result;
    }
    get pinnable() {
        return this.props['pinnableColumns'] === true;
    }
    get reorderable() {
        return this.props['reorderableColumns'] === true;
    }
    /** Claves de las columnas fijas que el usuario dejó (null mientras no toque nada: manda el esquema). */
    pinnedKeys = null;
    /** Orden de todas las columnas que el usuario eligió arrastrando (null: el del esquema). */
    orderKeys = null;
    columnsCache = null;
    /** Columna que se está arrastrando, y la que tiene el cursor encima. */
    dragKey = null;
    dropKey = null;
    /** Tras mover una columna con el teclado el foco vuelve a su cabecera cuando ya está en su sitio. */
    refocusKey = null;
    column(key) {
        return key ? this.columns.find((c) => c.key === key) : undefined;
    }
    /** Solo se mueve entre columnas del mismo grupo: fijas con fijas, normales con normales. */
    canDrop(target) {
        const from = this.column(this.dragKey);
        return this.reorderable && !!from && from.key !== target.key && from.frozen === target.frozen;
    }
    onDragStart(event, col) {
        if (!this.reorderable)
            return;
        // Estirar un borde no debe arrastrar la columna.
        if (this.resize)
            return event.preventDefault();
        this.dragKey = col.key;
        if (event.dataTransfer) {
            event.dataTransfer.effectAllowed = 'move';
            // Firefox no arrastra nada si no hay datos.
            event.dataTransfer.setData('text/plain', col.key);
        }
    }
    onDragOver(event, col) {
        if (!this.canDrop(col))
            return;
        event.preventDefault();
        if (event.dataTransfer)
            event.dataTransfer.dropEffect = 'move';
        this.dropKey = col.key;
    }
    onDrop(event, col) {
        event.preventDefault();
        const from = this.dragKey;
        if (from && this.canDrop(col))
            this.moveColumn(from, col.key);
        this.onDragEnd();
    }
    onDragEnd() {
        this.dragKey = null;
        this.dropKey = null;
    }
    // --- Redimensionar columnas (resizableColumns) --------------------------------------
    get resizable() {
        return this.props['resizableColumns'] === true;
    }
    /** Anchos en px de cada columna una vez que el usuario cambia alguno (null: los del esquema, en %). */
    widths = null;
    resize = null;
    /** Ancho de una pista de `<colgroup>`: px si el usuario ya redimensionó, % del esquema si no. */
    colWidth(col) {
        return this.widths ? `${this.widths[col.key]}px` : `${this.width(col)}%`;
    }
    /** Ancho de la tabla entera: la suma de las pistas, para que sea más ancha que el contenedor y se desplace. */
    get tableWidth() {
        const w = this.widths;
        return w ? `${Object.values(w).reduce((sum, n) => sum + n, 0)}px` : null;
    }
    specialWidth(key) {
        const n = this.widths?.[key];
        return n ? `${n}px` : null;
    }
    resizeLabel(col) {
        return fillText(this.texts.resizeColumn, { label: col.label });
    }
    /** Toma los anchos que tienen ahora las celdas de la cabecera: de ahí parte cualquier cambio. */
    measureWidths() {
        const heads = Array.from(this.host.nativeElement.querySelectorAll('thead tr:first-child > th'));
        const out = {};
        let i = 0;
        if (this.multiple)
            out[WIDTH_CHECK] = heads[i++]?.offsetWidth || 36;
        for (const col of this.columns)
            out[col.key] = heads[i++]?.offsetWidth || 100;
        if (this.actions.length)
            out[WIDTH_ACTIONS] = heads[i]?.offsetWidth || 120;
        return out;
    }
    onResizeStart(event, col) {
        event.preventDefault();
        event.stopPropagation();
        const widths = this.widths ?? this.measureWidths();
        this.widths = widths;
        this.resize = { key: col.key, startX: event.clientX, startWidth: widths[col.key] };
        event.target.setPointerCapture?.(event.pointerId);
    }
    onResizeMove(event) {
        const r = this.resize;
        if (!r || !this.widths)
            return;
        this.setWidth(r.key, r.startWidth + event.clientX - r.startX);
    }
    onResizeEnd() {
        if (!this.resize)
            return;
        this.resize = null;
        this.saveState();
    }
    /** Con el borde enfocado, las flechas lo mueven 10 px (50 con Mayús). */
    onResizeKey(event, col) {
        if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight')
            return;
        event.preventDefault();
        event.stopPropagation();
        const widths = this.widths ?? this.measureWidths();
        this.widths = widths;
        this.setWidth(col.key, widths[col.key] + (event.key === 'ArrowRight' ? 1 : -1) * (event.shiftKey ? 50 : 10));
        this.saveState();
    }
    /** Doble clic en un borde: vuelven los anchos del esquema. */
    resetWidths(event) {
        event.stopPropagation();
        this.widths = null;
        this.saveState();
    }
    setWidth(key, width) {
        if (!this.widths)
            return;
        this.widths = { ...this.widths, [key]: Math.round(Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, width))) };
    }
    /** Alt + flecha izquierda o derecha en una cabecera mueve la columna un sitio, dentro de su grupo. */
    onHeaderKey(event, col) {
        if (!this.reorderable || !event.altKey || (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight'))
            return;
        event.preventDefault();
        const group = this.columns.filter((c) => c.frozen === col.frozen);
        const target = group[group.findIndex((c) => c.key === col.key) + (event.key === 'ArrowLeft' ? -1 : 1)];
        if (!target)
            return;
        this.moveColumn(col.key, target.key);
        this.refocusKey = col.key;
    }
    /** Pone `fromKey` en el sitio de `toKey`: una fija reordena las fijadas; una normal, el orden general. */
    moveColumn(fromKey, toKey) {
        const from = this.column(fromKey);
        if (!from)
            return;
        const move = (list) => {
            const out = list.filter((k) => k !== fromKey);
            out.splice(list.indexOf(toKey), 0, fromKey);
            return out;
        };
        if (this.pinnable && from.frozen) {
            const current = this.pinnedKeys ?? this.schemaColumns.filter((c) => c.frozen).map((c) => c.key);
            this.pinnedKeys = move(current);
        }
        else {
            this.orderKeys = move(this.orderKeys ?? this.schemaColumns.map((c) => c.key));
        }
        this.saveState();
    }
    /** Fija o suelta una columna: la fijada pasa al final de las fijas; la soltada vuelve a su sitio. */
    togglePin(col) {
        const current = this.pinnedKeys ?? this.schemaColumns.filter((c) => c.frozen).map((c) => c.key);
        this.pinnedKeys = col.frozen ? current.filter((k) => k !== col.key) : [...current.filter((k) => k !== col.key), col.key];
        this.saveState();
    }
    pinLabel(col) {
        return fillText(col.frozen ? this.texts.unpinColumn : this.texts.pinColumn, { label: col.label });
    }
    get actions() {
        return this.props['actions'] ?? [];
    }
    get hasFilter() {
        return this.props['filter'] === true;
    }
    get selectMode() {
        const v = this.props['selectable'];
        return v === 'multiple' ? 'multiple' : v === true || v === 'single' ? 'single' : 'none';
    }
    get selectable() {
        return this.selectMode !== 'none';
    }
    get multiple() {
        return this.selectMode === 'multiple';
    }
    /** Hay columnas fijas a la izquierda. */
    get hasFrozen() {
        return this.columns.some((c) => c.frozen);
    }
    /** `left` de una columna fija: variable CSS que `ngAfterViewChecked` rellena con lo que miden las anteriores. */
    frozenLeft(col) {
        return col.frozen ? `var(--df-frozen-${this.columns.indexOf(col)})` : null;
    }
    onResize() {
        this.frozenOffsets = '';
        this.ngAfterViewChecked();
    }
    /** Mide dónde empieza cada columna fija (la casilla de selección incluida) y lo deja en variables CSS. */
    ngAfterViewChecked() {
        if (this.refocusKey) {
            const key = this.refocusKey;
            this.refocusKey = null;
            const heads = Array.from(this.host.nativeElement.querySelectorAll('thead tr:first-child > th[data-key]'));
            heads.find((h) => h.dataset['key'] === key)?.querySelector('button')?.focus();
        }
        if (!this.hasFrozen)
            return;
        const table = this.host.nativeElement.querySelector('.df-table__table');
        const heads = table?.querySelectorAll('thead tr:first-child > th');
        if (!table || !heads)
            return;
        // `offsetLeft` no sirve: en una celda sticky incluye el `left` que ya se le puso y se realimenta.
        // Se suman los anchos de las celdas anteriores, que no dependen de la posición.
        const offset = this.multiple ? 1 : 0;
        const starts = [];
        let x = 0;
        heads.forEach((h) => {
            starts.push(x);
            x += h.offsetWidth;
        });
        const lefts = [];
        if (this.multiple)
            lefts.push(`--df-frozen-check:${starts[0] ?? 0}px`);
        this.columns.forEach((col, i) => {
            if (col.frozen)
                lefts.push(`--df-frozen-${i}:${starts[i + offset] ?? 0}px`);
        });
        const key = lefts.join(';');
        if (key === this.frozenOffsets)
            return;
        this.frozenOffsets = key;
        for (const l of lefts) {
            const [name, value] = l.split(':');
            table.style.setProperty(name, value);
        }
    }
    // --- Estado entre visitas (persistState) -------------------------------------------
    /** Dónde se guarda el estado, o null si la tabla no lo recuerda o el navegador no deja usar el almacén. */
    get storage() {
        const mode = this.props['persistState'];
        if (!mode)
            return null;
        try {
            const win = this.document.defaultView;
            return (mode === 'local' ? win?.localStorage : win?.sessionStorage) ?? null;
        }
        catch {
            return null;
        }
    }
    get stateKey() {
        return `df-table:${this.props['stateKey']}`;
    }
    restoreState() {
        const storage = this.storage;
        if (!storage)
            return;
        let raw = null;
        try {
            raw = storage.getItem(this.stateKey);
        }
        catch {
            return;
        }
        const state = parseTableState(raw, {
            columnKeys: this.schemaColumns.map((c) => c.key),
            filterKeys: this.schemaColumns.filter((c) => c.filter).map((c) => c.key),
            pinnable: this.pinnable,
            reorderable: this.reorderable,
            resizable: this.resizable,
        });
        if (state.sorts) {
            // Lo que el usuario dejó gana al orden inicial del esquema, también si lo había quitado.
            this.sortInitialised = true;
            this.sorts = this.multiSort ? state.sorts : state.sorts.slice(0, 1);
        }
        if (state.filter != null && this.hasFilter)
            this.filterText = state.filter;
        if (state.columnFilters)
            this.columnFilters = state.columnFilters;
        if (state.pageSize != null && this.props['pageSize'] && this.pageSizeOptions.includes(state.pageSize))
            this.pageSizeChoice = state.pageSize;
        if (state.pinned)
            this.pinnedKeys = state.pinned;
        if (state.order)
            this.orderKeys = state.order;
        if (state.widths)
            this.widths = state.widths;
        // En modo server la primera petición lleva lo que se restauró.
        this.appliedFilter = this.filterText.trim();
        this.appliedColumnFilters = this.activeColumnFilters();
    }
    saveState() {
        const storage = this.storage;
        if (!storage)
            return;
        this.applyDefaultSort();
        const state = {
            sorts: this.sorts,
            filter: this.filterText,
            columnFilters: this.columnFilters,
            ...(this.pageSizeChoice != null ? { pageSize: this.pageSizeChoice } : {}),
            ...(this.pinnable && this.pinnedKeys ? { pinned: this.pinnedKeys } : {}),
            ...(this.reorderable && this.orderKeys ? { order: this.orderKeys } : {}),
            ...(this.resizable && this.widths ? { widths: this.widths } : {}),
        };
        try {
            storage.setItem(this.stateKey, JSON.stringify(state));
        }
        catch {
            // Almacén lleno o bloqueado: la tabla sigue funcionando sin recordar.
        }
    }
    get hasColumnFilters() {
        return this.columns.some((c) => c.filter);
    }
    get exportConfig() {
        return this.props['exportCsv'];
    }
    /** Hay algún filtro puesto (buscador o columna). */
    get filtering() {
        return this.filterText.trim() !== '' || Object.keys(this.activeColumnFilters()).length > 0;
    }
    get emptyMessage() {
        return this.props['emptyMessage'] || this.texts.empty;
    }
    get source() {
        return this.props['source'];
    }
    /** El servicio entrega las páginas ya filtradas, ordenadas y recortadas. */
    get serverSide() {
        return this.source?.mode === 'server';
    }
    get loading() {
        return this.loadState === 'loading';
    }
    get failed() {
        return this.loadState === 'error';
    }
    get errorMessage() {
        return this.props['errorMessage'] || this.texts.error;
    }
    /** Filas de origen: las del servicio (`source`), la propiedad del modelo (`dataKey`) o las del propio esquema. */
    get sourceRows() {
        if (this.source)
            return this.remoteRows;
        const dataKey = this.props['dataKey'];
        const data = dataKey ? getByPath(rootModel(this.field), dataKey) : this.props['staticRows'];
        return Array.isArray(data) ? data.filter((r) => r && typeof r === 'object') : [];
    }
    /** Filas que cumplen el filtro: el total del servidor, o las que quedan en el cliente. */
    get totalRows() {
        return this.serverSide ? this.remoteTotal : this.processed.length;
    }
    // --- Carga desde el servicio -------------------------------------------------
    ngOnInit() {
        this.restoreState();
        // Desde fuera no hay evento del DOM que marque la vista: la tabla se marca ella misma.
        this.controls?.set(this.tableId, {
            selectAll: () => { this.selectAll(); this.cdr.markForCheck(); },
            clearSelection: () => { this.clearSelection(); this.cdr.markForCheck(); },
        });
        this.filterInput$.pipe(debounceTime(FILTER_DEBOUNCE_MS), takeUntil(this.destroyed$)).subscribe(() => {
            this.appliedFilter = this.filterText.trim();
            this.appliedColumnFilters = this.activeColumnFilters();
            this.pageIndex = 0;
            this.load(true);
        });
        this.jobs$
            .pipe(switchMap((job) => {
            if (!job)
                return EMPTY;
            if (!this.provider) {
                console.warn(`[dynamic-forms] table.source (${job.endpoint}) sin DF_TABLE_PROVIDER registrado.`);
                return of(null);
            }
            return this.provider.load(job.endpoint, job.request).pipe(map((result) => this.toPage(result)), catchError(() => of(null)));
        }), takeUntil(this.destroyed$))
            .subscribe((page) => {
            if (page) {
                this.remoteRows = page.rows;
                this.remoteTotal = page.total;
                this.loadState = 'idle';
            }
            else {
                this.remoteRows = [];
                this.remoteTotal = 0;
                this.loadState = 'error';
            }
            this.cdr.markForCheck();
        });
    }
    /** Recarga la tabla cuando cambia el valor de alguno de los campos de `source.dependsOn`. */
    ngDoCheck() {
        if (!this.source)
            return;
        const key = JSON.stringify(this.params());
        if (key === this.paramsKey)
            return;
        this.paramsKey = key;
        this.pageIndex = 0;
        this.load();
    }
    ngOnDestroy() {
        if (this.controls?.get(this.tableId))
            this.controls.delete(this.tableId);
        this.destroyed$.next();
        this.destroyed$.complete();
    }
    params() {
        const out = {};
        for (const dep of this.source?.dependsOn ?? [])
            out[paramName(dep)] = readPath(this.field, dep);
        return out;
    }
    toPage(result) {
        const isRow = (r) => !!r && typeof r === 'object' && !Array.isArray(r);
        const rows = (Array.isArray(result) ? result : result?.rows ?? []).filter(isRow);
        const total = !Array.isArray(result) && Number.isFinite(result?.total) ? Number(result.total) : rows.length;
        return { rows, total };
    }
    /** Pide al servicio las filas que toquen ahora. */
    reload() {
        this.load();
    }
    /** `keepSelection`: un cambio de página, orden o filtro no vacía una selección múltiple que tiene `selectionKey`. */
    load(keepSelection = false) {
        const source = this.source;
        if (!source)
            return;
        // Lo seleccionado ya no tiene por qué existir en las filas nuevas.
        if (this.selected) {
            const lost = this.selected;
            this.selected = null;
            // Se avisa fuera del ciclo de detección en el que estamos (ngDoCheck).
            queueMicrotask(() => this.events?.select({ tableId: this.tableId, row: null, rows: [], changed: { rows: [lost], selected: false } }));
        }
        if (this.selection.size && !(keepSelection && this.selectionKey)) {
            const lost = this.selectedRows;
            this.selection.clear();
            queueMicrotask(() => this.events?.select({ tableId: this.tableId, row: null, rows: [], changed: { rows: lost, selected: false } }));
        }
        const params = this.params();
        this.waiting = this.source?.requireParams !== false && Object.values(params).some((v) => v == null || v === '');
        if (this.waiting) {
            this.remoteRows = [];
            this.remoteTotal = 0;
            this.loadState = 'idle';
            this.jobs$.next(null);
            return;
        }
        this.applyDefaultSort();
        const server = this.serverSide;
        const request = {
            page: server ? this.currentPage : 0,
            pageSize: server ? this.pageSize : null,
            sort: server ? (this.sorts[0] ?? null) : null,
            sorts: server ? this.sorts : [],
            filter: server ? this.appliedFilter : '',
            columnFilters: server ? this.appliedColumnFilters : {},
            params,
        };
        this.loadState = 'loading';
        this.jobs$.next({ endpoint: source.endpoint, request });
    }
    get pageSizeOptions() {
        return this.props['pageSizeOptions'] ?? DEFAULT_PAGE_SIZES;
    }
    /** Filas por página; null si la tabla no pagina. */
    get pageSize() {
        const base = this.props['pageSize'];
        return this.pageSizeChoice ?? base ?? null;
    }
    applyDefaultSort() {
        if (this.sortInitialised)
            return;
        this.sortInitialised = true;
        const sorts = this.props['sorts'] ?? [];
        this.sorts = this.multiSort ? sorts : sorts.slice(0, 1);
    }
    /** Todas las filas tras filtrar y ordenar (sin paginar). */
    get processed() {
        this.applyDefaultSort();
        const rows = this.sourceRows;
        // En modo server el servicio ya filtró y ordenó.
        if (this.serverSide)
            return rows;
        const c = this.cache;
        const columnKey = JSON.stringify(this.columnFilters);
        const sortsKey = JSON.stringify(this.sorts);
        if (c && c.rows === rows && c.length === rows.length && c.filter === this.filterText && c.columnFilters === columnKey
            && c.sorts === sortsKey) {
            return c.result;
        }
        let result = this.hasFilter ? filterRows(rows, this.columns, this.filterText, this.props['searchKeys'] ?? []) : rows;
        result = filterByColumns(result, this.columns, this.columnFilters);
        const keys = this.sorts.flatMap((s) => {
            const col = this.columns.find((x) => x.key === s.key);
            return col ? [{ col, direction: s.direction }] : [];
        });
        if (keys.length)
            result = sortRowsBy(result, keys);
        this.cache = { rows, length: rows.length, filter: this.filterText, columnFilters: columnKey, sorts: sortsKey, result };
        return result;
    }
    get pageCount() {
        const size = this.pageSize;
        return size ? Math.max(1, Math.ceil(this.totalRows / size)) : 1;
    }
    /** Página actual, sin salirse si las filas han bajado de número. */
    get currentPage() {
        return Math.min(this.pageIndex, this.pageCount - 1);
    }
    get visibleRows() {
        const size = this.pageSize;
        if (!size || this.serverSide)
            return this.processed;
        const start = this.currentPage * size;
        return this.processed.slice(start, start + size);
    }
    /** "11–20 de 45" */
    get range() {
        const total = this.totalRows;
        const size = this.pageSize;
        if (!size || total === 0)
            return `${total}`;
        const start = this.currentPage * size;
        return fillText(this.texts.range, { from: start + 1, to: Math.min(total, start + size), total });
    }
    /** Ancho de una columna en %: su `col` frente a la suma de todas (una pista, la tabla se ajusta al contenido). */
    width(col) {
        const total = this.columns.reduce((sum, c) => sum + c.col, 0);
        return Math.round((col.col / total) * 1000) / 10;
    }
    /** El HTML crudo de una celda `html`; el `[innerHTML]` de la plantilla lo sanea. */
    html(row, col) {
        const value = getByPath(row, col.key);
        return typeof value === 'string' ? value : '';
    }
    get slots() {
        return this.options?.formState?.[DF_TABLE_SLOTS];
    }
    /** Plantilla de la app para las celdas de la columna (`template`), si la hay. */
    cellTemplate(col) {
        return col.template ? this.slots?.cell(col.template) ?? null : null;
    }
    cellContext(row, col) {
        return { $implicit: row, row, value: getByPath(row, col.key), column: col.key };
    }
    /** Plantilla de la app para la tabla vacía (`dfEmpty`), si la hay. */
    get emptyTemplate() {
        return this.slots?.empty(this.tableId) ?? null;
    }
    /** Clase de la insignia de una celda `badge`: `df-badge df-badge--ok` (neutra si el valor no tiene variante). */
    badgeClass(row, col) {
        const value = getByPath(row, col.key);
        const variant = value == null ? undefined : col.variants?.[String(value)];
        return variant ? `df-badge df-badge--${variant}` : 'df-badge';
    }
    /** Destino de una celda `link` (null si falta algún valor de la fila: se pinta el texto sin enlace). */
    href(row, col) {
        return resolveHref(row, col.href);
    }
    /**
     * Clic en un enlace `link`: se emite `tableNavigate` y la app decide si navega ella (`preventDefault`). Con Ctrl,
     * Cmd, Mayús, Alt o un botón que no sea el izquierdo no se emite: el navegador abre una pestaña o ventana.
     */
    onLink(event, row, col) {
        event.stopPropagation();
        const href = this.href(row, col);
        if (!href || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey)
            return;
        this.events?.navigate({ tableId: this.tableId, column: col.key, href, row, originalEvent: event });
    }
    text(row, col) {
        return cellText(row, col);
    }
    ariaSort(col) {
        if (!col.sortable)
            return null;
        const s = this.sorts.find((x) => x.key === col.key);
        if (!s)
            return 'none';
        return s.direction === 'asc' ? 'ascending' : 'descending';
    }
    get multiSort() {
        return this.props['multiSort'] === true;
    }
    /** Posición (desde 1) de la columna en el orden, solo cuando hay varias columnas ordenando. */
    sortPosition(col) {
        const i = this.sorts.findIndex((s) => s.key === col.key);
        return this.sorts.length > 1 && i >= 0 ? i + 1 : null;
    }
    sortArrow(col) {
        const s = this.sorts.find((x) => x.key === col.key);
        return s ? (s.direction === 'asc' ? '▲' : '▼') : '';
    }
    /**
     * Pulsar la cabecera: ascendente, luego descendente, luego sin orden. Con `multiSort`, Mayús + clic añade la
     * columna al orden (o cambia su sentido, o la quita) sin tocar las demás; un clic sin Mayús ordena solo por ella.
     */
    sortBy(col, event) {
        if (!col.sortable)
            return;
        this.applyDefaultSort();
        const current = this.sorts.find((s) => s.key === col.key);
        const next = (s) => (!s ? 'asc' : s.direction === 'asc' ? 'desc' : null);
        if (this.multiSort && event?.shiftKey) {
            const direction = next(current);
            const others = this.sorts.filter((s) => s.key !== col.key);
            this.sorts = !direction ? others : current ? this.sorts.map((s) => (s.key === col.key ? { key: s.key, direction } : s)) : [...others, { key: col.key, direction }];
        }
        else {
            // Sin Mayús solo se cicla si esta columna ya es el único orden; si no, empieza de cero con ella.
            const alone = this.sorts.length === 1 && !!current;
            const direction = alone ? next(current) : 'asc';
            this.sorts = direction ? [{ key: col.key, direction }] : [];
        }
        this.pageIndex = 0;
        this.saveState();
        if (this.serverSide)
            this.load(true);
    }
    onFilter(event) {
        this.filterText = event.target.value;
        this.filtersChanged();
    }
    filterKind(col) {
        return columnFilterKind(col);
    }
    filterOptions(col) {
        return columnFilterOptions(col);
    }
    onColumnFilter(col, event) {
        const value = event.target.value;
        this.columnFilters = { ...this.columnFilters, [col.key]: value };
        this.filtersChanged();
    }
    /** Filtros por columna con algo escrito o elegido. */
    activeColumnFilters() {
        const out = {};
        for (const c of this.columns) {
            const v = (this.columnFilters[c.key] ?? '').trim();
            if (c.filter && v)
                out[c.key] = v;
        }
        return out;
    }
    filtersChanged() {
        this.saveState();
        if (this.serverSide) {
            this.filterInput$.next();
            return;
        }
        this.pageIndex = 0;
    }
    goTo(page) {
        this.pageIndex = Math.min(Math.max(0, page), this.pageCount - 1);
        if (this.serverSide)
            this.load(true);
    }
    onPageSize(event) {
        this.pageSizeChoice = Number(event.target.value);
        this.pageIndex = 0;
        this.saveState();
        if (this.serverSide)
            this.load(true);
    }
    get events() {
        return this.options?.formState?.[DF_TABLE_EVENTS];
    }
    /** La acción se muestra en esta fila (sin `showWhen` se muestra siempre). */
    actionVisible(row, action) {
        return !action.showWhen || this.evaluator.evaluate(action.showWhen, rootModel(this.field), row, contextOf(this.field));
    }
    actionDisabled(row, action) {
        return !!action.disabledWhen && this.evaluator.evaluate(action.disabledWhen, rootModel(this.field), row, contextOf(this.field));
    }
    /** Trazado SVG del icono incluido, o null si `icon` es un texto que se pinta tal cual. */
    iconPath(action) {
        return action.icon ? tableIconPath(action.icon) : null;
    }
    act(row, action) {
        if (this.actionDisabled(row, action) || !this.actionVisible(row, action))
            return;
        this.events?.action({ tableId: this.props['tableId'], action: action.name, row });
    }
    get tableId() {
        return this.props['tableId'];
    }
    get selectionKey() {
        return this.props['selectionKey'];
    }
    idOf(row) {
        const key = this.selectionKey;
        if (!key)
            return row;
        const id = getByPath(row, key);
        return id == null ? row : id;
    }
    /** Filas marcadas con `selectable: 'multiple'`. */
    get selectedRows() {
        return [...this.selection.values()];
    }
    /** Última fila que se marcó o desmarcó con el ratón: donde empieza un rango con Shift. */
    anchor = null;
    /** Con Shift apretado el navegador selecciona texto entre los dos clics; aquí estorba. */
    onRowMouseDown(event) {
        if (this.multiple && event.shiftKey)
            event.preventDefault();
    }
    /** Hay alguna fila que la casilla de la cabecera pueda marcar. */
    get headerRowsAvailable() {
        return this.headerRows.length > 0;
    }
    /** La fila admite selección (sin `selectableWhen` todas la admiten). */
    rowSelectable(row) {
        const rule = this.props['selectableWhen'];
        return !rule || this.evaluator.evaluate(rule, rootModel(this.field), row, contextOf(this.field));
    }
    /** Filas que marca la casilla de la cabecera: las seleccionables de la página o de todo lo filtrado. */
    get headerRows() {
        const rows = this.props['headerSelects'] === 'page' ? this.visibleRows : this.processed;
        return this.props['selectableWhen'] ? rows.filter((r) => this.rowSelectable(r)) : rows;
    }
    toggle(row, event) {
        if (!this.selectable || !this.rowSelectable(row))
            return;
        if (this.multiple) {
            const rows = this.visibleRows;
            const from = this.anchor ? rows.indexOf(this.anchor) : -1;
            if (event?.shiftKey && from >= 0) {
                // Rango con Shift: todas las filas de la página entre la última pulsada y esta se añaden a la selección.
                const to = rows.indexOf(row);
                const added = [];
                for (const r of rows.slice(Math.min(from, to), Math.max(from, to) + 1)) {
                    if (!this.rowSelectable(r))
                        continue;
                    if (!this.selection.has(this.idOf(r)))
                        added.push(r);
                    this.selection.set(this.idOf(r), r);
                }
                this.anchor = row;
                this.emitSelection(added, true);
                return;
            }
            const id = this.idOf(row);
            const wasSelected = this.selection.has(id);
            if (wasSelected)
                this.selection.delete(id);
            else
                this.selection.set(id, row);
            this.anchor = row;
            this.emitSelection([row], !wasSelected);
            return;
        }
        const previous = this.selected;
        this.selected = previous === row ? null : row;
        this.events?.select({
            tableId: this.tableId,
            row: this.selected,
            rows: this.selected ? [this.selected] : [],
            changed: { rows: [this.selected ?? previous ?? row], selected: this.selected !== null },
        });
    }
    isSelected(row) {
        return this.multiple ? this.selection.has(this.idOf(row)) : this.selected === row;
    }
    /** Casilla de la cabecera: todas las filas filtradas (en modo server, las de la página). */
    get allSelected() {
        const rows = this.headerRows;
        return rows.length > 0 && rows.every((r) => this.isSelected(r));
    }
    get someSelected() {
        return !this.allSelected && this.headerRows.some((r) => this.isSelected(r));
    }
    toggleAll() {
        const all = this.allSelected;
        const changed = [];
        for (const row of this.headerRows) {
            const id = this.idOf(row);
            if (all) {
                this.selection.delete(id);
                changed.push(row);
            }
            else {
                if (!this.selection.has(id))
                    changed.push(row);
                this.selection.set(id, row);
            }
        }
        this.emitSelection(changed, !all);
    }
    get controls() {
        return this.options?.formState?.[DF_TABLE_CONTROLS];
    }
    /** Marca las filas que marcaría la casilla de la cabecera (`selectable: 'multiple'`). Es la misma lógica que `toggleAll` cuando no están todas marcadas. */
    selectAll() {
        if (!this.multiple)
            return;
        const changed = this.headerRows.filter((r) => !this.selection.has(this.idOf(r)));
        for (const row of changed)
            this.selection.set(this.idOf(row), row);
        if (changed.length)
            this.emitSelection(changed, true);
    }
    /** Quita toda la selección, también la de otras páginas. No emite nada si no había nada marcado. */
    clearSelection() {
        this.anchor = null;
        if (this.multiple) {
            const changed = this.selectedRows;
            this.selection.clear();
            if (changed.length)
                this.emitSelection(changed, false);
        }
        else if (this.selected) {
            const previous = this.selected;
            this.selected = null;
            this.events?.select({ tableId: this.tableId, row: null, rows: [], changed: { rows: [previous], selected: false } });
        }
    }
    emitSelection(changed, selected) {
        this.events?.select({ tableId: this.tableId, row: null, rows: this.selectedRows, changed: { rows: changed, selected } });
    }
    // --- Exportar a CSV ----------------------------------------------------------
    /** Texto del botón: con filas marcadas exporta solo esas. */
    get exportLabel() {
        return this.multiple && this.selection.size ? fillText(this.texts.exportSelection, { n: this.selection.size }) : this.texts.exportCsv;
    }
    exportCsv() {
        const config = this.exportConfig;
        if (!config || this.exporting)
            return;
        this.exportFailed = false;
        const save = (rows) => this.download(csvFileName(config.filename), toCsv(rows, this.columns));
        if (this.multiple && this.selection.size)
            return save(this.selectedRows);
        const source = this.source;
        if (!(this.serverSide && source))
            return save(this.processed);
        // Modo server: la tabla solo tiene la página actual, así que se piden al servicio todas las filas del filtro.
        if (!this.provider) {
            this.exportFailed = true;
            return;
        }
        this.exporting = true;
        const request = {
            page: 0,
            pageSize: Math.max(1, this.remoteTotal),
            sort: this.sorts[0] ?? null,
            sorts: this.sorts,
            filter: this.appliedFilter,
            columnFilters: this.appliedColumnFilters,
            params: this.params(),
        };
        this.provider.load(source.endpoint, request).pipe(take(1), map((r) => this.toPage(r)), takeUntil(this.destroyed$)).subscribe({
            next: (page) => {
                this.exporting = false;
                save(page.rows);
                this.cdr.markForCheck();
            },
            error: () => {
                this.exporting = false;
                this.exportFailed = true;
                this.cdr.markForCheck();
            },
        });
    }
    download(name, csv) {
        const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
        const link = this.document.createElement('a');
        link.href = url;
        link.download = name;
        link.click();
        URL.revokeObjectURL(url);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: TableFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: TableFieldComponent, isStandalone: true, selector: "df-table-field", host: { listeners: { "window:resize": "onResize()" } }, usesInheritance: true, ngImport: i0, template: "<div class=\"df-table\">\n  @if (props.title) {\n    <div class=\"df-table__title\">{{ props.title }}</div>\n  }\n  @if (props.description) {\n    <p class=\"df-table__description\">{{ props.description }}</p>\n  }\n\n  @if (hasFilter || exportConfig) {\n    <div class=\"df-table__toolbar\">\n      @if (hasFilter) {\n        <label class=\"df-table__filter\">\n          <span>{{ props['filterLabel'] || texts.search }}</span>\n          <input type=\"search\" class=\"df-table__search\" [value]=\"filterText\" (input)=\"onFilter($event)\" />\n        </label>\n      }\n      @if (exportConfig) {\n        <button type=\"button\" class=\"df-table__action df-table__export\" [disabled]=\"exporting\" (click)=\"exportCsv()\">\n          {{ exporting ? texts.exporting : exportLabel }}\n        </button>\n      }\n    </div>\n  }\n  @if (exportFailed) {\n    <div class=\"df-table__status is-error\" role=\"alert\">{{ texts.exportFailed }}</div>\n  }\n\n  @if (loading) {\n    <div class=\"df-table__status\" role=\"status\">{{ texts.loading }}</div>\n  }\n\n  <div class=\"df-table__scroll\" [attr.aria-busy]=\"loading\" [class.is-loading]=\"loading\">\n    <table class=\"df-table__table\" [class.is-resized]=\"widths\" [style.width]=\"tableWidth\">\n      <colgroup>\n        @if (multiple) {\n          <col class=\"df-table__check-col\" [style.width]=\"specialWidth('__check')\" />\n        }\n        @for (col of columns; track col.key) {\n          <col [style.width]=\"colWidth(col)\" />\n        }\n        @if (actions.length) {\n          <col [style.width]=\"specialWidth('__actions')\" />\n        }\n      </colgroup>\n      <thead>\n        <tr>\n          @if (multiple) {\n            <th scope=\"col\" class=\"df-table__check\" [class.is-frozen]=\"hasFrozen\" [style.left]=\"hasFrozen ? 'var(--df-frozen-check)' : null\">\n              <input\n                type=\"checkbox\"\n                [attr.aria-label]=\"texts.selectAll\"\n                [checked]=\"allSelected\"\n                [indeterminate]=\"someSelected\"\n                [disabled]=\"!headerRowsAvailable\"\n                (change)=\"toggleAll()\" />\n            </th>\n          }\n          @for (col of columns; track col.key) {\n            <th\n              scope=\"col\"\n              [attr.aria-sort]=\"ariaSort(col)\"\n              [class.is-sortable]=\"col.sortable\"\n              [class.is-frozen]=\"col.frozen\"\n              [class.is-dragging]=\"dragKey === col.key\"\n              [class.is-drop-target]=\"dropKey === col.key\"\n              [attr.data-key]=\"col.key\"\n              [attr.draggable]=\"reorderable ? 'true' : null\"\n              [attr.title]=\"reorderable ? texts.reorderHint : null\"\n              [style.left]=\"frozenLeft(col)\"\n              (dragstart)=\"onDragStart($any($event), col)\"\n              (dragover)=\"onDragOver($any($event), col)\"\n              (drop)=\"onDrop($any($event), col)\"\n              (dragend)=\"onDragEnd()\"\n              (keydown)=\"onHeaderKey($event, col)\">\n              <span class=\"df-table__head\">\n                @if (col.sortable) {\n                  <button type=\"button\" class=\"df-table__sort\" (click)=\"sortBy(col, $event)\">\n                    {{ col.label }}\n                    <span class=\"df-table__arrow\" aria-hidden=\"true\">{{ sortArrow(col) }}@if (sortPosition(col); as pos) {<sup>{{ pos }}</sup>}</span>\n                  </button>\n                } @else {\n                  {{ col.label }}\n                }\n                @if (pinnable) {\n                  <button\n                    type=\"button\"\n                    class=\"df-table__pin\"\n                    [class.is-pinned]=\"col.frozen\"\n                    [attr.aria-pressed]=\"col.frozen\"\n                    [attr.aria-label]=\"pinLabel(col)\"\n                    [attr.title]=\"pinLabel(col)\"\n                    (click)=\"togglePin(col)\">\n                    <svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" aria-hidden=\"true\" focusable=\"false\">\n                      <path fill=\"currentColor\" d=\"M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z\" />\n                    </svg>\n                  </button>\n                }\n              </span>\n              @if (resizable) {\n                <span\n                  class=\"df-table__resizer\"\n                  role=\"separator\"\n                  aria-orientation=\"vertical\"\n                  tabindex=\"0\"\n                  [attr.aria-label]=\"resizeLabel(col)\"\n                  [attr.aria-valuenow]=\"widths ? widths[col.key] : null\"\n                  (pointerdown)=\"onResizeStart($any($event), col)\"\n                  (pointermove)=\"onResizeMove($any($event))\"\n                  (pointerup)=\"onResizeEnd()\"\n                  (pointercancel)=\"onResizeEnd()\"\n                  (keydown)=\"onResizeKey($event, col)\"\n                  (click)=\"$event.stopPropagation()\"\n                  (dblclick)=\"resetWidths($event)\"></span>\n              }\n            </th>\n          }\n          @if (actions.length) {\n            <th scope=\"col\" class=\"df-table__actions-head\">{{ texts.actions }}</th>\n          }\n        </tr>\n        @if (hasColumnFilters) {\n          <tr class=\"df-table__filters\">\n            @if (multiple) {\n              <th [class.is-frozen]=\"hasFrozen\" [style.left]=\"hasFrozen ? 'var(--df-frozen-check)' : null\"></th>\n            }\n            @for (col of columns; track col.key) {\n              <th [class.is-frozen]=\"col.frozen\" [style.left]=\"frozenLeft(col)\">\n                @if (col.filter) {\n                  @if (filterKind(col) === 'select') {\n                    <select class=\"df-table__column-filter\" [attr.aria-label]=\"filterAria(col)\" (change)=\"onColumnFilter(col, $event)\">\n                      <option value=\"\" [selected]=\"!columnFilters[col.key]\">{{ texts.all }}</option>\n                      @for (o of filterOptions(col); track o.value) {\n                        <option [value]=\"o.value\" [selected]=\"columnFilters[col.key] === o.value\">{{ o.label }}</option>\n                      }\n                    </select>\n                  } @else {\n                    <input\n                      type=\"search\"\n                      class=\"df-table__column-filter\"\n                      [attr.aria-label]=\"filterAria(col)\"\n                      [value]=\"columnFilters[col.key] ?? ''\"\n                      (input)=\"onColumnFilter(col, $event)\" />\n                  }\n                }\n              </th>\n            }\n            @if (actions.length) {\n              <th></th>\n            }\n          </tr>\n        }\n      </thead>\n      <tbody>\n        @for (row of visibleRows; track $index) {\n          <tr\n            [class.is-selectable]=\"selectable && rowSelectable(row)\"\n            [class.is-selected]=\"isSelected(row)\"\n            [attr.aria-selected]=\"selectable && rowSelectable(row) ? isSelected(row) : null\"\n            [attr.tabindex]=\"selectable && rowSelectable(row) ? 0 : null\"\n            (mousedown)=\"onRowMouseDown($event)\"\n            (click)=\"toggle(row, $event)\"\n            (keydown.enter)=\"toggle(row)\"\n            (keydown.space)=\"$event.preventDefault(); toggle(row)\">\n            @if (multiple) {\n              <td class=\"df-table__check\" [class.is-frozen]=\"hasFrozen\" [style.left]=\"hasFrozen ? 'var(--df-frozen-check)' : null\">\n                <input\n                  type=\"checkbox\"\n                  [attr.aria-label]=\"texts.selectRow\"\n                  [checked]=\"isSelected(row)\"\n                  tabindex=\"-1\"\n                  [disabled]=\"!rowSelectable(row)\"\n                  (click)=\"$event.stopPropagation(); toggle(row, $event)\" />\n              </td>\n            }\n            @for (col of columns; track col.key) {\n              <td [attr.data-type]=\"col.type\" [class.is-frozen]=\"col.frozen\" [style.left]=\"frozenLeft(col)\">@if (cellTemplate(col); as tpl) {<ng-container *ngTemplateOutlet=\"tpl; context: cellContext(row, col)\" />} @else if (col.html) {<span [innerHTML]=\"html(row, col)\"></span>} @else if (col.type === 'badge') {@if (text(row, col); as label) {<span [class]=\"badgeClass(row, col)\">{{ label }}</span>}} @else if (col.type === 'link' && href(row, col); as target) {<a [attr.href]=\"target\" (click)=\"onLink($any($event), row, col)\">{{ text(row, col) }}</a>} @else {{{ text(row, col) }}}</td>\n            }\n            @if (actions.length) {\n              <td class=\"df-table__actions\">\n                @for (action of actions; track action.name) {\n                  @if (actionVisible(row, action)) {\n                    <button\n                      type=\"button\"\n                      class=\"df-table__action\"\n                      [class.is-icon]=\"action.icon\"\n                      [disabled]=\"actionDisabled(row, action)\"\n                      [attr.title]=\"action.tooltip || (action.icon ? action.label : null)\"\n                      [attr.aria-label]=\"action.icon ? action.label : null\"\n                      (click)=\"$event.stopPropagation(); act(row, action)\">\n                      @if (!action.icon) {\n                        {{ action.label }}\n                      } @else if (iconPath(action); as path) {\n                        <svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" aria-hidden=\"true\" focusable=\"false\"><path fill=\"currentColor\" [attr.d]=\"path\" /></svg>\n                      } @else {\n                        <span aria-hidden=\"true\">{{ action.icon }}</span>\n                      }\n                    </button>\n                  }\n                }\n              </td>\n            }\n          </tr>\n        } @empty {\n          @if (!loading) {\n            <tr class=\"df-table__empty\" [class.is-error]=\"failed\">\n              <td [attr.colspan]=\"columns.length + (actions.length ? 1 : 0) + (multiple ? 1 : 0)\">\n                @if (failed) {\n                  {{ errorMessage }}\n                  <button type=\"button\" class=\"df-table__action df-table__retry\" (click)=\"reload()\">{{ texts.retry }}</button>\n                } @else {\n                  @if (filtering && !waiting) {\n                    {{ noResultsText }}\n                  } @else if (emptyTemplate; as tpl) {\n                    <ng-container *ngTemplateOutlet=\"tpl; context: { $implicit: tableId }\" />\n                  } @else {\n                    {{ emptyMessage }}\n                  }\n                }\n              </td>\n            </tr>\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n\n  @if (pageSize) {\n    <div class=\"df-table__pager\">\n      <label class=\"df-table__page-size\">\n        <span>{{ texts.rowsPerPage }}</span>\n        <select (change)=\"onPageSize($event)\">\n          @for (n of pageSizeOptions; track n) {\n            <option [value]=\"n\" [selected]=\"n === pageSize\">{{ n }}</option>\n          }\n        </select>\n      </label>\n      <span class=\"df-table__range\" aria-live=\"polite\">{{ range }}</span>\n      <button type=\"button\" class=\"df-table__page\" [disabled]=\"currentPage === 0\" (click)=\"goTo(currentPage - 1)\" [attr.aria-label]=\"texts.previousPage\">\u2039</button>\n      <button type=\"button\" class=\"df-table__page\" [disabled]=\"currentPage >= pageCount - 1\" (click)=\"goTo(currentPage + 1)\" [attr.aria-label]=\"texts.nextPage\">\u203A</button>\n    </div>\n  }\n</div>\n", styles: [":host{display:block}.df-table{margin-bottom:var(--df-field-gap)}.df-table__title{font-weight:600;color:var(--df-color-text);margin-bottom:.25rem}.df-table__description{margin:0 0 .75rem;font-size:.85rem;color:var(--df-color-muted)}.df-table__toolbar{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:.5rem 1rem;margin-bottom:.75rem}.df-table__filter{display:flex;flex-direction:column;gap:.25rem;max-width:18rem;font-size:var(--df-label-size);font-weight:600;color:var(--df-color-text)}.df-table__search,.df-table__column-filter,.df-table__page-size select{font:inherit;font-weight:400;padding:.35rem .5rem;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);color:var(--df-color-text)}.df-table__column-filter{width:100%;min-width:5rem;box-sizing:border-box;font-size:.85rem}.df-table__filters th{font-weight:400;padding-top:.25rem}.df-table__check{width:2.25rem;text-align:center}.df-table__status.is-error{color:var(--df-color-danger)}.df-table__status{font-size:.85rem;color:var(--df-color-muted);margin-bottom:.35rem}.df-table__scroll.is-loading{opacity:.55}.df-table__empty.is-error td{color:var(--df-color-danger)}.df-table__retry{margin-left:.5rem}.df-table__scroll{overflow-x:auto;border:1px solid var(--df-color-border);border-radius:var(--df-radius)}.df-table__table{width:100%;border-collapse:collapse;font-size:.9rem;color:var(--df-color-text)}.df-table__table th,.df-table__table td{padding:.5rem .75rem;text-align:left;border-bottom:1px solid var(--df-color-border)}.df-table__table thead th{background:#7f7f7f1a;font-weight:600;white-space:nowrap}.df-table__table tbody tr:last-child td{border-bottom:0}.df-table__table td[data-type=number],.df-table__table td[data-type=currency]{text-align:right;font-variant-numeric:tabular-nums}.df-table__sort{all:unset;cursor:pointer;display:inline-flex;gap:.35rem;align-items:center}.df-table__sort:focus-visible{outline:2px solid var(--df-color-primary);outline-offset:2px}.df-table__table.is-resized{table-layout:fixed}.df-table__table.is-resized th,.df-table__table.is-resized td{overflow:hidden}.df-table__table thead th:not(.is-frozen){position:relative}.df-table__resizer{position:absolute;top:0;right:0;bottom:0;width:6px;cursor:col-resize;touch-action:none}.df-table__resizer:hover,.df-table__resizer:focus-visible{background:var(--df-color-primary);opacity:.5;outline:none}.df-table th[draggable=true]{cursor:grab}.df-table th.is-dragging{opacity:.45}.df-table th.is-drop-target{box-shadow:inset 3px 0 0 var(--df-color-primary)}.df-table__head{display:inline-flex;align-items:center;gap:.35rem}.df-table__pin{all:unset;display:inline-flex;cursor:pointer;color:var(--df-color-muted);opacity:.55;transform:rotate(45deg)}.df-table__pin:hover,.df-table__pin:focus-visible{opacity:1}.df-table__pin:focus-visible{outline:2px solid var(--df-color-primary);outline-offset:2px}.df-table__pin.is-pinned{color:var(--df-color-primary);opacity:1;transform:none}.df-table__arrow{font-size:.65rem;min-width:.65rem}.df-table .is-frozen{position:sticky;z-index:1;white-space:nowrap;background-color:var(--df-color-surface)}.df-table thead .is-frozen{background-image:linear-gradient(#7f7f7f1a,#7f7f7f1a);z-index:2}.df-table tr.is-selected .is-frozen{background-image:linear-gradient(var(--df-color-focus),var(--df-color-focus))}.df-table tr.is-selectable{cursor:pointer}.df-table tr.is-selectable:hover{background:#7f7f7f14}.df-table tr.is-selectable:focus-visible{outline:2px solid var(--df-color-primary);outline-offset:-2px}.df-table tr.is-selected{background:var(--df-color-focus)}.df-table__empty td{text-align:center;color:var(--df-color-muted)}.df-table__actions{white-space:nowrap}.df-table__action,.df-table__page{cursor:pointer;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);color:var(--df-color-primary);padding:.2rem .6rem;font:inherit;margin-right:.35rem}.df-table__action:disabled,.df-table__page:disabled{opacity:.5;cursor:not-allowed}.df-table__action.is-icon{display:inline-flex;align-items:center;justify-content:center;min-width:2rem;min-height:2rem;padding:.2rem}.df-table__pager{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:.75rem;margin-top:.5rem;font-size:.85rem;color:var(--df-color-muted)}.df-table__page-size{display:inline-flex;align-items:center;gap:.5rem}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: TableFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-table-field', standalone: true, imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.Default, template: "<div class=\"df-table\">\n  @if (props.title) {\n    <div class=\"df-table__title\">{{ props.title }}</div>\n  }\n  @if (props.description) {\n    <p class=\"df-table__description\">{{ props.description }}</p>\n  }\n\n  @if (hasFilter || exportConfig) {\n    <div class=\"df-table__toolbar\">\n      @if (hasFilter) {\n        <label class=\"df-table__filter\">\n          <span>{{ props['filterLabel'] || texts.search }}</span>\n          <input type=\"search\" class=\"df-table__search\" [value]=\"filterText\" (input)=\"onFilter($event)\" />\n        </label>\n      }\n      @if (exportConfig) {\n        <button type=\"button\" class=\"df-table__action df-table__export\" [disabled]=\"exporting\" (click)=\"exportCsv()\">\n          {{ exporting ? texts.exporting : exportLabel }}\n        </button>\n      }\n    </div>\n  }\n  @if (exportFailed) {\n    <div class=\"df-table__status is-error\" role=\"alert\">{{ texts.exportFailed }}</div>\n  }\n\n  @if (loading) {\n    <div class=\"df-table__status\" role=\"status\">{{ texts.loading }}</div>\n  }\n\n  <div class=\"df-table__scroll\" [attr.aria-busy]=\"loading\" [class.is-loading]=\"loading\">\n    <table class=\"df-table__table\" [class.is-resized]=\"widths\" [style.width]=\"tableWidth\">\n      <colgroup>\n        @if (multiple) {\n          <col class=\"df-table__check-col\" [style.width]=\"specialWidth('__check')\" />\n        }\n        @for (col of columns; track col.key) {\n          <col [style.width]=\"colWidth(col)\" />\n        }\n        @if (actions.length) {\n          <col [style.width]=\"specialWidth('__actions')\" />\n        }\n      </colgroup>\n      <thead>\n        <tr>\n          @if (multiple) {\n            <th scope=\"col\" class=\"df-table__check\" [class.is-frozen]=\"hasFrozen\" [style.left]=\"hasFrozen ? 'var(--df-frozen-check)' : null\">\n              <input\n                type=\"checkbox\"\n                [attr.aria-label]=\"texts.selectAll\"\n                [checked]=\"allSelected\"\n                [indeterminate]=\"someSelected\"\n                [disabled]=\"!headerRowsAvailable\"\n                (change)=\"toggleAll()\" />\n            </th>\n          }\n          @for (col of columns; track col.key) {\n            <th\n              scope=\"col\"\n              [attr.aria-sort]=\"ariaSort(col)\"\n              [class.is-sortable]=\"col.sortable\"\n              [class.is-frozen]=\"col.frozen\"\n              [class.is-dragging]=\"dragKey === col.key\"\n              [class.is-drop-target]=\"dropKey === col.key\"\n              [attr.data-key]=\"col.key\"\n              [attr.draggable]=\"reorderable ? 'true' : null\"\n              [attr.title]=\"reorderable ? texts.reorderHint : null\"\n              [style.left]=\"frozenLeft(col)\"\n              (dragstart)=\"onDragStart($any($event), col)\"\n              (dragover)=\"onDragOver($any($event), col)\"\n              (drop)=\"onDrop($any($event), col)\"\n              (dragend)=\"onDragEnd()\"\n              (keydown)=\"onHeaderKey($event, col)\">\n              <span class=\"df-table__head\">\n                @if (col.sortable) {\n                  <button type=\"button\" class=\"df-table__sort\" (click)=\"sortBy(col, $event)\">\n                    {{ col.label }}\n                    <span class=\"df-table__arrow\" aria-hidden=\"true\">{{ sortArrow(col) }}@if (sortPosition(col); as pos) {<sup>{{ pos }}</sup>}</span>\n                  </button>\n                } @else {\n                  {{ col.label }}\n                }\n                @if (pinnable) {\n                  <button\n                    type=\"button\"\n                    class=\"df-table__pin\"\n                    [class.is-pinned]=\"col.frozen\"\n                    [attr.aria-pressed]=\"col.frozen\"\n                    [attr.aria-label]=\"pinLabel(col)\"\n                    [attr.title]=\"pinLabel(col)\"\n                    (click)=\"togglePin(col)\">\n                    <svg viewBox=\"0 0 24 24\" width=\"14\" height=\"14\" aria-hidden=\"true\" focusable=\"false\">\n                      <path fill=\"currentColor\" d=\"M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z\" />\n                    </svg>\n                  </button>\n                }\n              </span>\n              @if (resizable) {\n                <span\n                  class=\"df-table__resizer\"\n                  role=\"separator\"\n                  aria-orientation=\"vertical\"\n                  tabindex=\"0\"\n                  [attr.aria-label]=\"resizeLabel(col)\"\n                  [attr.aria-valuenow]=\"widths ? widths[col.key] : null\"\n                  (pointerdown)=\"onResizeStart($any($event), col)\"\n                  (pointermove)=\"onResizeMove($any($event))\"\n                  (pointerup)=\"onResizeEnd()\"\n                  (pointercancel)=\"onResizeEnd()\"\n                  (keydown)=\"onResizeKey($event, col)\"\n                  (click)=\"$event.stopPropagation()\"\n                  (dblclick)=\"resetWidths($event)\"></span>\n              }\n            </th>\n          }\n          @if (actions.length) {\n            <th scope=\"col\" class=\"df-table__actions-head\">{{ texts.actions }}</th>\n          }\n        </tr>\n        @if (hasColumnFilters) {\n          <tr class=\"df-table__filters\">\n            @if (multiple) {\n              <th [class.is-frozen]=\"hasFrozen\" [style.left]=\"hasFrozen ? 'var(--df-frozen-check)' : null\"></th>\n            }\n            @for (col of columns; track col.key) {\n              <th [class.is-frozen]=\"col.frozen\" [style.left]=\"frozenLeft(col)\">\n                @if (col.filter) {\n                  @if (filterKind(col) === 'select') {\n                    <select class=\"df-table__column-filter\" [attr.aria-label]=\"filterAria(col)\" (change)=\"onColumnFilter(col, $event)\">\n                      <option value=\"\" [selected]=\"!columnFilters[col.key]\">{{ texts.all }}</option>\n                      @for (o of filterOptions(col); track o.value) {\n                        <option [value]=\"o.value\" [selected]=\"columnFilters[col.key] === o.value\">{{ o.label }}</option>\n                      }\n                    </select>\n                  } @else {\n                    <input\n                      type=\"search\"\n                      class=\"df-table__column-filter\"\n                      [attr.aria-label]=\"filterAria(col)\"\n                      [value]=\"columnFilters[col.key] ?? ''\"\n                      (input)=\"onColumnFilter(col, $event)\" />\n                  }\n                }\n              </th>\n            }\n            @if (actions.length) {\n              <th></th>\n            }\n          </tr>\n        }\n      </thead>\n      <tbody>\n        @for (row of visibleRows; track $index) {\n          <tr\n            [class.is-selectable]=\"selectable && rowSelectable(row)\"\n            [class.is-selected]=\"isSelected(row)\"\n            [attr.aria-selected]=\"selectable && rowSelectable(row) ? isSelected(row) : null\"\n            [attr.tabindex]=\"selectable && rowSelectable(row) ? 0 : null\"\n            (mousedown)=\"onRowMouseDown($event)\"\n            (click)=\"toggle(row, $event)\"\n            (keydown.enter)=\"toggle(row)\"\n            (keydown.space)=\"$event.preventDefault(); toggle(row)\">\n            @if (multiple) {\n              <td class=\"df-table__check\" [class.is-frozen]=\"hasFrozen\" [style.left]=\"hasFrozen ? 'var(--df-frozen-check)' : null\">\n                <input\n                  type=\"checkbox\"\n                  [attr.aria-label]=\"texts.selectRow\"\n                  [checked]=\"isSelected(row)\"\n                  tabindex=\"-1\"\n                  [disabled]=\"!rowSelectable(row)\"\n                  (click)=\"$event.stopPropagation(); toggle(row, $event)\" />\n              </td>\n            }\n            @for (col of columns; track col.key) {\n              <td [attr.data-type]=\"col.type\" [class.is-frozen]=\"col.frozen\" [style.left]=\"frozenLeft(col)\">@if (cellTemplate(col); as tpl) {<ng-container *ngTemplateOutlet=\"tpl; context: cellContext(row, col)\" />} @else if (col.html) {<span [innerHTML]=\"html(row, col)\"></span>} @else if (col.type === 'badge') {@if (text(row, col); as label) {<span [class]=\"badgeClass(row, col)\">{{ label }}</span>}} @else if (col.type === 'link' && href(row, col); as target) {<a [attr.href]=\"target\" (click)=\"onLink($any($event), row, col)\">{{ text(row, col) }}</a>} @else {{{ text(row, col) }}}</td>\n            }\n            @if (actions.length) {\n              <td class=\"df-table__actions\">\n                @for (action of actions; track action.name) {\n                  @if (actionVisible(row, action)) {\n                    <button\n                      type=\"button\"\n                      class=\"df-table__action\"\n                      [class.is-icon]=\"action.icon\"\n                      [disabled]=\"actionDisabled(row, action)\"\n                      [attr.title]=\"action.tooltip || (action.icon ? action.label : null)\"\n                      [attr.aria-label]=\"action.icon ? action.label : null\"\n                      (click)=\"$event.stopPropagation(); act(row, action)\">\n                      @if (!action.icon) {\n                        {{ action.label }}\n                      } @else if (iconPath(action); as path) {\n                        <svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" aria-hidden=\"true\" focusable=\"false\"><path fill=\"currentColor\" [attr.d]=\"path\" /></svg>\n                      } @else {\n                        <span aria-hidden=\"true\">{{ action.icon }}</span>\n                      }\n                    </button>\n                  }\n                }\n              </td>\n            }\n          </tr>\n        } @empty {\n          @if (!loading) {\n            <tr class=\"df-table__empty\" [class.is-error]=\"failed\">\n              <td [attr.colspan]=\"columns.length + (actions.length ? 1 : 0) + (multiple ? 1 : 0)\">\n                @if (failed) {\n                  {{ errorMessage }}\n                  <button type=\"button\" class=\"df-table__action df-table__retry\" (click)=\"reload()\">{{ texts.retry }}</button>\n                } @else {\n                  @if (filtering && !waiting) {\n                    {{ noResultsText }}\n                  } @else if (emptyTemplate; as tpl) {\n                    <ng-container *ngTemplateOutlet=\"tpl; context: { $implicit: tableId }\" />\n                  } @else {\n                    {{ emptyMessage }}\n                  }\n                }\n              </td>\n            </tr>\n          }\n        }\n      </tbody>\n    </table>\n  </div>\n\n  @if (pageSize) {\n    <div class=\"df-table__pager\">\n      <label class=\"df-table__page-size\">\n        <span>{{ texts.rowsPerPage }}</span>\n        <select (change)=\"onPageSize($event)\">\n          @for (n of pageSizeOptions; track n) {\n            <option [value]=\"n\" [selected]=\"n === pageSize\">{{ n }}</option>\n          }\n        </select>\n      </label>\n      <span class=\"df-table__range\" aria-live=\"polite\">{{ range }}</span>\n      <button type=\"button\" class=\"df-table__page\" [disabled]=\"currentPage === 0\" (click)=\"goTo(currentPage - 1)\" [attr.aria-label]=\"texts.previousPage\">\u2039</button>\n      <button type=\"button\" class=\"df-table__page\" [disabled]=\"currentPage >= pageCount - 1\" (click)=\"goTo(currentPage + 1)\" [attr.aria-label]=\"texts.nextPage\">\u203A</button>\n    </div>\n  }\n</div>\n", styles: [":host{display:block}.df-table{margin-bottom:var(--df-field-gap)}.df-table__title{font-weight:600;color:var(--df-color-text);margin-bottom:.25rem}.df-table__description{margin:0 0 .75rem;font-size:.85rem;color:var(--df-color-muted)}.df-table__toolbar{display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:.5rem 1rem;margin-bottom:.75rem}.df-table__filter{display:flex;flex-direction:column;gap:.25rem;max-width:18rem;font-size:var(--df-label-size);font-weight:600;color:var(--df-color-text)}.df-table__search,.df-table__column-filter,.df-table__page-size select{font:inherit;font-weight:400;padding:.35rem .5rem;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);color:var(--df-color-text)}.df-table__column-filter{width:100%;min-width:5rem;box-sizing:border-box;font-size:.85rem}.df-table__filters th{font-weight:400;padding-top:.25rem}.df-table__check{width:2.25rem;text-align:center}.df-table__status.is-error{color:var(--df-color-danger)}.df-table__status{font-size:.85rem;color:var(--df-color-muted);margin-bottom:.35rem}.df-table__scroll.is-loading{opacity:.55}.df-table__empty.is-error td{color:var(--df-color-danger)}.df-table__retry{margin-left:.5rem}.df-table__scroll{overflow-x:auto;border:1px solid var(--df-color-border);border-radius:var(--df-radius)}.df-table__table{width:100%;border-collapse:collapse;font-size:.9rem;color:var(--df-color-text)}.df-table__table th,.df-table__table td{padding:.5rem .75rem;text-align:left;border-bottom:1px solid var(--df-color-border)}.df-table__table thead th{background:#7f7f7f1a;font-weight:600;white-space:nowrap}.df-table__table tbody tr:last-child td{border-bottom:0}.df-table__table td[data-type=number],.df-table__table td[data-type=currency]{text-align:right;font-variant-numeric:tabular-nums}.df-table__sort{all:unset;cursor:pointer;display:inline-flex;gap:.35rem;align-items:center}.df-table__sort:focus-visible{outline:2px solid var(--df-color-primary);outline-offset:2px}.df-table__table.is-resized{table-layout:fixed}.df-table__table.is-resized th,.df-table__table.is-resized td{overflow:hidden}.df-table__table thead th:not(.is-frozen){position:relative}.df-table__resizer{position:absolute;top:0;right:0;bottom:0;width:6px;cursor:col-resize;touch-action:none}.df-table__resizer:hover,.df-table__resizer:focus-visible{background:var(--df-color-primary);opacity:.5;outline:none}.df-table th[draggable=true]{cursor:grab}.df-table th.is-dragging{opacity:.45}.df-table th.is-drop-target{box-shadow:inset 3px 0 0 var(--df-color-primary)}.df-table__head{display:inline-flex;align-items:center;gap:.35rem}.df-table__pin{all:unset;display:inline-flex;cursor:pointer;color:var(--df-color-muted);opacity:.55;transform:rotate(45deg)}.df-table__pin:hover,.df-table__pin:focus-visible{opacity:1}.df-table__pin:focus-visible{outline:2px solid var(--df-color-primary);outline-offset:2px}.df-table__pin.is-pinned{color:var(--df-color-primary);opacity:1;transform:none}.df-table__arrow{font-size:.65rem;min-width:.65rem}.df-table .is-frozen{position:sticky;z-index:1;white-space:nowrap;background-color:var(--df-color-surface)}.df-table thead .is-frozen{background-image:linear-gradient(#7f7f7f1a,#7f7f7f1a);z-index:2}.df-table tr.is-selected .is-frozen{background-image:linear-gradient(var(--df-color-focus),var(--df-color-focus))}.df-table tr.is-selectable{cursor:pointer}.df-table tr.is-selectable:hover{background:#7f7f7f14}.df-table tr.is-selectable:focus-visible{outline:2px solid var(--df-color-primary);outline-offset:-2px}.df-table tr.is-selected{background:var(--df-color-focus)}.df-table__empty td{text-align:center;color:var(--df-color-muted)}.df-table__actions{white-space:nowrap}.df-table__action,.df-table__page{cursor:pointer;border:1px solid var(--df-color-border);border-radius:var(--df-radius);background:var(--df-color-surface);color:var(--df-color-primary);padding:.2rem .6rem;font:inherit;margin-right:.35rem}.df-table__action:disabled,.df-table__page:disabled{opacity:.5;cursor:not-allowed}.df-table__action.is-icon{display:inline-flex;align-items:center;justify-content:center;min-width:2rem;min-height:2rem;padding:.2rem}.df-table__pager{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:.75rem;margin-top:.5rem;font-size:.85rem;color:var(--df-color-muted)}.df-table__page-size{display:inline-flex;align-items:center;gap:.5rem}\n"] }]
        }], propDecorators: { onResize: [{
                type: HostListener,
                args: ['window:resize']
            }] } });

/**
 * Plantilla propia que se pinta donde el esquema tiene un nodo `{ "type": "slot", "name": "resumen" }`, entre los
 * demás campos:
 *
 *   <dynamic-form [schema]="schema" [(model)]="model">
 *     <ng-template dfSlot="resumen" let-model><app-resumen [datos]="model" /></ng-template>
 *   </dynamic-form>
 */
class DfSlotDirective {
    name = input.required({ ...(ngDevMode ? { debugName: "name" } : /* istanbul ignore next */ {}), alias: 'dfSlot' });
    template = inject(TemplateRef);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfSlotDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.25", type: DfSlotDirective, isStandalone: true, selector: "ng-template[dfSlot]", inputs: { name: { classPropertyName: "name", publicName: "dfSlot", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DfSlotDirective, decorators: [{
            type: Directive,
            args: [{ selector: 'ng-template[dfSlot]', standalone: true }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "dfSlot", required: true }] }] } });
/** Clave de `options.formState` por la que `<dynamic-form>` entrega a los nodos `slot` sus plantillas. */
const DF_SLOTS = 'dfSlots';

/** Nodo `slot`: no es un control ni toca el modelo, solo pinta la plantilla de la app con ese nombre. */
class SlotFieldComponent extends FieldType {
    get name() {
        return this.props['slotName'];
    }
    get template() {
        return this.options?.formState?.[DF_SLOTS]?.get(this.name) ?? null;
    }
    get context() {
        const model = rootModel(this.field);
        return { $implicit: model, model, name: this.name };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: SlotFieldComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: SlotFieldComponent, isStandalone: true, selector: "df-slot-field", usesInheritance: true, ngImport: i0, template: `@if (template; as tpl) {<ng-container *ngTemplateOutlet="tpl; context: context" />}`, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: SlotFieldComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'df-slot-field',
                    standalone: true,
                    imports: [NgTemplateOutlet],
                    template: `@if (template; as tpl) {<ng-container *ngTemplateOutlet="tpl; context: context" />}`,
                    // El modelo cambia sin que Formly avise a este componente: se revisa en cada pasada.
                    changeDetection: ChangeDetectionStrategy.Default,
                }]
        }] });

/** Wrapper estándar: label, control proyectado, descripción y mensajes de error. */
class FieldWrapperComponent extends FieldWrapper {
    get showLabel() {
        return !!this.props.label && this.props['hideLabel'] !== true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FieldWrapperComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: FieldWrapperComponent, isStandalone: true, selector: "df-field-wrapper", usesInheritance: true, ngImport: i0, template: "<div\n  class=\"df-field\"\n  [class.df-field--invalid]=\"showError\"\n  [class.df-field--required]=\"props.required === true\"\n  [class.df-field--disabled]=\"props.disabled === true\">\n  @if (showLabel) {\n    <label class=\"df-label\" [attr.for]=\"id\">\n      {{ props.label }}\n      @if (props.required) { <span class=\"df-required\" aria-hidden=\"true\">*</span> }\n    </label>\n  }\n\n  <div class=\"df-field__control\">\n    <ng-container #fieldComponent></ng-container>\n  </div>\n\n  @if (props.description) {\n    <small class=\"df-description\">{{ props.description }}</small>\n  }\n\n  @if (showError) {\n    <div class=\"df-error\" role=\"alert\">\n      <formly-validation-message [field]=\"field\"></formly-validation-message>\n    </div>\n  }\n</div>\n", styles: [":host{display:block}.df-field{display:flex;flex-direction:column;gap:.35rem;margin-bottom:var(--df-field-gap)}.df-field--disabled{opacity:.65}.df-label{font-size:var(--df-label-size);font-weight:600;color:var(--df-color-text)}.df-required{color:var(--df-color-danger);margin-left:.15rem}.df-description{font-size:.8rem;color:var(--df-color-muted)}.df-error{font-size:.8rem;color:var(--df-color-danger)}\n"], dependencies: [{ kind: "ngmodule", type: FormlyModule }, { kind: "component", type: i2.LegacyFormlyValidationMessage, selector: "formly-validation-message" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FieldWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-field-wrapper', standalone: true, imports: [FormlyModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"df-field\"\n  [class.df-field--invalid]=\"showError\"\n  [class.df-field--required]=\"props.required === true\"\n  [class.df-field--disabled]=\"props.disabled === true\">\n  @if (showLabel) {\n    <label class=\"df-label\" [attr.for]=\"id\">\n      {{ props.label }}\n      @if (props.required) { <span class=\"df-required\" aria-hidden=\"true\">*</span> }\n    </label>\n  }\n\n  <div class=\"df-field__control\">\n    <ng-container #fieldComponent></ng-container>\n  </div>\n\n  @if (props.description) {\n    <small class=\"df-description\">{{ props.description }}</small>\n  }\n\n  @if (showError) {\n    <div class=\"df-error\" role=\"alert\">\n      <formly-validation-message [field]=\"field\"></formly-validation-message>\n    </div>\n  }\n</div>\n", styles: [":host{display:block}.df-field{display:flex;flex-direction:column;gap:.35rem;margin-bottom:var(--df-field-gap)}.df-field--disabled{opacity:.65}.df-label{font-size:var(--df-label-size);font-weight:600;color:var(--df-color-text)}.df-required{color:var(--df-color-danger);margin-left:.15rem}.df-description{font-size:.8rem;color:var(--df-color-muted)}.df-error{font-size:.8rem;color:var(--df-color-danger)}\n"] }]
        }] });

/** Fieldset con título/descripción para nodos de tipo group. */
class GroupWrapperComponent extends FieldWrapper {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: GroupWrapperComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: GroupWrapperComponent, isStandalone: true, selector: "df-group-wrapper", usesInheritance: true, ngImport: i0, template: "<fieldset class=\"df-group\" [class]=\"props['cssClass']\" [attr.data-group-id]=\"props['groupId']\">\n  @if (props['title']) {\n    <legend class=\"df-group__title\">{{ props['title'] }}</legend>\n  }\n  @if (props['description']) {\n    <p class=\"df-group__description\">{{ props['description'] }}</p>\n  }\n  <ng-container #fieldComponent></ng-container>\n</fieldset>\n", styles: [":host{display:block}.df-group{border:1px solid var(--df-color-border);border-radius:var(--df-radius);padding:1rem 1.25rem .25rem;margin:0 0 var(--df-field-gap);min-width:0}.df-group__title{padding:0 .5rem;font-weight:600;color:var(--df-color-text)}.df-group__description{margin:0 0 .75rem;font-size:.85rem;color:var(--df-color-muted)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: GroupWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'df-group-wrapper', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<fieldset class=\"df-group\" [class]=\"props['cssClass']\" [attr.data-group-id]=\"props['groupId']\">\n  @if (props['title']) {\n    <legend class=\"df-group__title\">{{ props['title'] }}</legend>\n  }\n  @if (props['description']) {\n    <p class=\"df-group__description\">{{ props['description'] }}</p>\n  }\n  <ng-container #fieldComponent></ng-container>\n</fieldset>\n", styles: [":host{display:block}.df-group{border:1px solid var(--df-color-border);border-radius:var(--df-radius);padding:1rem 1.25rem .25rem;margin:0 0 var(--df-field-gap);min-width:0}.df-group__title{padding:0 .5rem;font-weight:600;color:var(--df-color-text)}.df-group__description{margin:0 0 .75rem;font-size:.85rem;color:var(--df-color-muted)}\n"] }]
        }] });

const DF_PLAIN_TYPE_NAMES = {
    input: 'df-input',
    select: 'df-select',
    textarea: 'df-textarea',
    checkbox: 'df-checkbox',
    radio: 'df-radio',
    hidden: 'df-hidden',
    currency: 'df-currency',
    repeat: 'df-repeat',
    table: 'df-table',
    slot: 'df-slot',
};
/**
 * Tema por defecto: sin dependencias de UI, componentes propios de la librería.
 * Estilos: @use '@core/dynamic-forms/styles/plain';
 */
const PLAIN_THEME = {
    name: 'plain',
    hostClass: 'df-theme-plain',
    fieldWrappers: ['df-field'],
    groupWrapper: 'df-group',
    typeMap: {
        text: DF_PLAIN_TYPE_NAMES.input,
        email: DF_PLAIN_TYPE_NAMES.input,
        password: DF_PLAIN_TYPE_NAMES.input,
        number: DF_PLAIN_TYPE_NAMES.input,
        date: DF_PLAIN_TYPE_NAMES.input,
        textarea: DF_PLAIN_TYPE_NAMES.textarea,
        select: DF_PLAIN_TYPE_NAMES.select,
        multiselect: DF_PLAIN_TYPE_NAMES.select,
        radio: DF_PLAIN_TYPE_NAMES.radio,
        checkbox: DF_PLAIN_TYPE_NAMES.checkbox,
        hidden: DF_PLAIN_TYPE_NAMES.hidden,
        currency: DF_PLAIN_TYPE_NAMES.currency,
    },
    formlyConfig: {
        types: [
            { name: DF_PLAIN_TYPE_NAMES.input, component: InputFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.select, component: SelectFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.textarea, component: TextareaFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.checkbox, component: CheckboxFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.radio, component: RadioFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.hidden, component: HiddenFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.currency, component: CurrencyFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.repeat, component: RepeatFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.table, component: TableFieldComponent },
            { name: DF_PLAIN_TYPE_NAMES.slot, component: SlotFieldComponent },
        ],
        wrappers: [
            { name: 'df-field', component: FieldWrapperComponent },
            { name: 'df-group', component: GroupWrapperComponent },
        ],
    },
};

const DNI_LETTERS = 'TRWAGMYFPDXBNJZSQVHLCKE';
const normalize = (v) => (v == null ? '' : String(v)).trim().toUpperCase().replace(/[\s-]/g, '');
/** Un valor vacío siempre es válido: de "obligatorio" se encarga `required`. */
const isEmpty = (c) => c.value == null || c.value === '';
function isValidDni(raw) {
    const v = normalize(raw);
    if (!/^\d{8}[A-Z]$/.test(v))
        return false;
    return DNI_LETTERS[Number(v.slice(0, 8)) % 23] === v[8];
}
function isValidNie(raw) {
    const v = normalize(raw);
    if (!/^[XYZ]\d{7}[A-Z]$/.test(v))
        return false;
    const prefix = { X: '0', Y: '1', Z: '2' }[v[0]];
    return DNI_LETTERS[Number(prefix + v.slice(1, 8)) % 23] === v[8];
}
function isValidCif(raw) {
    const v = normalize(raw);
    if (!/^[ABCDEFGHJKLMNPQRSUVW]\d{7}[0-9A-J]$/.test(v))
        return false;
    const digits = v.slice(1, 8);
    let sum = 0;
    for (let i = 0; i < 7; i++) {
        const n = Number(digits[i]);
        if (i % 2 === 0) {
            const d = n * 2;
            sum += d > 9 ? d - 9 : d;
        }
        else {
            sum += n;
        }
    }
    const controlDigit = (10 - (sum % 10)) % 10;
    const controlLetter = 'JABCDEFGHI'[controlDigit];
    const control = v[8];
    const letterOnly = /^[KPQS]$/.test(v[0]);
    const digitOnly = /^[ABEH]$/.test(v[0]);
    if (letterOnly)
        return control === controlLetter;
    if (digitOnly)
        return control === String(controlDigit);
    return control === controlLetter || control === String(controlDigit);
}
function isValidIban(raw) {
    const v = normalize(raw);
    if (!/^[A-Z]{2}\d{2}[A-Z0-9]{11,30}$/.test(v))
        return false;
    const rearranged = v.slice(4) + v.slice(0, 4);
    const numeric = rearranged.replace(/[A-Z]/g, (ch) => String(ch.charCodeAt(0) - 55));
    let remainder = 0;
    for (const ch of numeric)
        remainder = (remainder * 10 + Number(ch)) % 97;
    return remainder === 1;
}
const isValidPhoneES = (raw) => /^[6789]\d{8}$/.test(normalize(raw));
function isValidPostalCodeES(raw) {
    const v = normalize(raw);
    if (!/^\d{5}$/.test(v))
        return false;
    const province = Number(v.slice(0, 2));
    return province >= 1 && province <= 52;
}
const BUSINESS_VALIDATORS = [
    { name: 'dni', message: 'El DNI no es válido', validate: (c) => isEmpty(c) || isValidDni(c.value) },
    { name: 'nie', message: 'El NIE no es válido', validate: (c) => isEmpty(c) || isValidNie(c.value) },
    {
        name: 'dniNie',
        message: 'El documento no es válido',
        validate: (c) => isEmpty(c) || isValidDni(c.value) || isValidNie(c.value),
    },
    { name: 'cif', message: 'El CIF no es válido', validate: (c) => isEmpty(c) || isValidCif(c.value) },
    { name: 'iban', message: 'El IBAN no es válido', validate: (c) => isEmpty(c) || isValidIban(c.value) },
    { name: 'phoneES', message: 'El teléfono no es válido', validate: (c) => isEmpty(c) || isValidPhoneES(c.value) },
    {
        name: 'postalCodeES',
        message: 'El código postal no es válido',
        validate: (c) => isEmpty(c) || isValidPostalCodeES(c.value),
    },
    {
        name: 'matchesField',
        message: 'Los valores no coinciden',
        validate: (c, args) => {
            const other = args?.['field'];
            if (typeof other !== 'string' || isEmpty(c))
                return true;
            return c.value === c.root.get(other.split('.'))?.value;
        },
    },
];

/** Mensajes built-in (ValidationContract.builtIn). */
const DEFAULT_VALIDATION_MESSAGES = {
    required: 'Este campo es obligatorio',
    email: 'Debe ser un email válido',
    pattern: 'El formato no es válido',
    min: (e) => `El valor mínimo es ${e['min']}`,
    max: (e) => `El valor máximo es ${e['max']}`,
    minLength: (e) => `Mínimo ${e['requiredLength']} caracteres`,
    maxLength: (e) => `Máximo ${e['requiredLength']} caracteres`,
    // El ejemplo sigue el formato del campo: 1.500,75 (es) o 1,500.75 (en).
    minItems: (_e, field) => `Añade al menos ${field.props?.['minItems']} elemento(s)`,
    maxItems: (_e, field) => `No puede haber más de ${field.props?.['maxItems']} elemento(s)`,
    currencyFormat: (_e, field) => `El importe no tiene un formato válido (p. ej. ${amountExample(field.props?.['numberFormat'])})`,
    currencyDecimals: 'El importe no puede tener más de dos decimales',
};
/** Juego completo en inglés: `provideDynamicForms({ messages: EN_VALIDATION_MESSAGES })`. */
const EN_VALIDATION_MESSAGES = {
    required: 'This field is required',
    email: 'Must be a valid email',
    pattern: 'The format is not valid',
    min: (e) => `The minimum value is ${e['min']}`,
    max: (e) => `The maximum value is ${e['max']}`,
    minLength: (e) => `At least ${e['requiredLength']} characters`,
    maxLength: (e) => `At most ${e['requiredLength']} characters`,
    minItems: (_e, field) => `Add at least ${field.props?.['minItems']} item(s)`,
    maxItems: (_e, field) => `There can be no more than ${field.props?.['maxItems']} item(s)`,
    currencyFormat: (_e, field) => `The amount is not in a valid format (e.g. ${amountExample(field.props?.['numberFormat'])})`,
    currencyDecimals: 'The amount cannot have more than two decimals',
};
function toFormlyMessages(messages) {
    return Object.entries(messages).map(([name, message]) => ({ name, message }));
}

/**
 * Inicializa @core/dynamic-forms en la app consumidora.
 *
 *   bootstrapApplication(App, { providers: [provideDynamicForms()] });
 *   bootstrapApplication(App, { providers: [provideDynamicForms({ theme: materialTheme([...]) })] });
 */
function provideDynamicForms(config = {}) {
    const theme = config.theme ?? PLAIN_THEME;
    const resolved = {
        theme,
        defaultResetOnHide: config.defaultResetOnHide ?? true,
        strictSchema: config.strictSchema ?? true,
        maxLengthMode: config.maxLengthMode ?? 'weighted',
        currency: resolveCurrency(config.currency),
        tableTexts: { ...DEFAULT_TABLE_TEXTS, ...config.tableTexts },
    };
    return makeEnvironmentProviders([
        { provide: DYNAMIC_FORMS_CONFIG, useValue: resolved },
        { provide: DF_VALIDATORS, useValue: BUSINESS_VALIDATORS, multi: true },
        { provide: DF_VALIDATORS, useValue: config.validators ?? [], multi: true },
        ...(config.tableProvider ? [{ provide: DF_TABLE_PROVIDER, useClass: config.tableProvider }] : []),
        ...(config.optionsProvider ? [{ provide: DF_OPTIONS_PROVIDER, useClass: config.optionsProvider }] : []),
        ...(theme.providers ?? []),
        importProvidersFrom(FormlyModule.forRoot({
            types: [...(theme.formlyConfig?.types ?? []), ...(config.types ?? [])],
            wrappers: [...(theme.formlyConfig?.wrappers ?? []), ...(config.wrappers ?? [])],
            validationMessages: toFormlyMessages({ ...DEFAULT_VALIDATION_MESSAGES, ...(config.messages ?? {}) }),
            extras: { lazyRender: true, resetFieldOnHide: resolved.defaultResetOnHide, checkExpressionOn: 'modelChange' },
        })),
    ]);
}
/** Completa la config de moneda y falla al arrancar si un valor no es válido (mejor que dentro de Intl). */
function resolveCurrency(currency = {}) {
    const numberFormat = currency.numberFormat ?? 'es';
    const resolved = {
        code: currency.code ?? 'EUR',
        numberFormat,
        wordsLanguage: currency.wordsLanguage ?? numberFormat,
        amountInWords: currency.amountInWords ?? true,
        wordsUppercase: currency.wordsUppercase ?? true,
    };
    if (!isCurrencyCode(resolved.code)) {
        throw new Error(`[dynamic-forms] currency.code debe ser un código ISO 4217 (EUR, GBP…): ${String(resolved.code)}`);
    }
    if (!NUMBER_FORMATS.includes(resolved.numberFormat)) {
        throw new Error(`[dynamic-forms] currency.numberFormat debe ser 'es' o 'en': ${String(resolved.numberFormat)}`);
    }
    if (!WORDS_LANGUAGES.includes(resolved.wordsLanguage)) {
        throw new Error(`[dynamic-forms] currency.wordsLanguage debe ser 'es' o 'en': ${String(resolved.wordsLanguage)}`);
    }
    return resolved;
}

/**
 * Temas que delegan en los paquetes UI oficiales de Formly. La librería NO
 * depende de ellos: la app consumidora instala @ngx-formly/material (o
 * bootstrap) y pasa sus providers, p. ej.:
 *
 *   provideDynamicForms({
 *     theme: materialTheme([importProvidersFrom(FormlyMaterialModule, MatNativeDateModule)]),
 *   })
 *
 * `currency` se pinta con el input de texto del paquete UI: valida el formato (currencyFormat/currencyDecimals)
 * pero no formatea ni escribe el importe en letra, y el modelo guarda el texto. El campo completo solo
 * existe en PLAIN_THEME, porque el form-field de Material exige un MatFormFieldControl.
 * Las listas repetibles (`array`) y las tablas de datos (`table`) se pintan con `df-repeat` y `df-table`, los mismos componentes de la librería en todos los temas.
 */
const sharedConfig = {
    types: [
        { name: 'df-hidden', component: HiddenFieldComponent },
        { name: 'df-repeat', component: RepeatFieldComponent },
        { name: 'df-table', component: TableFieldComponent },
        { name: 'df-slot', component: SlotFieldComponent },
    ],
    wrappers: [
        { name: 'df-group', component: GroupWrapperComponent },
        { name: 'df-field', component: FieldWrapperComponent },
    ],
};
function materialTheme(providers = [], overrides = {}) {
    return {
        name: 'material',
        hostClass: 'df-theme-material',
        fieldWrappers: ['form-field'],
        groupWrapper: 'df-group',
        providers,
        formlyConfig: sharedConfig,
        typeMap: {
            text: 'input', email: 'input', password: 'input', number: 'input',
            date: 'datepicker', textarea: 'textarea', select: 'select', multiselect: 'select',
            radio: 'radio', checkbox: 'checkbox', hidden: 'df-hidden', currency: 'input',
        },
        // checkbox y radio no son un MatFormFieldControl: dentro de un mat-form-field salen en un recuadro. Van con el
        // wrapper de la librería (descripción y errores); el checkbox pinta su propia etiqueta.
        typeWrappers: { checkbox: ['df-field'], radio: ['df-field'] },
        typeProps: { multiselect: { multiple: true }, checkbox: { hideLabel: true } },
        ...overrides,
    };
}
function bootstrapTheme(providers = [], overrides = {}) {
    return {
        name: 'bootstrap',
        hostClass: 'df-theme-bootstrap',
        fieldWrappers: ['form-field'],
        groupWrapper: 'df-group',
        providers,
        formlyConfig: sharedConfig,
        typeMap: {
            text: 'input', email: 'input', password: 'input', number: 'input',
            date: 'input', textarea: 'textarea', select: 'select', multiselect: 'select',
            radio: 'radio', checkbox: 'checkbox', hidden: 'df-hidden', currency: 'input',
        },
        typeProps: { multiselect: { multiple: true }, date: { type: 'date' } },
        ...overrides,
    };
}

/**
 * Longitud CSS simple (0, 12px, 1.5rem, 2em, 5%…). Es todo lo que admite layout.gap:
 * nada de url(), var() ni calc(), porque el valor viene del backend y acaba en un estilo.
 */
const CSS_LENGTH_RE = /^(0|\d*\.?\d+(px|rem|em|%|vw|vh))$/;
const isCssLength = (value) => typeof value === 'string' && CSS_LENGTH_RE.test(value.trim());

/**
 * Catálogo de validadores de negocio referenciables por alias desde el esquema.
 * Se alimenta de DF_VALIDATORS (multi) y admite registro en tiempo de ejecución.
 */
class ValidatorRegistryService {
    registry = new Map();
    constructor() {
        const groups = inject(DF_VALIDATORS, { optional: true }) ?? [];
        groups.flat().forEach((def) => this.register(def));
    }
    register(definition) {
        if (!definition?.name)
            throw new Error('[dynamic-forms] Un validador necesita "name".');
        this.registry.set(definition.name, definition);
    }
    get(name) {
        return this.registry.get(name);
    }
    has(name) {
        return this.registry.has(name);
    }
    names() {
        return [...this.registry.keys()];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: ValidatorRegistryService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: ValidatorRegistryService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: ValidatorRegistryService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

const KEY_RE = /^[A-Za-z_][A-Za-z0-9_.]*$/;
const ID_RE = /^[A-Za-z][A-Za-z0-9_-]*$/;
const FILENAME_RE = /^[A-Za-z0-9_][A-Za-z0-9_. -]*$/;
const OPTION_TYPES = new Set(['select', 'multiselect', 'radio']);
/** Operadores que no comparan contra un valor. */
const VALUELESS_OPERATORS = new Set(['empty', 'notEmpty', 'truthy', 'falsy']);
/** Claves de los campos de la fila de una lista repetible; `null` fuera de ellas. */
/** `ctx` (o `ctx.algo`) es del contexto externo: un campo con esa clave haría ambigua la ruta `ctx.nombre`. */
const isReservedKey = (key) => key === 'ctx' || key.startsWith('ctx.');
const SLOT_NAME_RE = /^[A-Za-z][A-Za-z0-9_-]*$/;
const HREF_RE = /^(\/(?!\/)|#|https?:\/\/)\S*$/;
/** Conjunto que acepta cualquier clave: las filas de una tabla no declaran sus propiedades. */
const ANY_ROW_KEY = new (class extends Set {
    has() { return true; }
})();
/**
 * Validación estructural del SchemaContract sin dependencias externas (sin ajv).
 * Comprueba lo que de verdad rompe el render: tipos, keys, referencias cruzadas
 * en condiciones/dependsOn y aliases de validadores no registrados.
 */
class SchemaValidatorService {
    registry = inject(ValidatorRegistryService);
    formlyConfig = inject(FormlyConfig, { optional: true });
    /**
     * Formly aplica la config de forRoot() en diferido (al crear el primer formulario), y aquí se valida
     * antes; por eso se leen también los tipos declarados en FORMLY_CONFIG.
     */
    declaredTypes = new Set([inject(FORMLY_CONFIG, { optional: true }) ?? []]
        .flat(Infinity)
        .flatMap((c) => c?.types?.map((t) => t.name) ?? []));
    validate(schema) {
        const errors = [];
        const push = (path, message) => errors.push({ path, message });
        if (!schema || typeof schema !== 'object') {
            push('$', 'El esquema debe ser un objeto');
            return { valid: false, errors };
        }
        const s = schema;
        if (s.version !== '1.0')
            push('version', `Versión no soportada: ${String(s.version)}`);
        if (typeof s.id !== 'string' || !ID_RE.test(s.id))
            push('id', 'id obligatorio con formato ^[A-Za-z][A-Za-z0-9_-]*$');
        const cols = s.layout?.columns;
        if (cols != null && !(Number.isInteger(cols) && cols >= 1 && cols <= 12))
            push('layout.columns', 'columns entre 1 y 12');
        if (s.layout?.resetOnHide != null && typeof s.layout.resetOnHide !== 'boolean')
            push('layout.resetOnHide', 'resetOnHide debe ser true o false');
        if (s.layout?.gap != null && !isCssLength(s.layout.gap))
            push('layout.gap', 'gap debe ser una longitud CSS (p. ej. 1rem, 12px)');
        if (!Array.isArray(s.fields) || s.fields.length === 0) {
            push('fields', 'fields debe ser un array con al menos un elemento');
            return { valid: false, errors };
        }
        // Claves absolutas (raíz del modelo). Las de dentro de una lista repetible son de su fila, no de la raíz.
        const keys = this.collectKeys(s.fields);
        this.visitNodes(s.fields, 'fields', push, keys, null, null);
        return { valid: errors.length === 0, errors };
    }
    /** Claves de los campos y listas de un nivel, atravesando grupos pero no listas (cada fila tiene las suyas). */
    collectKeys(nodes) {
        const keys = new Set();
        const walk = (list) => list.forEach((n) => {
            if (!n || typeof n !== 'object')
                return;
            if (isDfGroup(n))
                walk(Array.isArray(n.fields) ? n.fields : []);
            else if (!isDfTable(n) && !isDfSlot(n) && n.key)
                keys.add(n.key);
        });
        walk(nodes);
        return keys;
    }
    /** `row`: contexto de la lista repetible que contiene los nodos (claves de la fila y su disposición). */
    visitNodes(nodes, path, push, keys, row, table) {
        nodes.forEach((node, i) => {
            const p = `${path}[${i}]`;
            if (!node || typeof node !== 'object')
                return push(p, 'Nodo inválido');
            if (isDfGroup(node)) {
                if (table)
                    push(`${p}.type`, 'Una lista con display "table" solo admite campos, no grupos');
                return this.validateGroup(node, p, push, keys, row, table);
            }
            if (isDfSlot(node)) {
                if (row)
                    push(`${p}.type`, 'Un slot no puede ir dentro de una lista repetible');
                if (typeof node.name !== 'string' || !SLOT_NAME_RE.test(node.name))
                    push(`${p}.name`, 'Un slot necesita name con formato ^[A-Za-z][A-Za-z0-9_-]*$');
                if (node.cssClass != null && typeof node.cssClass !== 'string')
                    push(`${p}.cssClass`, 'cssClass debe ser un texto');
                return this.validateLogic(node.logic, `${p}.logic`, push, keys, row);
            }
            if (isDfArray(node))
                return this.validateArray(node, p, push, keys, row);
            if (isDfTable(node)) {
                if (table)
                    push(`${p}.type`, 'Una lista con display "table" solo admite campos, no tablas de datos');
                return this.validateTable(node, p, push, keys, row);
            }
            this.validateField(node, p, push, keys, row, table);
        });
    }
    validateGroup(g, p, push, keys, row, table) {
        if (typeof g.id !== 'string' || !g.id)
            push(`${p}.id`, 'Un grupo necesita id');
        if (g.columns != null && (g.columns < 1 || g.columns > 12))
            push(`${p}.columns`, 'columns entre 1 y 12');
        if (!Array.isArray(g.fields) || g.fields.length === 0)
            push(`${p}.fields`, 'Un grupo necesita fields');
        else
            this.visitNodes(g.fields, `${p}.fields`, push, keys, row, table);
        this.validateLogic(g.logic, `${p}.logic`, push, keys, row);
    }
    validateArray(a, p, push, keys, row) {
        if (row)
            push(`${p}.type`, 'Una lista no puede ir dentro de otra lista');
        if (typeof a.key !== 'string' || !KEY_RE.test(a.key))
            push(`${p}.key`, 'key obligatoria con formato ^[A-Za-z_][A-Za-z0-9_.]*$');
        else if (isReservedKey(a.key))
            push(`${p}.key`, 'La clave ctx está reservada para el contexto externo de las condiciones (ctx.nombre)');
        if (a.display != null && a.display !== 'rows' && a.display !== 'table')
            push(`${p}.display`, "display debe ser 'rows' o 'table'");
        if (a.columns != null && !(Number.isInteger(a.columns) && a.columns >= 1 && a.columns <= 12))
            push(`${p}.columns`, 'columns entre 1 y 12');
        const isCount = (n) => Number.isInteger(n) && n >= 0;
        if (a.minItems != null && !isCount(a.minItems))
            push(`${p}.minItems`, 'minItems debe ser un entero mayor o igual que 0');
        if (a.maxItems != null && !(isCount(a.maxItems) && a.maxItems >= 1))
            push(`${p}.maxItems`, 'maxItems debe ser un entero mayor o igual que 1');
        if (isCount(a.minItems) && isCount(a.maxItems) && a.minItems > a.maxItems)
            push(`${p}.maxItems`, 'maxItems no puede ser menor que minItems');
        if (!Array.isArray(a.fields) || a.fields.length === 0) {
            push(`${p}.fields`, 'Una lista necesita fields');
        }
        else {
            this.visitNodes(a.fields, `${p}.fields`, push, keys, this.collectKeys(a.fields), a.display === 'table' ? a : null);
        }
        this.validateTotals(a, p, push);
        this.validateLogic(a.logic, `${p}.logic`, push, keys, row);
    }
    validateTable(t, p, push, keys, row) {
        if (typeof t.id !== 'string' || !ID_RE.test(t.id))
            push(`${p}.id`, 'Una tabla necesita id con formato ^[A-Za-z][A-Za-z0-9_-]*$');
        const isCount = (n) => Number.isInteger(n) && n >= 1;
        if (t.pageSize != null && !isCount(t.pageSize))
            push(`${p}.pageSize`, 'pageSize debe ser un entero mayor o igual que 1');
        if (t.pageSizeOptions != null && !(Array.isArray(t.pageSizeOptions) && t.pageSizeOptions.length > 0 && t.pageSizeOptions.every(isCount))) {
            push(`${p}.pageSizeOptions`, 'pageSizeOptions debe ser un array de enteros mayores o igual que 1');
        }
        if (t.searchKeys != null && !(Array.isArray(t.searchKeys) && t.searchKeys.every((k) => typeof k === 'string' && KEY_RE.test(k)))) {
            push(`${p}.searchKeys`, 'searchKeys debe ser un array de claves con formato ^[A-Za-z_][A-Za-z0-9_.]*$');
        }
        if (t.dataKey != null && (typeof t.dataKey !== 'string' || !KEY_RE.test(t.dataKey)))
            push(`${p}.dataKey`, 'dataKey con formato ^[A-Za-z_][A-Za-z0-9_.]*$');
        if (t.rows != null && !(Array.isArray(t.rows) && t.rows.every((r) => r && typeof r === 'object' && !Array.isArray(r)))) {
            push(`${p}.rows`, 'rows debe ser un array de objetos');
        }
        if (t.source != null)
            this.validateTableSource(t, p, push, keys, row);
        if (t.selectable != null && typeof t.selectable !== 'boolean' && t.selectable !== 'single' && t.selectable !== 'multiple') {
            push(`${p}.selectable`, "selectable debe ser true, false, 'single' o 'multiple'");
        }
        if (t.pinnableColumns != null && typeof t.pinnableColumns !== 'boolean')
            push(`${p}.pinnableColumns`, 'pinnableColumns debe ser true o false');
        if (t.resizableColumns != null && typeof t.resizableColumns !== 'boolean')
            push(`${p}.resizableColumns`, 'resizableColumns debe ser true o false');
        if (t.reorderableColumns != null && typeof t.reorderableColumns !== 'boolean')
            push(`${p}.reorderableColumns`, 'reorderableColumns debe ser true o false');
        if (t.persistState != null && typeof t.persistState !== 'boolean' && t.persistState !== 'session' && t.persistState !== 'local') {
            push(`${p}.persistState`, "persistState debe ser true, false, 'session' o 'local'");
        }
        if (t.stateKey != null && (typeof t.stateKey !== 'string' || !ID_RE.test(t.stateKey))) {
            push(`${p}.stateKey`, 'stateKey con formato ^[A-Za-z][A-Za-z0-9_-]*$');
        }
        if (t.selectableWhen != null) {
            if (t.selectable == null || t.selectable === false)
                push(`${p}.selectableWhen`, 'selectableWhen solo tiene sentido con selectable');
            this.validateRule(t.selectableWhen, `${p}.selectableWhen`, push, keys, ANY_ROW_KEY);
        }
        if (t.headerSelects != null) {
            if (t.headerSelects !== 'filtered' && t.headerSelects !== 'page')
                push(`${p}.headerSelects`, "headerSelects debe ser 'filtered' o 'page'");
            else if (t.selectable !== 'multiple')
                push(`${p}.headerSelects`, "headerSelects solo tiene sentido con selectable: 'multiple'");
        }
        if (t.selectionKey != null) {
            if (typeof t.selectionKey !== 'string' || !KEY_RE.test(t.selectionKey))
                push(`${p}.selectionKey`, 'selectionKey con formato ^[A-Za-z_][A-Za-z0-9_.]*$');
            else if (t.selectable !== 'multiple')
                push(`${p}.selectionKey`, "selectionKey solo tiene sentido con selectable: 'multiple'");
        }
        if (t.exportCsv != null && typeof t.exportCsv !== 'boolean') {
            const e = t.exportCsv;
            if (!e || typeof e !== 'object' || Array.isArray(e))
                push(`${p}.exportCsv`, 'exportCsv debe ser true, false o un objeto { filename }');
            else {
                const name = e.filename;
                if (Object.keys(e).some((k) => k !== 'filename'))
                    push(`${p}.exportCsv`, 'exportCsv solo admite filename');
                if (name != null && (typeof name !== 'string' || name.length > 100 || !FILENAME_RE.test(name))) {
                    push(`${p}.exportCsv.filename`, 'filename con formato ^[A-Za-z0-9_][A-Za-z0-9_. -]*$ y hasta 100 caracteres');
                }
            }
        }
        const columnKeys = new Set();
        if (!Array.isArray(t.columns) || t.columns.length === 0) {
            push(`${p}.columns`, 'Una tabla necesita columns');
        }
        else {
            t.columns.forEach((c, i) => {
                const cp = `${p}.columns[${i}]`;
                if (!c || typeof c !== 'object')
                    return push(cp, 'Columna inválida');
                if (typeof c.key !== 'string' || !KEY_RE.test(c.key))
                    push(`${cp}.key`, 'key obligatoria con formato ^[A-Za-z_][A-Za-z0-9_.]*$');
                else if (columnKeys.has(c.key))
                    push(`${cp}.key`, `Columna repetida: ${c.key}`);
                else
                    columnKeys.add(c.key);
                if (typeof c.label !== 'string' || !c.label)
                    push(`${cp}.label`, 'Una columna necesita label');
                if (c.type != null && !DF_TABLE_COLUMN_TYPES.includes(c.type))
                    push(`${cp}.type`, `Tipo de columna no soportado: ${String(c.type)}`);
                if (c.type === 'map' && (!c.map || typeof c.map !== 'object' || Array.isArray(c.map)))
                    push(`${cp}.map`, 'Una columna map necesita map');
                if (c.type === 'badge' && c.variants != null) {
                    const bad = !c.variants || typeof c.variants !== 'object' || Array.isArray(c.variants)
                        || Object.values(c.variants).some((x) => !DF_BADGE_VARIANTS.includes(x));
                    if (bad)
                        push(`${cp}.variants`, 'variants debe asignar a cada valor ok, warn, error o info');
                }
                else if (c.type !== 'badge' && c.variants != null)
                    push(`${cp}.variants`, 'variants solo se admite en columnas de tipo badge');
                if (c.template != null && (typeof c.template !== 'string' || !SLOT_NAME_RE.test(c.template)))
                    push(`${cp}.template`, 'template con formato ^[A-Za-z][A-Za-z0-9_-]*$');
                if (c.type === 'link') {
                    if (typeof c.href !== 'string' || !HREF_RE.test(c.href))
                        push(`${cp}.href`, 'Una columna link necesita href que empiece por /, #, http:// o https://');
                }
                else if (c.href != null)
                    push(`${cp}.href`, 'href solo se admite en columnas de tipo link');
                if (c.col != null && !(Number.isInteger(c.col) && c.col >= 1 && c.col <= 12))
                    push(`${cp}.col`, 'col entre 1 y 12');
                if (c.filter != null && typeof c.filter !== 'boolean')
                    push(`${cp}.filter`, 'filter debe ser true o false');
                if (c.frozen != null && typeof c.frozen !== 'boolean')
                    push(`${cp}.frozen`, 'frozen debe ser true o false');
                else if (c.frozen === true && t.columns.slice(0, i).some((prev) => prev?.frozen !== true)) {
                    push(`${cp}.frozen`, 'Una columna fija no puede ir detrás de una que no lo es: las fijas van primero');
                }
                if (c.html != null && typeof c.html !== 'boolean')
                    push(`${cp}.html`, 'html debe ser true o false');
                else if (c.html === true && c.type != null && c.type !== 'text')
                    push(`${cp}.html`, 'html solo se admite en columnas de tipo text');
                if (c.currency != null && !isCurrencyCode(c.currency))
                    push(`${cp}.currency`, `Código de moneda ISO 4217 no válido: ${String(c.currency)}`);
            });
        }
        if (t.multiSort != null && typeof t.multiSort !== 'boolean')
            push(`${p}.multiSort`, 'multiSort debe ser true o false');
        if (t.sort != null) {
            const list = Array.isArray(t.sort) ? t.sort : [t.sort];
            if (list.length > 1 && t.multiSort !== true)
                push(`${p}.sort`, 'Un orden con varias columnas necesita multiSort: true');
            const seen = new Set();
            list.forEach((s, i) => {
                const sp = Array.isArray(t.sort) ? `${p}.sort[${i}]` : `${p}.sort`;
                if (!s || typeof s !== 'object' || !columnKeys.has(s.key))
                    push(`${sp}.key`, 'sort.key debe ser la key de una columna');
                else if (seen.has(s.key))
                    push(`${sp}.key`, `Columna repetida en el orden: ${s.key}`);
                else
                    seen.add(s.key);
                if (s && typeof s === 'object' && s.direction != null && s.direction !== 'asc' && s.direction !== 'desc')
                    push(`${sp}.direction`, "direction debe ser 'asc' o 'desc'");
            });
        }
        if (t.actions != null) {
            if (!Array.isArray(t.actions))
                push(`${p}.actions`, 'actions debe ser un array');
            else {
                const names = new Set();
                t.actions.forEach((a, i) => {
                    const ap = `${p}.actions[${i}]`;
                    if (!a || typeof a.name !== 'string' || !a.name)
                        push(`${ap}.name`, 'name obligatorio');
                    else if (names.has(a.name))
                        push(`${ap}.name`, `Acción repetida: ${a.name}`);
                    else
                        names.add(a.name);
                    if (!a || typeof a.label !== 'string' || !a.label)
                        push(`${ap}.label`, 'Una acción necesita label');
                    if (a?.icon != null && (typeof a.icon !== 'string' || !a.icon || a.icon.length > 32))
                        push(`${ap}.icon`, 'icon debe ser un texto de hasta 32 caracteres');
                    if (a?.tooltip != null && typeof a.tooltip !== 'string')
                        push(`${ap}.tooltip`, 'tooltip debe ser un texto');
                    // Las reglas de una acción leen de la fila (`./campo`), cuyas propiedades no se conocen: cualquiera vale.
                    for (const k of ['showWhen', 'disabledWhen']) {
                        if (a?.[k] != null)
                            this.validateRule(a[k], `${ap}.${k}`, push, keys, ANY_ROW_KEY);
                    }
                });
            }
        }
        this.validateLogic(t.logic, `${p}.logic`, push, keys, row);
    }
    validateTableSource(t, p, push, keys, row) {
        const src = t.source;
        if (!src || typeof src !== 'object' || Array.isArray(src))
            return push(`${p}.source`, 'source debe ser un objeto');
        if (typeof src.endpoint !== 'string' || !src.endpoint)
            push(`${p}.source.endpoint`, 'source necesita endpoint');
        if (src.mode != null && src.mode !== 'client' && src.mode !== 'server')
            push(`${p}.source.mode`, "mode debe ser 'client' o 'server'");
        if (src.mode === 'server' && t.pageSize == null)
            push(`${p}.pageSize`, 'source.mode "server" necesita pageSize');
        if (t.rows != null || t.dataKey != null)
            push(`${p}.source`, 'source no se combina con rows ni dataKey');
        if (src.dependsOn != null) {
            if (!Array.isArray(src.dependsOn))
                push(`${p}.source.dependsOn`, 'dependsOn debe ser un array');
            else if (src.externalParams === true) {
                src.dependsOn.forEach((d) => {
                    if (typeof d !== 'string' || !/^[A-Za-z_][A-Za-z0-9_.]*$/.test(d))
                        push(`${p}.source.dependsOn`, `Clave de modelo no válida: ${String(d)}`);
                });
            }
            else
                src.dependsOn.forEach((d) => this.checkRef(String(d), `${p}.source.dependsOn`, push, keys, row));
        }
        if (src.externalParams != null && typeof src.externalParams !== 'boolean')
            push(`${p}.source.externalParams`, 'externalParams debe ser true o false');
        if (src.requireParams != null && typeof src.requireParams !== 'boolean')
            push(`${p}.source.requireParams`, 'requireParams debe ser true o false');
    }
    validateTotals(a, p, push) {
        if (a.totals == null)
            return;
        if (!Array.isArray(a.totals))
            return push(`${p}.totals`, 'totals debe ser un array');
        const types = new Map();
        const collect = (nodes) => (Array.isArray(nodes) ? nodes : []).forEach((n) => {
            if (!n || typeof n !== 'object')
                return;
            if (isDfGroup(n))
                collect(n.fields);
            else if (isDfField(n) && n.key)
                types.set(n.key, n.type);
        });
        collect(a.fields);
        a.totals.forEach((t, i) => {
            const tp = `${p}.totals[${i}]`;
            if (!t || typeof t !== 'object')
                return push(tp, 'Total inválido');
            if (typeof t.label !== 'string' || !t.label)
                push(`${tp}.label`, 'Un total necesita label');
            if (!DF_ARRAY_TOTAL_OPS.includes(t.op))
                return push(`${tp}.op`, `op desconocida: ${String(t.op)}`);
            if (t.field == null) {
                if (t.op !== 'count')
                    push(`${tp}.field`, `El total ${t.op} necesita field`);
            }
            else if (!types.has(t.field)) {
                push(`${tp}.field`, `Campo desconocido en la fila: ${t.field}`);
            }
            else if (t.op !== 'count' && !['number', 'currency'].includes(types.get(t.field))) {
                push(`${tp}.field`, `El total ${t.op} necesita un campo number o currency`);
            }
        });
    }
    validateField(f, p, push, keys, row, table) {
        if (table && (f.hidden === true || f.logic?.showWhen || f.logic?.hideWhen)) {
            push(`${p}.logic`, 'En una lista con display "table" un campo no puede ocultarse: desalinearía las columnas');
        }
        if (typeof f.key !== 'string' || !KEY_RE.test(f.key))
            push(`${p}.key`, 'key obligatoria con formato ^[A-Za-z_][A-Za-z0-9_.]*$');
        else if (isReservedKey(f.key))
            push(`${p}.key`, 'La clave ctx está reservada para el contexto externo de las condiciones (ctx.nombre)');
        if (!this.isKnownType(f.type))
            push(`${p}.type`, `Tipo no soportado: ${String(f.type)}`);
        if (OPTION_TYPES.has(f.type) && f.options == null)
            push(`${p}.options`, `El tipo ${f.type} necesita options`);
        if (f.options && !Array.isArray(f.options)) {
            const o = f.options;
            if (o.source === 'static' && !Array.isArray(o.items))
                push(`${p}.options.items`, 'static necesita items');
            if (o.source === 'dependent')
                this.checkRef(o.dependsOn, `${p}.options.dependsOn`, push, keys, row);
            if (o.source === 'dependent' && (!o.map || typeof o.map !== 'object' || Array.isArray(o.map)))
                push(`${p}.options.map`, 'dependent necesita map');
            if (o.source === 'remote' && (typeof o.endpoint !== 'string' || !o.endpoint))
                push(`${p}.options.endpoint`, 'remote necesita endpoint');
            if (o.source === 'remote')
                (o.dependsOn ?? []).forEach((d) => this.checkRef(d, `${p}.options.dependsOn`, push, keys, row));
            if (!['static', 'dependent', 'remote'].includes(o.source))
                push(`${p}.options.source`, `source desconocido: ${String(o.source)}`);
        }
        const v = f.validation;
        if (v) {
            if (v.pattern != null) {
                try {
                    new RegExp(v.pattern);
                }
                catch {
                    push(`${p}.validation.pattern`, 'Expresión regular inválida');
                }
            }
            [...(v.validators ?? []), ...(v.asyncValidators ?? [])].forEach((ref, i) => {
                if (!ref?.name)
                    push(`${p}.validation.validators[${i}]`, 'name obligatorio');
                else if (!this.registry.has(ref.name))
                    push(`${p}.validation.validators[${i}]`, `Validador no registrado: ${ref.name}`);
            });
        }
        if (f.layout?.col != null && (f.layout.col < 1 || f.layout.col > 12))
            push(`${p}.layout.col`, 'col entre 1 y 12');
        if (f.type === 'currency' && f.props)
            this.validateCurrencyProps(f.props, `${p}.props`, push);
        this.validateLogic(f.logic, `${p}.logic`, push, keys, row);
    }
    validateLogic(logic, p, push, keys, row) {
        if (!logic)
            return;
        ['showWhen', 'hideWhen', 'requiredWhen', 'disabledWhen'].forEach((k) => {
            if (logic[k])
                this.validateRule(logic[k], `${p}.${k}`, push, keys, row);
        });
    }
    /** Comprueba que una referencia a otro campo existe: la raíz, o la fila si empieza por `./`. */
    checkRef(ref, p, push, keys, row) {
        if (ref.startsWith(CONTEXT_PREFIX)) {
            // El contexto lo pasa la app (`<dynamic-form [context]>`): no se puede saber qué claves traerá.
            if (ref.length === CONTEXT_PREFIX.length)
                push(p, 'ctx. necesita el nombre de una clave del contexto: ctx.modo');
        }
        else if (ref.startsWith(RELATIVE_PREFIX)) {
            if (!row)
                push(p, `La ruta relativa ${ref} solo se puede usar dentro de una lista`);
            else if (!row.has(ref.slice(RELATIVE_PREFIX.length)))
                push(p, `Campo desconocido en la fila: ${ref}`);
        }
        else if (!keys.has(ref)) {
            push(p, `Campo desconocido: ${ref}`);
        }
    }
    validateRule(rule, p, push, keys, row) {
        if (!rule || typeof rule !== 'object')
            return push(p, 'Regla inválida');
        const c = rule;
        if (typeof c.field === 'string') {
            this.checkRef(c.field, `${p}.field`, push, keys, row);
            if (!DF_OPERATORS.includes(c.operator))
                push(`${p}.operator`, `Operador desconocido: ${String(c.operator)}`);
            else if (!VALUELESS_OPERATORS.has(c.operator) && c.value === undefined)
                push(`${p}.value`, `value obligatorio con el operador ${c.operator}`);
            return;
        }
        const g = rule;
        if (!g.all && !g.any && !g.not)
            return push(p, 'Un grupo de reglas necesita all, any o not');
        g.all?.forEach((r, i) => this.validateRule(r, `${p}.all[${i}]`, push, keys, row));
        g.any?.forEach((r, i) => this.validateRule(r, `${p}.any[${i}]`, push, keys, row));
        if (g.not)
            this.validateRule(g.not, `${p}.not`, push, keys, row);
    }
    /** Props de un campo currency que vienen del backend: si no son válidas, el adaptador las ignoraría. */
    validateCurrencyProps(props, p, push) {
        if (props['currency'] != null && !isCurrencyCode(props['currency']))
            push(`${p}.currency`, `Código de moneda ISO 4217 no válido: ${String(props['currency'])}`);
        if (props['numberFormat'] != null && !NUMBER_FORMATS.includes(props['numberFormat']))
            push(`${p}.numberFormat`, "numberFormat debe ser 'es' o 'en'");
        if (props['wordsLanguage'] != null && !WORDS_LANGUAGES.includes(props['wordsLanguage']))
            push(`${p}.wordsLanguage`, "wordsLanguage debe ser 'es' o 'en'");
        for (const k of ['amountInWords', 'wordsUppercase']) {
            if (props[k] != null && typeof props[k] !== 'boolean')
                push(`${p}.${k}`, `${k} debe ser true o false`);
        }
        const w = props['currencyWords'];
        if (w != null && (typeof w !== 'object' || !['singular', 'plural', 'centSingular', 'centPlural'].every((k) => typeof w[k] === 'string'))) {
            push(`${p}.currencyWords`, 'currencyWords necesita singular, plural, centSingular y centPlural');
        }
    }
    /** Tipos del contrato o tipos registrados en Formly con provideDynamicForms({ types }). */
    isKnownType(type) {
        if (typeof type !== 'string')
            return false;
        return DF_FIELD_TYPES.includes(type) || this.declaredTypes.has(type) || !!this.formlyConfig?.types[type];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: SchemaValidatorService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: SchemaValidatorService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: SchemaValidatorService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const FORBIDDEN_PROP_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
const PROP_KEY_RE = /^[A-Za-z][A-Za-z0-9_]*$/;
// eslint-disable-next-line no-control-regex -- la sanitización elimina justo estos caracteres
const CONTROL_CHARS_RE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
function interpolate(template, data) {
    return template.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (_, k) => {
        const v = getByPath(data, k);
        return v == null ? '' : String(v);
    });
}
/**
 * Adapter Layer: SchemaContract (JSON) → FormlyFieldConfig[].
 * Única pieza de la librería que conoce Formly en profundidad.
 */
class FormSchemaAdapterService {
    config = inject(DYNAMIC_FORMS_CONFIG);
    registry = inject(ValidatorRegistryService);
    schemaValidator = inject(SchemaValidatorService);
    evaluator = inject(ConditionEvaluatorService);
    optionsProvider = inject(DF_OPTIONS_PROVIDER, { optional: true });
    formlyConfig = inject(FormlyConfig, { optional: true });
    /** Tipos declarados en forRoot(): se leen de FORMLY_CONFIG porque Formly los aplica en diferido. */
    declaredTypes = [inject(FORMLY_CONFIG, { optional: true }) ?? []]
        .flat(Infinity)
        .flatMap((c) => c?.types ?? []);
    /** `layout.resetOnHide` del esquema que se está traduciendo (toFormly es síncrono). */
    schemaResetOnHide;
    remoteCache = new Map();
    subscriptions = new WeakMap();
    /**
     * Registra (o sustituye) el proveedor de `options.source = 'remote'` en tiempo de ejecución. Sirve cuando
     * `provideDynamicForms` está en los providers de una ruta y no llega a este servicio (que es `root`), como el
     * `DF_OPTIONS_PROVIDER`. Vacía la caché de opciones: las siguientes cargas ya van al proveedor nuevo.
     */
    registerOptionsProvider(provider) {
        this.optionsProvider = provider;
        this.remoteCache.clear();
    }
    /** Valida, sanitiza y transforma. Lanza DynamicFormsSchemaError en modo estricto. */
    toFormly(schema) {
        const result = this.schemaValidator.validate(schema);
        if (!result.valid) {
            if (this.config.strictSchema)
                throw new DynamicFormsSchemaError(result.errors);
            console.warn('[dynamic-forms] Esquema con incidencias:', result.errors);
        }
        const clean = this.sanitize(schema);
        // columns = campos por fila; por defecto, uno por fila (ocupa las 12 columnas de la rejilla).
        const columns = clean.layout?.columns ?? 1;
        this.schemaResetOnHide = typeof clean.layout?.resetOnHide === 'boolean' ? clean.layout.resetOnHide : undefined;
        try {
            return [
                {
                    fieldGroupClassName: `df-grid df-grid--${columns}`,
                    fieldGroup: clean.fields.map((n) => this.mapNode(n, columns)),
                },
            ];
        }
        finally {
            this.schemaResetOnHide = undefined;
        }
    }
    // ---------------------------------------------------------------------------
    // Sanitización: copia profunda con whitelist de claves.
    // ---------------------------------------------------------------------------
    sanitize(schema) {
        const str = (v) => typeof v === 'string' ? v.replace(CONTROL_CHARS_RE, '').trim() : undefined;
        const sanitizeNode = (node) => {
            if (isDfGroup(node)) {
                const g = {
                    type: 'group',
                    id: str(node.id) ?? '',
                    title: str(node.title),
                    description: str(node.description),
                    columns: node.columns,
                    cssClass: str(node.cssClass),
                    logic: node.logic,
                    fields: (node.fields ?? []).map(sanitizeNode),
                };
                return g;
            }
            if (isDfSlot(node))
                return { type: 'slot', name: str(node.name) ?? '', cssClass: str(node.cssClass), logic: node.logic };
            if (isDfTable(node))
                return this.sanitizeTable(node, str);
            if (isDfArray(node)) {
                const a = {
                    type: 'array',
                    key: node.key,
                    title: str(node.title),
                    description: str(node.description),
                    itemLabel: str(node.itemLabel),
                    addLabel: str(node.addLabel),
                    removeLabel: str(node.removeLabel),
                    minItems: node.minItems,
                    maxItems: node.maxItems,
                    totals: Array.isArray(node.totals)
                        ? node.totals.map((t) => ({ label: str(t.label) ?? '', op: t.op, field: t.field }))
                        : undefined,
                    display: node.display,
                    columns: node.columns,
                    cssClass: str(node.cssClass),
                    logic: node.logic,
                    fields: (node.fields ?? []).map(sanitizeNode),
                };
                return a;
            }
            const f = {
                key: node.key,
                type: node.type,
                label: str(node.label),
                placeholder: str(node.placeholder),
                description: str(node.description),
                defaultValue: node.defaultValue,
                readonly: node.readonly === true,
                disabled: node.disabled === true,
                hidden: node.hidden === true,
                options: node.options,
                validation: node.validation,
                logic: node.logic,
                layout: node.layout,
                props: this.sanitizeProps(node.props),
            };
            return f;
        };
        return {
            version: '1.0',
            id: schema.id,
            title: str(schema.title),
            description: str(schema.description),
            layout: schema.layout,
            fields: schema.fields.map(sanitizeNode),
            meta: schema.meta,
        };
    }
    sanitizeTable(node, str) {
        const column = (c) => ({
            key: c.key,
            label: str(c.label) ?? '',
            type: c.type,
            map: c.map && typeof c.map === 'object' ? this.cleanValue(c.map) : undefined,
            variants: c.variants && typeof c.variants === 'object' ? this.cleanValue(c.variants) : undefined,
            href: str(c.href),
            template: str(c.template),
            sortable: c.sortable,
            col: c.col,
            currency: c.currency,
            filter: c.filter === true ? true : undefined,
            frozen: c.frozen === true ? true : undefined,
            html: c.html === true ? true : undefined,
        });
        return {
            type: 'table',
            id: str(node.id) ?? '',
            title: str(node.title),
            description: str(node.description),
            columns: (Array.isArray(node.columns) ? node.columns : []).map(column),
            rows: Array.isArray(node.rows) ? this.cleanValue(node.rows) : undefined,
            dataKey: node.dataKey,
            source: node.source && typeof node.source === 'object'
                ? {
                    endpoint: str(node.source.endpoint) ?? '', mode: node.source.mode, dependsOn: node.source.dependsOn,
                    externalParams: node.source.externalParams === true ? true : undefined,
                    requireParams: node.source.requireParams === false ? false : undefined,
                }
                : undefined,
            errorMessage: str(node.errorMessage),
            filter: node.filter === true,
            filterLabel: str(node.filterLabel),
            searchKeys: Array.isArray(node.searchKeys) ? node.searchKeys.filter((k) => typeof k === 'string') : undefined,
            pageSize: node.pageSize,
            pageSizeOptions: node.pageSizeOptions,
            sort: Array.isArray(node.sort) ? node.sort.map((s) => ({ key: s.key, direction: s.direction })) : node.sort ? { key: node.sort.key, direction: node.sort.direction } : undefined,
            multiSort: node.multiSort === true ? true : undefined,
            selectable: node.selectable === 'multiple' ? 'multiple' : node.selectable === 'single' ? 'single' : node.selectable === true,
            selectionKey: node.selectionKey,
            selectableWhen: node.selectableWhen,
            headerSelects: node.headerSelects === 'page' ? 'page' : node.headerSelects === 'filtered' ? 'filtered' : undefined,
            exportCsv: node.exportCsv && typeof node.exportCsv === 'object'
                ? { filename: str(node.exportCsv.filename) }
                : node.exportCsv === true,
            pinnableColumns: node.pinnableColumns === true ? true : undefined,
            reorderableColumns: node.reorderableColumns === true ? true : undefined,
            resizableColumns: node.resizableColumns === true ? true : undefined,
            persistState: node.persistState === 'local' || node.persistState === 'session' ? node.persistState : node.persistState === true ? true : undefined,
            stateKey: str(node.stateKey),
            actions: node.actions?.map((a) => ({
                name: a.name, label: str(a.label) ?? '', icon: str(a.icon), tooltip: str(a.tooltip), showWhen: a.showWhen, disabledWhen: a.disabledWhen,
            })),
            emptyMessage: str(node.emptyMessage),
            cssClass: str(node.cssClass),
            logic: node.logic,
        };
    }
    /** Copia profunda de datos del esquema: sin claves peligrosas ni funciones, y sin caracteres de control en los textos. */
    cleanValue(value) {
        if (typeof value === 'string')
            return value.replace(CONTROL_CHARS_RE, '');
        if (Array.isArray(value))
            return value.map((v) => this.cleanValue(v));
        if (value && typeof value === 'object') {
            const out = {};
            for (const [k, v] of Object.entries(value)) {
                if (FORBIDDEN_PROP_KEYS.has(k) || typeof v === 'function')
                    continue;
                out[k] = this.cleanValue(v);
            }
            return out;
        }
        return typeof value === 'function' ? undefined : value;
    }
    sanitizeProps(props) {
        if (!props)
            return {};
        const out = {};
        for (const [k, v] of Object.entries(props)) {
            // Cualquier clave que empiece por "on" (onClick, onclick…) puede acabar como manejador de eventos.
            if (FORBIDDEN_PROP_KEYS.has(k) || !PROP_KEY_RE.test(k) || /^on/i.test(k))
                continue;
            if (typeof v === 'function')
                continue;
            out[k] = v;
        }
        return out;
    }
    // ---------------------------------------------------------------------------
    // Nodos
    // ---------------------------------------------------------------------------
    mapNode(node, parentColumns) {
        if (isDfGroup(node))
            return this.mapGroup(node);
        if (isDfArray(node))
            return this.mapArray(node);
        if (isDfTable(node))
            return this.mapTable(node);
        if (isDfSlot(node))
            return this.mapSlot(node);
        return this.mapField(node, parentColumns);
    }
    /** Lista repetible: un tipo `df-repeat` (FormArray) cuyas filas son un grupo con los campos del nodo. */
    mapArray(array) {
        const table = array.display === 'table';
        const columns = array.columns ?? 1;
        const min = array.minItems;
        const max = array.maxItems;
        const cells = array.fields.filter((n) => !(isDfField(n) && n.type === 'hidden'));
        const children = array.fields.map((n) => {
            const child = this.mapNode(n, columns);
            if (!table)
                return child;
            // Cada campo es una celda: la rejilla de la fila la fija la lista, el nombre va en la cabecera.
            child.className = isDfField(n) ? n.layout?.cssClass : undefined;
            const label = child.props?.['label'];
            child.props = { ...child.props, hideLabel: true, attributes: label ? { 'aria-label': String(label) } : undefined };
            return child;
        });
        const config = {
            key: array.key,
            type: 'df-repeat',
            className: ['df-col-12', array.cssClass].filter(Boolean).join(' '),
            defaultValue: min ? Array.from({ length: min }, () => ({})) : undefined,
            props: {
                label: array.title,
                description: array.description,
                itemLabel: array.itemLabel,
                addLabel: array.addLabel,
                removeLabel: array.removeLabel,
                minItems: min,
                maxItems: max,
                display: table ? 'table' : 'rows',
                tableColumns: table ? cells.map((n) => this.tableColumn(n)) : undefined,
                totals: array.totals?.length ? array.totals.map((t) => this.resolveTotal(t, array.fields)) : undefined,
            },
            fieldArray: {
                fieldGroupClassName: table ? 'df-table-row' : `df-grid df-grid--${columns}`,
                fieldGroup: children,
            },
            validators: this.arrayValidators(min, max),
        };
        this.applyLogic(config, array.logic);
        return config;
    }
    /** Hueco para una plantilla de la app: un campo sin key (no crea control) del tipo `df-slot`. */
    mapSlot(slot) {
        const config = {
            type: 'df-slot',
            className: ['df-col-12', slot.cssClass].filter(Boolean).join(' '),
            props: { slotName: slot.name },
        };
        this.applyLogic(config, slot.logic);
        return config;
    }
    /** Tabla de datos de solo lectura: un campo sin key (no crea control) del tipo `df-table`. */
    mapTable(table) {
        const columns = table.columns.map((c) => {
            const p = this.currencyProps({ currency: c.currency });
            return {
                key: c.key,
                label: c.label,
                type: c.type ?? 'text',
                map: c.map,
                variants: c.variants,
                href: c.href,
                template: c.template,
                sortable: c.sortable !== false,
                col: Math.min(12, Math.max(1, c.col ?? 1)),
                currency: p['currency'],
                numberFormat: p['numberFormat'],
                filter: c.filter === true,
                frozen: c.frozen === true,
                html: c.html === true,
            };
        });
        const exportCsv = table.exportCsv
            ? { filename: (typeof table.exportCsv === 'object' ? table.exportCsv.filename : undefined) || table.id }
            : undefined;
        const config = {
            type: 'df-table',
            className: ['df-col-12', table.cssClass].filter(Boolean).join(' '),
            props: {
                tableId: table.id,
                title: table.title,
                description: table.description,
                columns,
                staticRows: table.rows,
                dataKey: table.dataKey,
                source: table.source
                    ? { endpoint: table.source.endpoint, mode: table.source.mode ?? 'client', dependsOn: table.source.dependsOn ?? [], ...(table.source.requireParams === false ? { requireParams: false } : {}) }
                    : undefined,
                errorMessage: table.errorMessage,
                filter: table.filter === true,
                filterLabel: table.filterLabel,
                searchKeys: table.searchKeys,
                pageSize: table.pageSize,
                pageSizeOptions: table.pageSizeOptions,
                sorts: (Array.isArray(table.sort) ? table.sort : table.sort ? [table.sort] : []).map((s) => ({ key: s.key, direction: s.direction ?? 'asc' })),
                multiSort: table.multiSort === true,
                selectable: table.selectable === 'multiple' ? 'multiple' : table.selectable === true || table.selectable === 'single',
                selectionKey: table.selectionKey,
                selectableWhen: table.selectableWhen,
                headerSelects: table.headerSelects === 'page' ? 'page' : 'filtered',
                exportCsv,
                pinnableColumns: table.pinnableColumns === true,
                reorderableColumns: table.reorderableColumns === true,
                resizableColumns: table.resizableColumns === true,
                persistState: table.persistState === 'local' ? 'local' : table.persistState === true || table.persistState === 'session' ? 'session' : undefined,
                stateKey: table.stateKey || table.id,
                actions: table.actions ?? [],
                emptyMessage: table.emptyMessage,
            },
        };
        this.applyLogic(config, table.logic);
        return config;
    }
    /** Resuelve la moneda y el formato de un total con los del campo que suma (o con los de la app). */
    resolveTotal(total, rowNodes) {
        const source = total.field ? this.findRowField(rowNodes, total.field) : undefined;
        const base = { label: total.label, op: total.op, field: total.field };
        if (source?.type === 'currency') {
            const p = this.currencyProps(source.props ?? {});
            return { ...base, currency: p['currency'], numberFormat: p['numberFormat'] };
        }
        return { ...base, numberFormat: this.config.currency.numberFormat };
    }
    findRowField(nodes, key) {
        for (const n of nodes) {
            if (isDfGroup(n)) {
                const found = this.findRowField(n.fields, key);
                if (found)
                    return found;
            }
            else if (isDfField(n) && n.key === key) {
                return n;
            }
        }
        return undefined;
    }
    tableColumn(node) {
        const field = isDfField(node) ? node : undefined;
        return {
            label: field?.label ?? '',
            col: Math.min(12, Math.max(1, field?.layout?.col ?? 1)),
            required: field?.validation?.required === true,
        };
    }
    arrayValidators(min, max) {
        const count = (c) => (Array.isArray(c.value) ? c.value.length : 0);
        return {
            ...(min ? { minItems: { expression: (c) => count(c) >= min } } : {}),
            ...(max ? { maxItems: { expression: (c) => count(c) <= max } } : {}),
        };
    }
    mapGroup(group) {
        const columns = group.columns ?? 1;
        const theme = this.config.theme;
        const config = {
            fieldGroupClassName: `df-grid df-grid--${columns}`,
            // Un grupo (fieldset) ocupa siempre la fila entera de la rejilla que lo contiene.
            className: ['df-col-12', group.cssClass].filter(Boolean).join(' '),
            wrappers: theme.groupWrapper ? [theme.groupWrapper] : [],
            props: { title: group.title, description: group.description, groupId: group.id, cssClass: group.cssClass },
            fieldGroup: group.fields.map((n) => this.mapNode(n, columns)),
        };
        this.applyLogic(config, group.logic);
        return config;
    }
    /**
     * Wrappers de un campo. Manda, por este orden: `theme.typeWrappers` del tipo del contrato (el tema decide, aunque
     * el paquete UI declare wrappers en sus tipos), los `wrappers` del tipo Formly registrado (un tipo propio con
     * `wrappers: []` se pinta sin el wrapper del tema) y `theme.fieldWrappers`.
     */
    fieldWrappers(contractType, formlyType) {
        const theme = this.config.theme;
        const declared = this.declaredTypes.find((t) => t.name === formlyType)?.wrappers ?? this.formlyConfig?.types[formlyType]?.wrappers;
        return [...(theme.typeWrappers?.[contractType] ?? declared ?? theme.fieldWrappers ?? [])];
    }
    mapField(field, parentColumns) {
        const theme = this.config.theme;
        // Un tipo propio (registrado con provideDynamicForms({ types })) no está en typeMap y se usa tal cual.
        const contractType = field.type;
        const formlyType = theme.typeMap[contractType] ?? field.type;
        const v = field.validation ?? {};
        const props = {
            label: field.label,
            placeholder: field.placeholder,
            description: field.description,
            readonly: field.readonly,
            disabled: field.disabled,
            required: v.required === true,
            min: v.min,
            max: v.max,
            minLength: v.minLength,
            maxLength: v.maxLength,
            pattern: v.pattern,
            ...this.inputTypeProps(field),
            ...(theme.typeProps?.[contractType] ?? {}),
            ...field.props,
        };
        // Los componentes (contador, bloqueo) leen el modo resuelto de las props.
        props['maxLengthMode'] = resolveMaxLengthMode(field.props?.['maxLengthMode'], this.config.maxLengthMode);
        if (field.type === 'currency')
            Object.assign(props, this.currencyProps(field.props ?? {}));
        const config = {
            key: field.key,
            type: formlyType,
            defaultValue: field.defaultValue,
            wrappers: field.type === 'hidden' ? [] : this.fieldWrappers(contractType, formlyType),
            className: field.type === 'hidden' ? 'df-hidden-slot' : this.className(field, parentColumns),
            props,
            hide: field.hidden === true,
            validators: this.fieldValidators(field, v, props),
            asyncValidators: this.mapValidators(v.asyncValidators, true),
            validation: v.messages ? { messages: this.mapMessages(v) } : undefined,
        };
        this.applyOptions(config, field.options);
        this.applyLogic(config, field.logic);
        return config;
    }
    inputTypeProps(field) {
        switch (field.type) {
            case 'email': return { type: 'email' };
            case 'password': return { type: 'password' };
            case 'number': return { type: 'number' };
            case 'date': return { type: 'date' };
            case 'multiselect': return { multiple: true };
            case 'checkbox': return { hideLabel: true };
            default: return {};
        }
    }
    className(field, parentColumns) {
        const span = field.layout?.col ?? Math.max(1, Math.round(12 / parentColumns));
        const classes = [`df-col-${Math.min(12, Math.max(1, span))}`];
        if (field.layout?.order != null)
            classes.push(`df-order-${field.layout.order}`);
        if (field.layout?.cssClass)
            classes.push(field.layout.cssClass);
        return classes.join(' ');
    }
    // ---------------------------------------------------------------------------
    // Validadores por alias
    // ---------------------------------------------------------------------------
    /** Validadores síncronos: los alias del esquema más los built-in de los tipos email y currency. */
    fieldValidators(field, v, props) {
        const maxLengthMode = props['maxLengthMode'];
        const aliases = this.withWeightedMaxLength(this.mapValidators(v.validators, false), v.maxLength, maxLengthMode);
        if (field.type === 'email') {
            return { email: { expression: (c) => Validators.email(c) === null }, ...aliases };
        }
        if (field.type === 'currency') {
            const format = props['numberFormat'];
            const currency = props['currency'];
            return {
                currencyFormat: { expression: (c) => amountError(c.value, format, currency) !== 'format' },
                currencyDecimals: { expression: (c) => amountError(c.value, format, currency) !== 'decimals' },
                ...aliases,
            };
        }
        return aliases;
    }
    /**
     * Moneda y formato de un campo currency: lo que diga el campo (si es válido) o la config de la app.
     * El idioma de la letra sigue al numberFormat del campo si el campo lo cambia y no fija wordsLanguage.
     */
    currencyProps(own) {
        const defaults = this.config.currency;
        const pick = (value, valid) => (valid.includes(value) ? value : undefined);
        const numberFormat = pick(own['numberFormat'], NUMBER_FORMATS);
        return {
            currency: isCurrencyCode(own['currency']) ? own['currency'] : defaults.code,
            numberFormat: numberFormat ?? defaults.numberFormat,
            wordsLanguage: pick(own['wordsLanguage'], WORDS_LANGUAGES) ?? numberFormat ?? defaults.wordsLanguage,
            amountInWords: typeof own['amountInWords'] === 'boolean' ? own['amountInWords'] : defaults.amountInWords,
            wordsUppercase: typeof own['wordsUppercase'] === 'boolean' ? own['wordsUppercase'] : defaults.wordsUppercase,
        };
    }
    /**
     * Formly valida props.maxLength contando caracteres. En modo 'weighted' (ñ, á… cuentan 2) se añade
     * un validador con el mismo error { maxLength: { requiredLength, actualLength } }, así que el
     * mensaje built-in sigue funcionando. Como la longitud con peso nunca es menor, no se contradicen.
     */
    withWeightedMaxLength(validators, max, mode) {
        if (max == null || mode !== 'weighted')
            return validators;
        const weighted = (c) => {
            if (typeof c.value !== 'string')
                return null;
            const actualLength = textLength(c.value, 'weighted');
            return actualLength > max ? { maxLength: { requiredLength: max, actualLength } } : null;
        };
        return { ...(validators ?? {}), validation: [weighted] };
    }
    /** Mensajes por campo: resuelve {{x}} contra las props del campo y los args del validador del mismo nombre. */
    mapMessages(v) {
        const refs = [...(v.validators ?? []), ...(v.asyncValidators ?? [])];
        const out = {};
        for (const [name, template] of Object.entries(v.messages ?? {})) {
            const args = refs.find((r) => r.name === name)?.args ?? {};
            out[name] = (_error, field) => interpolate(template, { ...(field.props ?? {}), ...args });
        }
        return out;
    }
    mapValidators(refs, async) {
        if (!refs?.length)
            return undefined;
        const out = {};
        for (const ref of refs) {
            const def = this.registry.get(ref.name);
            if (!def)
                continue;
            if (!!def.async !== async) {
                console.warn(`[dynamic-forms] "${ref.name}" es ${def.async ? 'async' : 'sync'}; muévelo a ${def.async ? 'asyncValidators' : 'validators'}.`);
                continue;
            }
            out[ref.name] = {
                expression: (control, field) => def.validate(control, ref.args, field),
                message: this.resolveMessage(ref, def),
            };
        }
        return out;
    }
    resolveMessage(ref, def) {
        return (_error, field) => {
            const data = { ...(field.props ?? {}), ...(ref.args ?? {}) };
            if (ref.message)
                return interpolate(ref.message, data);
            if (typeof def.message === 'function')
                return def.message(ref.args, field);
            return interpolate(def.message, data);
        };
    }
    // ---------------------------------------------------------------------------
    // Opciones: static | dependent | remote
    // ---------------------------------------------------------------------------
    applyOptions(config, source) {
        if (!source)
            return;
        const props = (config.props ??= {});
        if (Array.isArray(source)) {
            props['options'] = source;
            return;
        }
        if (source.source === 'static') {
            props['options'] = source.items;
            return;
        }
        config.expressions ??= {};
        const deps = source.source === 'dependent' ? [source.dependsOn] : source.dependsOn ?? [];
        const resetOnChange = source.resetOnChange !== false;
        if (source.source === 'dependent') {
            const mapping = source.map ?? {};
            const parent = source.dependsOn;
            props['options'] = [];
            config.expressions['props.options'] = (f) => {
                const parentValue = readPath(f, parent);
                return parentValue == null ? [] : mapping[String(parentValue)] ?? [];
            };
        }
        else {
            const endpoint = source.endpoint;
            props['options'] = [];
            config.expressions['props.options'] = (f) => this.remoteOptions(endpoint, deps, f);
        }
        if (resetOnChange && deps.length)
            this.resetOnParentChange(config, deps);
    }
    remoteOptions(endpoint, deps, field) {
        if (!endpoint)
            return of([]);
        if (!this.optionsProvider) {
            console.warn(`[dynamic-forms] options.source="remote" (${endpoint}) sin DF_OPTIONS_PROVIDER registrado.`);
            return of([]);
        }
        // El proveedor recibe el nombre del campo sin el "./" de las rutas relativas.
        const params = {};
        for (const d of deps)
            params[paramName(d)] = readPath(field, d);
        if (Object.values(params).some((v) => v == null || v === ''))
            return of([]);
        const cacheKey = `${endpoint}::${JSON.stringify(params)}`;
        let obs = this.remoteCache.get(cacheKey);
        if (!obs) {
            obs = this.optionsProvider.load(endpoint, params).pipe(shareReplay(1));
            this.remoteCache.set(cacheKey, obs);
        }
        return obs;
    }
    /** Cascading: cuando cambia cualquier padre, el hijo se vacía. */
    resetOnParentChange(config, deps) {
        const hooks = (config.hooks ??= {});
        const prevInit = hooks.onInit;
        const prevDestroy = hooks.onDestroy;
        hooks.onInit = (f) => {
            prevInit?.(f);
            const root = f.formControl?.root;
            if (!root)
                return;
            const sub = new Subscription();
            for (const dep of deps) {
                // Una ruta relativa se busca desde la fila (el padre del control); el resto, desde la raíz.
                const relative = dep.startsWith(RELATIVE_PREFIX);
                const parentControl = relative
                    ? f.formControl.parent?.get(dep.slice(RELATIVE_PREFIX.length).split('.'))
                    : root.get(dep.split('.'));
                if (!parentControl)
                    continue;
                sub.add(parentControl.valueChanges
                    .pipe(distinctUntilChanged())
                    .subscribe(() => {
                    if (f.formControl?.value != null && f.formControl.value !== '')
                        f.formControl.setValue(null);
                }));
            }
            this.subscriptions.set(f, sub);
        };
        hooks.onDestroy = (f) => {
            this.subscriptions.get(f)?.unsubscribe();
            this.subscriptions.delete(f);
            prevDestroy?.(f);
        };
    }
    // ---------------------------------------------------------------------------
    // Lógica condicional
    // ---------------------------------------------------------------------------
    applyLogic(config, logic) {
        config.resetOnHide = logic?.resetOnHide ?? this.schemaResetOnHide ?? this.config.defaultResetOnHide;
        if (!logic)
            return;
        const expressions = (config.expressions ??= {});
        // `f.model` es el objeto que contiene al campo: dentro de una lista repetible, su fila (para `./campo`).
        const rule = (r) => (f) => this.evaluator.evaluate(r, rootModel(f), f.model, contextOf(f));
        if (logic.hideWhen || logic.showWhen) {
            const hide = rule(logic.hideWhen);
            const show = rule(logic.showWhen);
            const staticHide = config.hide === true;
            expressions['hide'] = (f) => {
                if (staticHide)
                    return true;
                if (logic.hideWhen && hide(f))
                    return true;
                if (logic.showWhen)
                    return !show(f);
                return false;
            };
        }
        if (logic.requiredWhen) {
            const baseRequired = config.props?.['required'] === true;
            const req = rule(logic.requiredWhen);
            expressions['props.required'] = (f) => baseRequired || req(f);
        }
        if (logic.disabledWhen) {
            const baseDisabled = config.props?.['disabled'] === true;
            const dis = rule(logic.disabledWhen);
            expressions['props.disabled'] = (f) => baseDisabled || dis(f);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSchemaAdapterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSchemaAdapterService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: FormSchemaAdapterService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/** Helper exportado para tests/consumidores: ¿un valor de expresión es observable? */
const isObservableOptions = (v) => isObservable(v);

/**
 * Fachada pública. Encapsula el ciclo de vida de Formly:
 *
 *   <dynamic-form [schema]="schema" [(model)]="model" (formSubmit)="onSubmit($event)">
 *     <button dfActions type="submit">Guardar</button>
 *   </dynamic-form>
 */
class DynamicFormComponent {
    adapter = inject(FormSchemaAdapterService);
    config = inject(DYNAMIC_FORMS_CONFIG);
    destroyRef = inject(DestroyRef);
    // ----- Inputs -------------------------------------------------------------
    schema = input.required(...(ngDevMode ? [{ debugName: "schema" }] : /* istanbul ignore next */ []));
    model = model({}, ...(ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []));
    submitLabel = input('Enviar', ...(ngDevMode ? [{ debugName: "submitLabel" }] : /* istanbul ignore next */ []));
    showDefaultActions = input(true, ...(ngDevMode ? [{ debugName: "showDefaultActions" }] : /* istanbul ignore next */ []));
    validateOnInit = input(false, ...(ngDevMode ? [{ debugName: "validateOnInit" }] : /* istanbul ignore next */ []));
    /**
     * Cuándo se muestran los errores: `'touched'` (por defecto) al tocar el campo o enviar; `'always'` desde que el
     * campo existe, también los que aparecen después (secciones condicionales, filas nuevas).
     */
    /**
     * Datos externos al formulario para las condiciones: `{ "field": "ctx.modo", ... }` lee `context().modo`. Si el objeto
     * cambia, las condiciones se reevalúan.
     */
    context = input({}, ...(ngDevMode ? [{ debugName: "context" }] : /* istanbul ignore next */ []));
    showErrors = input('touched', ...(ngDevMode ? [{ debugName: "showErrors" }] : /* istanbul ignore next */ []));
    // ----- Outputs ------------------------------------------------------------
    formSubmit = output();
    formInvalidSubmit = output();
    valueChange = output();
    statusChange = output();
    formReady = output();
    /** Un botón de fila de una tabla (`table.actions`) pulsado. */
    tableAction = output();
    /** Una fila de una tabla `selectable` seleccionada, o null al deseleccionarla. */
    tableSelect = output();
    /** Un enlace de una columna `link` pulsado: `originalEvent.preventDefault()` y navega tú para no recargar la página. */
    tableNavigate = output();
    // Plantillas de la app para las tablas: `<ng-template dfCell="nombre">` y `<ng-template dfEmpty="id">`.
    cellTemplates = contentChildren(DfCellDirective, ...(ngDevMode ? [{ debugName: "cellTemplates" }] : /* istanbul ignore next */ []));
    emptyTemplates = contentChildren(DfEmptyDirective, ...(ngDevMode ? [{ debugName: "emptyTemplates" }] : /* istanbul ignore next */ []));
    // Plantillas de la app para los nodos `slot` del esquema: `<ng-template dfSlot="nombre">`.
    slotTemplates = contentChildren(DfSlotDirective, ...(ngDevMode ? [{ debugName: "slotTemplates" }] : /* istanbul ignore next */ []));
    // ----- Estado interno -----------------------------------------------------
    form = new FormGroup({});
    options = { formState: {} };
    fields = computed(() => this.adapter.toFormly(this.schema()), ...(ngDevMode ? [{ debugName: "fields" }] : /* istanbul ignore next */ []));
    title = computed(() => this.schema().title, ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    description = computed(() => this.schema().description, ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    formId = computed(() => `df-${this.schema().id}`, ...(ngDevMode ? [{ debugName: "formId" }] : /* istanbul ignore next */ []));
    hostClass = `df-form ${this.config.theme.hostClass ?? ''}`.trim();
    /** layout.gap del esquema → --df-grid-gap (solo longitudes CSS simples). */
    get gridGap() {
        const gap = this.schema().layout?.gap;
        return isCssLength(gap) ? gap.trim() : null;
    }
    initialModel = {};
    constructor() {
        this.options.formState[DF_TABLE_EVENTS] = {
            action: (e) => this.tableAction.emit(e),
            select: (e) => this.tableSelect.emit(e),
            navigate: (e) => this.tableNavigate.emit(e),
        };
        this.options.formState[DF_TABLE_CONTROLS] = new Map();
        this.options.formState[DF_CONTEXT_KEY] = this.context();
        // Formly solo reevalúa las expresiones al cambiar el modelo: un contexto nuevo hay que avisarlo.
        effect(() => {
            const context = this.context();
            untracked(() => {
                this.options.formState[DF_CONTEXT_KEY] = context;
                const root = this.fields()[0];
                // Si el esquema cambió a la vez, Formly aún no ha construido la raíz nueva (sin `options`): ya leerá el contexto al construirla.
                if (root?.options && this.options.detectChanges)
                    this.options.detectChanges(root);
            });
        });
        this.options.formState[DF_SLOTS] = { get: (name) => this.slotTemplates().find((s) => s.name() === name)?.template ?? null };
        this.options.formState[DF_TABLE_SLOTS] = {
            cell: (name) => this.cellTemplates().find((c) => c.name() === name)?.template ?? null,
            empty: (id) => (this.emptyTemplates().find((e) => e.table() === id) ?? this.emptyTemplates().find((e) => !e.table()))?.template ?? null,
        };
        this.form.statusChanges.pipe(takeUntilDestroyed()).subscribe((s) => {
            if (this.showErrors() === 'always')
                this.form.markAllAsTouched();
            this.statusChange.emit(s);
        });
        // Cada esquema nuevo → snapshot del modelo inicial para reset().
        effect(() => {
            this.schema();
            untracked(() => {
                this.initialModel = structuredClone(this.model());
                this.formReady.emit(this.form);
                if (this.validateOnInit() || this.showErrors() === 'always')
                    queueMicrotask(() => this.markAllAsTouched());
            });
        });
    }
    get valid() {
        return this.form.valid;
    }
    onModelChange(next) {
        this.model.set({ ...next });
        this.valueChange.emit(this.model());
    }
    submit() {
        this.markAllAsTouched();
        const event = { model: this.model(), form: this.form, schema: this.schema() };
        if (this.form.valid)
            this.formSubmit.emit(event);
        else
            this.formInvalidSubmit.emit(event);
    }
    reset(next) {
        const value = structuredClone(next ?? this.initialModel);
        this.options.resetModel?.(value);
        this.model.set(value);
    }
    /**
     * Marca las filas que marcaría la casilla de la cabecera de una tabla `selectable: 'multiple'` (en modo `server`,
     * las de la página). Sin `tableId` actúa sobre todas las tablas. Emite `tableSelect` con `changed`.
     */
    selectAll(tableId) {
        this.tableControls(tableId).forEach((t) => t.selectAll());
    }
    /** Vacía la selección de una tabla (también la de otras páginas). Sin `tableId` actúa sobre todas las tablas. */
    clearSelection(tableId) {
        this.tableControls(tableId).forEach((t) => t.clearSelection());
    }
    tableControls(tableId) {
        const all = this.options.formState[DF_TABLE_CONTROLS];
        if (tableId === undefined)
            return [...all.values()];
        const one = all.get(tableId);
        return one ? [one] : [];
    }
    markAllAsTouched() {
        this.form.markAllAsTouched();
        this.form.updateValueAndValidity();
    }
    /**
     * Vuelve a ejecutar los validadores de todos los controles. Para validadores que leen estado fuera del
     * formulario (una señal, un servicio): llámalo cuando ese estado cambie.
     */
    revalidate() {
        const walk = (control) => {
            if (control instanceof FormGroup || control instanceof FormArray) {
                Object.values(control.controls).forEach(walk);
            }
            control.updateValueAndValidity({ onlySelf: true });
        };
        walk(this.form);
        this.form.updateValueAndValidity();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DynamicFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: DynamicFormComponent, isStandalone: true, selector: "dynamic-form", inputs: { schema: { classPropertyName: "schema", publicName: "schema", isSignal: true, isRequired: true, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, submitLabel: { classPropertyName: "submitLabel", publicName: "submitLabel", isSignal: true, isRequired: false, transformFunction: null }, showDefaultActions: { classPropertyName: "showDefaultActions", publicName: "showDefaultActions", isSignal: true, isRequired: false, transformFunction: null }, validateOnInit: { classPropertyName: "validateOnInit", publicName: "validateOnInit", isSignal: true, isRequired: false, transformFunction: null }, context: { classPropertyName: "context", publicName: "context", isSignal: true, isRequired: false, transformFunction: null }, showErrors: { classPropertyName: "showErrors", publicName: "showErrors", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { model: "modelChange", formSubmit: "formSubmit", formInvalidSubmit: "formInvalidSubmit", valueChange: "valueChange", statusChange: "statusChange", formReady: "formReady", tableAction: "tableAction", tableSelect: "tableSelect", tableNavigate: "tableNavigate" }, host: { properties: { "class": "this.hostClass", "style.--df-grid-gap": "this.gridGap" } }, queries: [{ propertyName: "cellTemplates", predicate: DfCellDirective, isSignal: true }, { propertyName: "emptyTemplates", predicate: DfEmptyDirective, isSignal: true }, { propertyName: "slotTemplates", predicate: DfSlotDirective, isSignal: true }], ngImport: i0, template: "<form [id]=\"formId()\" [formGroup]=\"form\" (ngSubmit)=\"submit()\" novalidate>\n  <ng-content select=\"[dfHeader]\"></ng-content>\n\n  @if (title()) {\n    <header class=\"df-form__header\">\n      <h2 class=\"df-form__title\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"df-form__description\">{{ description() }}</p>\n      }\n    </header>\n  }\n\n  <formly-form\n    [form]=\"form\"\n    [fields]=\"fields()\"\n    [model]=\"model()\"\n    [options]=\"options\"\n    (modelChange)=\"onModelChange($event)\">\n  </formly-form>\n\n  <footer class=\"df-form__actions\">\n    <ng-content select=\"[dfActions]\"></ng-content>\n    @if (showDefaultActions()) {\n      <button type=\"submit\" class=\"df-btn df-btn--primary\" [disabled]=\"form.pending\">\n        {{ submitLabel() }}\n      </button>\n    }\n  </footer>\n</form>\n", styles: [":host{display:block}.df-form__header{margin-bottom:1.25rem}.df-form__title{margin:0 0 .25rem;font-size:1.35rem;color:var(--df-color-text)}.df-form__description{margin:0;color:var(--df-color-muted)}.df-form__actions{display:flex;gap:.75rem;justify-content:flex-end;margin-top:1rem}.df-btn{padding:.55rem 1.1rem;border-radius:var(--df-radius);border:1px solid var(--df-color-border);background:transparent;color:var(--df-color-text);font:inherit;cursor:pointer}.df-btn--primary{background:var(--df-color-primary);border-color:var(--df-color-primary);color:#fff}.df-btn:disabled{opacity:.6;cursor:not-allowed}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: FormlyModule }, { kind: "component", type: i2.LegacyFormlyForm, selector: "formly-form" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: DynamicFormComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dynamic-form', standalone: true, imports: [ReactiveFormsModule, FormlyModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<form [id]=\"formId()\" [formGroup]=\"form\" (ngSubmit)=\"submit()\" novalidate>\n  <ng-content select=\"[dfHeader]\"></ng-content>\n\n  @if (title()) {\n    <header class=\"df-form__header\">\n      <h2 class=\"df-form__title\">{{ title() }}</h2>\n      @if (description()) {\n        <p class=\"df-form__description\">{{ description() }}</p>\n      }\n    </header>\n  }\n\n  <formly-form\n    [form]=\"form\"\n    [fields]=\"fields()\"\n    [model]=\"model()\"\n    [options]=\"options\"\n    (modelChange)=\"onModelChange($event)\">\n  </formly-form>\n\n  <footer class=\"df-form__actions\">\n    <ng-content select=\"[dfActions]\"></ng-content>\n    @if (showDefaultActions()) {\n      <button type=\"submit\" class=\"df-btn df-btn--primary\" [disabled]=\"form.pending\">\n        {{ submitLabel() }}\n      </button>\n    }\n  </footer>\n</form>\n", styles: [":host{display:block}.df-form__header{margin-bottom:1.25rem}.df-form__title{margin:0 0 .25rem;font-size:1.35rem;color:var(--df-color-text)}.df-form__description{margin:0;color:var(--df-color-muted)}.df-form__actions{display:flex;gap:.75rem;justify-content:flex-end;margin-top:1rem}.df-btn{padding:.55rem 1.1rem;border-radius:var(--df-radius);border:1px solid var(--df-color-border);background:transparent;color:var(--df-color-text);font:inherit;cursor:pointer}.df-btn--primary{background:var(--df-color-primary);border-color:var(--df-color-primary);color:#fff}.df-btn:disabled{opacity:.6;cursor:not-allowed}\n"] }]
        }], ctorParameters: () => [], propDecorators: { schema: [{ type: i0.Input, args: [{ isSignal: true, alias: "schema", required: true }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }, { type: i0.Output, args: ["modelChange"] }], submitLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "submitLabel", required: false }] }], showDefaultActions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDefaultActions", required: false }] }], validateOnInit: [{ type: i0.Input, args: [{ isSignal: true, alias: "validateOnInit", required: false }] }], context: [{ type: i0.Input, args: [{ isSignal: true, alias: "context", required: false }] }], showErrors: [{ type: i0.Input, args: [{ isSignal: true, alias: "showErrors", required: false }] }], formSubmit: [{ type: i0.Output, args: ["formSubmit"] }], formInvalidSubmit: [{ type: i0.Output, args: ["formInvalidSubmit"] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], statusChange: [{ type: i0.Output, args: ["statusChange"] }], formReady: [{ type: i0.Output, args: ["formReady"] }], tableAction: [{ type: i0.Output, args: ["tableAction"] }], tableSelect: [{ type: i0.Output, args: ["tableSelect"] }], tableNavigate: [{ type: i0.Output, args: ["tableNavigate"] }], cellTemplates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => DfCellDirective), { isSignal: true }] }], emptyTemplates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => DfEmptyDirective), { isSignal: true }] }], slotTemplates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => DfSlotDirective), { isSignal: true }] }], hostClass: [{
                type: HostBinding,
                args: ['class']
            }], gridGap: [{
                type: HostBinding,
                args: ['style.--df-grid-gap']
            }] } });

/*
 * @core/dynamic-forms — API pública (ver openspec.yaml → ComponentAPI)
 */
// Modelos / contratos

/**
 * Generated bundle index. Do not edit.
 */

export { BUSINESS_VALIDATORS, CONTEXT_PREFIX, CURRENCY_WORDS, CheckboxFieldComponent, ConditionEvaluatorService, CurrencyFieldComponent, DEFAULT_VALIDATION_MESSAGES, DF_ARRAY_TOTAL_OPS, DF_BADGE_VARIANTS, DF_FIELD_TYPES, DF_OPERATORS, DF_OPTIONS_PROVIDER, DF_PLAIN_TYPE_NAMES, DF_SLOTS, DF_TABLE_COLUMN_TYPES, DF_TABLE_CONTROLS, DF_TABLE_EVENTS, DF_TABLE_ICONS, DF_TABLE_PROVIDER, DF_TABLE_SLOTS, DF_VALIDATORS, DYNAMIC_FORMS_CONFIG, DfCellDirective, DfEmptyDirective, DfSlotDirective, DynamicFormComponent, DynamicFormsSchemaError, EN_TABLE_TEXTS, EN_VALIDATION_MESSAGES, FieldWrapperComponent, FormSchemaAdapterService, GroupWrapperComponent, HiddenFieldComponent, InputFieldComponent, NUMBER_FORMATS, PLAIN_THEME, RELATIVE_PREFIX, RadioFieldComponent, RepeatFieldComponent, SchemaValidatorService, SelectFieldComponent, SlotFieldComponent, TableFieldComponent, TextareaFieldComponent, ValidatorRegistryService, WORDS_LANGUAGES, amountError, amountExample, amountToWords, bootstrapTheme, currencySymbol, editableAmount, formatAmount, formatNumber, getByPath, integerToWords, integerToWordsEn, isCurrencyCode, isDfArray, isDfField, isDfGroup, isDfSlot, isDfTable, isObservableOptions, isValidCif, isValidDni, isValidIban, isValidNie, isValidPhoneES, isValidPostalCodeES, materialTheme, parseAmount, provideDynamicForms, textLength, toFormlyMessages, truncateToLength };
//# sourceMappingURL=core-dynamic-forms.mjs.map
